#!/usr/bin/env python3
"""Independent audit of legacy H+6 paired X artifacts; imports no simulation/fitter."""
import argparse
import ast
import csv
from functools import lru_cache
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import subprocess
import time
import tomllib
import warnings

METRICS = ('logical_1', 'logical_2', 'state_failure')
STEM = 'toric3d-x-feedback'
SETTINGS = dict(bp_method='minimum_sum', max_iter=50, ms_scaling_factor=1.,
                omp_thread_count=1, osd_method='OSD_CS', osd_order=2, schedule='parallel')
VARIANTS = ('drop_smallest', 'narrow_window', 'cubic', 'inverse_L_correction')
GUARDS = {'grid_resolution', 'interior_optimizer', 'monotonicity', 'goodness_of_fit',
          'crossings', 'bootstrap'} | {'sensitivity_'+name for name in VARIANTS}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value):
    require(not isinstance(value, bool), 'Boolean is not a count')
    number = int(value)
    require(str(number) == str(value), f'noninteger count {value!r}')
    return number


def close(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-12)


def wilson(k, n, z=1.959963984540054):
    require(0 <= k <= n and n > 0, 'invalid binomial counts')
    # Score-test quadratic roots, independently of either plotting adapter.
    root = z * math.sqrt(z*z + 4*k*(1-k/n))
    denominator = 2*(n+z*z)
    return (0. if k == 0 else max(0., (2*k+z*z-root)/denominator),
            1. if k == n else min(1., (2*k+z*z+root)/denominator))


def paired_statistics(n, final, feedback, both):
    cells = (both, final-both, feedback-both, n-final-feedback+both)
    require(n > 0 and all(isinstance(k, int) and k >= 0 for k in cells),
            'impossible paired joint counts')
    final_only, feedback_only = cells[1:3]
    delta = (feedback_only-final_only)/n
    low_a, high_a = wilson(feedback_only, n, 2.241402727604947)
    low_b, high_b = wilson(final_only, n, 2.241402727604947)
    fl, fh = wilson(final, n)
    sl, sh = wilson(feedback, n)
    return dict(final_only_only=final_only, slice_feedback_only=feedback_only,
                final_only_rate=final/n, final_only_ci_low=fl, final_only_ci_high=fh,
                slice_feedback_rate=feedback/n, slice_feedback_ci_low=sl,
                slice_feedback_ci_high=sh, difference_feedback_minus_final=delta,
                difference_standard_error=(math.sqrt(max(0.,
                    (final_only+feedback_only-n*delta*delta)/(n*(n-1)))) if n > 1 else math.nan),
                difference_ci_low=max(-1., low_a-high_b),
                difference_ci_high=min(1., high_a-low_b))


@lru_cache(maxsize=4096)
def _joint_feasible(n, final, feedback, both):
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    atoms = list(itertools.product((0,1),repeat=4))
    matrix = np.array([[1,a,b,a|b,c,d,c|d,a&c,b&d,(a|b)&(c|d)]
                       for a,b,c,d in atoms], dtype=float).T
    target = np.array([n,*final,*feedback,*both],dtype=float)
    # SciPy forwards unrecognized solver options to HiGHS. Its threads option
    # is set explicitly; suppress only the expected forwarding notification.
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Unrecognized options detected:.*threads.*', category=RuntimeWarning)
        solution = milp(np.zeros(16), integrality=np.ones(16), bounds=Bounds(0,n),
                        constraints=LinearConstraint(matrix,target,target), options={'threads':1})
    return bool(solution.success and np.array_equal(matrix@np.rint(solution.x), target))


def validate_joint_feasibility(n, final, feedback, both):
    require(_joint_feasible(n,tuple(final),tuple(feedback),tuple(both)),
            'aggregate logical counts have no common integer joint distribution')


def validate_shard(checkpoint, rows=None, metadata=None, expected=None):
    require(checkpoint['format_version'] == 1, 'checkpoint format')
    config = checkpoint['config']
    dims, rates = config['dimensions'], config['error_rates']
    shots = integer(config['shots'])
    require(shots > 0 and config['batch_size'] > 0, 'invalid requested shots/batch')
    require(all(len(d) == 3 and d[0] == d[1] == d[2] >= 2 for d in dims), 'geometry T=L')
    keys = [(tuple(d), float(p)) for d in dims for p in rates]
    require(len(keys) == len(set(keys)) and bool(keys), 'duplicate/empty checkpoint grid')
    require(all(math.isfinite(p) and 0 <= p <= 1 for p in rates), 'invalid rates')
    require(config['settings'] == SETTINGS, 'decoder settings differ')
    require(config['routing'] == 'one_step' and config['point_rng_type'] == 'Random.Xoshiro'
            and config['rng_type'] == 'Random.MersenneTwister', 'routing/RNG provenance')
    if expected:
        for field, value in expected.items():
            require(config.get(field) == value, f'frozen config differs: {field}')
    seeds, states = checkpoint['point_seeds'], checkpoint['states']
    require(len(keys) == len(seeds) == len(states), 'checkpoint grid/state count')
    require(all(re.fullmatch('[0-9a-f]{16}', s) for s in seeds), 'invalid UInt64 hex seed')
    require(len(set(seeds)) == len(seeds), 'duplicate point seed')
    require(math.isfinite(checkpoint['started_at_unix']), 'nonfinite start time')
    completed = {}
    total_pairs = 0
    for key, seed, state in zip(keys, seeds, states):
        n = integer(state['completed_shots'])
        require(0 <= n <= shots, 'invalid completed shot count')
        total_pairs += n
        vectors = [state[name] for name in ('final_counts', 'feedback_counts', 'both_counts')]
        require(all(len(v) == 3 for v in vectors), 'checkpoint metric count')
        final, feedback, both = [[integer(k) for k in v] for v in vectors]
        for arm in (final, feedback):
            overlap = arm[0]+arm[1]-arm[2]
            require(0 <= overlap <= min(arm[0], arm[1]) and arm[2] <= n,
                    'logical union algebra is impossible')
        require(max(both[0], both[1]) <= both[2], 'state joint count below logical joint count')
        for f, s, b in zip(final, feedback, both):
            require(min(b, f-b, s-b, n-f-s+b) >= 0, 'impossible checkpoint joint counts')
        validate_joint_feasibility(n,final,feedback,both)
        require(math.isfinite(state['elapsed_seconds']) and state['elapsed_seconds'] >= 0,
                'invalid elapsed time')
        if n:
            require(state['decoder_version'] == '2.4.1', 'checkpoint backend version')
        if key[1] == 0:
            require(not any(final+feedback+both), 'nonzero zero-noise failure count')
        if n == shots:
            completed[key] = (seed, state)
    if rows is not None:
        seen = set()
        for row in rows:
            key = ((integer(row['steps']), integer(row['Ly']), integer(row['Lz'])), float(row['p']))
            metric = row['metric']
            require((key, metric) not in seen, 'duplicate raw grid metric')
            seen.add((key, metric))
            require(key in completed and metric in METRICS, 'raw grid contains unexpected point')
            seed, state = completed[key]
            require(row['point_seed'] == seed, 'raw/checkpoint point seed identity')
            require(integer(row['seed']) == config['seed'], 'raw/master seed identity')
            require(integer(row['shots']) == shots, 'raw/checkpoint shots')
            require(integer(row['qubits']) == 3*(key[0][0]+1)*key[0][1]*key[0][2], 'qubit geometry')
            require(row['routing'] == config['routing'], 'raw routing')
            require(row['ldpc_version'] == state['decoder_version'], 'raw backend version')
            require(close(row['elapsed_seconds'], state['elapsed_seconds']), 'raw elapsed time')
            for field, value in SETTINGS.items():
                require(close(row[field], value) if isinstance(value, (int, float))
                        else row[field] == value, f'raw decoder {field}')
            index = METRICS.index(metric)
            counts = tuple(state[name][index] for name in ('final_counts', 'feedback_counts', 'both_counts'))
            require(tuple(integer(row[name]) for name in
                ('final_only_failures', 'slice_feedback_failures', 'both_failures')) == counts,
                'raw/checkpoint counts')
            for field, value in paired_statistics(shots, *counts).items():
                require(close(row[field], value), f'raw recomputation differs: {field}')
        require(seen == {(key, metric) for key in completed for metric in METRICS},
                'raw grid missing completed point or metric')
    if metadata is not None:
        mapping = dict(dimensions_steps_Ly_Lz='dimensions', error_rates='error_rates',
                       shots_per_point='shots', seed_metadata='seed', batch_size='batch_size',
                       routing='routing', rng_type='rng_type', point_rng_type='point_rng_type',
                       decoder_settings='settings')
        for field, source in mapping.items():
            require(metadata[field] == config[source], f'metadata config differs: {field}')
        require(metadata['point_seeds_hex'] == seeds, 'metadata point seed identity')
        require(close(metadata['started_at_unix'], checkpoint['started_at_unix']), 'metadata start time')
        require(metadata['completed_points'] == len(completed) and metadata['expected_points'] == len(keys)
                and metadata['complete'] == (len(completed) == len(keys)), 'metadata completeness')
        for field, value in dict(format_version=1, protocols=['final_only', 'slice_feedback'],
                active_gate_outputs_per_transfer_cell=13, seed_gate_fault_locations=0,
                logical_qubits=2, logical_diagnostics=list(METRICS), ldpc_versions=['2.4.1'],
                checkpoint_filename=STEM+'-checkpoint.toml').items():
            require(metadata[field] == value, f'metadata scope differs: {field}')
    return dict(complete=len(completed) == len(keys), completed_points=len(completed),
                expected_points=len(keys), completed_pairs=total_pairs,
                raw_rows=len(rows) if rows is not None else None,
                feasible_four_bit_joint_tables=len(states),
                point_seeds_hex=seeds)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_toml(path):
    return tomllib.loads(Path(path).read_text())


def load_csv(path):
    with Path(path).open(newline='') as stream:
        return list(csv.DictReader(stream))


def validate_provenance(selection, provenance, study, repo):
    source_hashes = provenance['source_hashes']
    expected_source = {str(p.relative_to(repo)) for p in (repo/'src').rglob('*.jl')}
    require(expected_source <= set(source_hashes), 'source manifest omits Julia source')
    require('document/note.tex' in source_hashes, 'source manifest omits note')
    for name, expected in source_hashes.items():
        require(digest(repo/name) == expected, f'source hash differs: {name}')
    commit = provenance['source_commit']
    require(re.fullmatch('[0-9a-f]{40}', commit), 'invalid source commit')
    committed_paths = set(subprocess.run(['git', '-C', str(repo), 'ls-tree', '-r', '--name-only', commit],
                                        check=True, capture_output=True, text=True).stdout.splitlines())
    require(expected_source <= committed_paths, 'uncommitted Julia source')
    committed_checks = 0
    for name in sorted(set(source_hashes) & committed_paths):
        blob = subprocess.run(['git', '-C', str(repo), 'show', f'{commit}:{name}'],
                              check=True, capture_output=True).stdout
        require(hashlib.sha256(blob).hexdigest() == source_hashes[name],
                f'recorded source commit hash differs: {name}')
        committed_checks += 1
    for name, expected in selection['pilot_sha256'].items():
        require(digest(study/'pilot-x'/name) == expected, f'frozen pilot hash differs: {name}')
    require(provenance['recorded_at_unix'] <= selection['frozen_at_unix'], 'provenance recorded after freeze')
    require(selection['channel'] == 'x_only' and selection['frozen_before_production'] is True,
            'selection channel or freeze status')
    require(selection['pilot_excluded_from_production'] is True, 'pilot exclusion')
    require(selection['fit_policy_source_sha256'] == source_hashes[selection['fit_policy_source']],
            'frozen fit policy source hash')
    sizes = [size for shard in selection['shards'].values() for size in shard['sizes']]
    require(sorted(sizes) == sorted(selection['sizes']) and len(sizes) == len(set(sizes)),
            'frozen shard size partition')
    require(selection['total_paired_shots'] == len(sizes)*len(selection['rates'])*selection['paired_shots_per_point'],
            'frozen total paired shots')
    for name in selection['shards']:
        execution = json.loads((study/name/'execution.json').read_text())
        require(selection['frozen_at_unix'] <= execution['started_at_unix'], 'freeze occurs after execution start')
        single_thread = execution.get('single_thread') is True or all(
            execution.get('environment', {}).get(key) == '1' for key in
            ('JULIA_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'))
        require(commit.startswith(execution['source_commit']) and single_thread,
                'execution source/thread declaration')
        checkpoint = study/name/(STEM+'-checkpoint.toml')
        if checkpoint.exists():
            require(load_toml(checkpoint)['started_at_unix'] >= execution['started_at_unix'],
                    'checkpoint starts before execution declaration')
    require(provenance['packages']['ldpc'] == '2.4.1' and provenance['packages']['pymatching'] == '2.4.0',
            'backend pins')
    require('Z-type Q' in provenance['metadata_correction'] and
            'before transfer' in provenance['metadata_correction'], 'metadata correction missing')
    return dict(source_hashes_checked=len(source_hashes), committed_source_blobs_checked=committed_checks,
                pilot_hashes_checked=len(selection['pilot_sha256']), source_commit=commit,
                note_sha256=source_hashes['document/note.tex'],
                hash_only_files=sorted(set(source_hashes)-committed_paths),
                current_file_mtimes_observation_only={name: (study/name).stat().st_mtime
                    for name in ('selection.json', 'provenance.json')})


def validate_publication_state(fit):
    require(set(fit['guards']) == GUARDS and all(type(v) is bool for v in fit['guards'].values()),
            'fit guard set incomplete or malformed')
    failed = [name for name, passed in fit['guards'].items() if not passed]
    require(fit['failed_guards'] == failed, 'failed guard listing differs')
    if failed:
        require(fit['status'] == 'diagnostic_only' and fit['pc'] is None and fit['nu'] is None,
                'publication of threshold despite failed guard')
    else:
        require(fit['status'] == 'accepted' and fit['candidate'] is not None and
                fit['pc'] == fit['candidate']['pc'] and fit['nu'] == fit['candidate']['nu'],
                'publication state disagrees with accepted candidate')


def common_crossings(points):
    sizes = sorted({r['steps'] for r in points})
    rates = sorted({r['p'] for r in points})
    observed = {(r['steps'], r['p']): r['failures']/r['shots'] for r in points}
    common = [[rates[0], rates[-1]]]
    for first, second in zip(sizes, sizes[1:]):
        difference = [observed[second,p]-observed[first,p] for p in rates]
        intervals = [[rates[i], rates[i+1]] for i in range(len(rates)-1)
                     if difference[i]*difference[i+1] < 0]
        intervals += [[rates[i-1], rates[i+1]] for i in range(1, len(rates)-1)
                      if difference[i] == 0 and difference[i-1]*difference[i+1] < 0]
        common = [[max(a,c), min(b,d)] for a,b in common for c,d in intervals if max(a,c) <= min(b,d)]
    merged = []
    for low, high in sorted(common):
        if merged and low <= merged[-1][1]:
            merged[-1][1] = max(high, merged[-1][1])
        else:
            merged.append([low,high])
    return merged


def quantile(values, fraction):
    values = sorted(values)
    index = (len(values)-1)*fraction
    lower = int(index)
    return values[lower]+(index-lower)*(values[min(lower+1,len(values)-1)]-values[lower])


def validate_bootstrap(boot, replicates, seed):
    require(boot['replicates'] == replicates and boot['seed'] == seed, 'bootstrap frozen settings')
    samples = boot['samples']
    require([s['replicate'] for s in samples] == list(range(len(samples)))
            and len(samples) in (0, replicates), 'bootstrap sample grid')
    for sample in samples:
        require(type(sample['accepted']) is bool and sample['accepted'] == (not sample['failed_guards']),
                'bootstrap sample guard status')
        if sample['accepted']:
            require(all(math.isfinite(sample[k]) for k in ('pc','nu')), 'invalid accepted bootstrap sample')
    accepted = [s for s in samples if s['accepted']]
    require(boot['accepted'] == len(accepted), 'bootstrap accepted count')
    for field in ('pc', 'nu'):
        expected = [quantile([s[field] for s in accepted], q) for q in (.025, .975)] if len(accepted) >= 2 else None
        actual = boot[field+'_interval']
        require(actual is None if expected is None else actual is not None and len(actual) == 2 and
                all(close(a,b) for a,b in zip(actual,expected)), 'bootstrap '+field+' interval mismatch')


def reconstruct_candidate(rows, candidate):
    """Reconstruct probabilities, likelihood diagnostics and bounds from counts.

    Only SciPy's chi-square survival distribution is shared as a numerical
    dependency; no likelihood, fitting or plotting code is imported.
    """
    from scipy.stats import chi2
    checks = {}
    try:
        close = lambda a, b: math.isfinite(float(a)) and math.isfinite(float(b)) and math.isclose(a, b, rel_tol=1e-8, abs_tol=1e-10)
        points = sorted(rows, key=lambda r: (int(r["Ly"]), float(r["p"])))
        rates = [float(r["p"]) for r in points]
        sizes = sorted({int(r["Ly"]) for r in points})
        low, high = min(rates), max(rates)
        scale = high - low
        reference = math.exp(math.fsum(math.log(v) for v in sizes) / len(sizes))
        pc, nu = candidate["pc"], candidate["nu"]
        coefficients = candidate["coefficients"]
        degree = candidate["polynomial_degree"]
        correction = candidate["correction_coefficient"]
        has_correction = correction is not None
        checks["model_geometry"] = (degree in (2, 3) and len(coefficients) == degree + 1 and scale > 0 and nu > 0 and
            close(low, candidate["p_min"]) and close(high, candidate["p_max"]) and close(scale, candidate["p_scale"]) and
            close(reference, candidate["L_reference"]) and candidate["nu_bounds"] == [.3, 5.] and
            candidate["correction_omega"] == (1.0 if has_correction else None))
        parameters = candidate["parameters"]
        expected_parameters = [(pc - low) / scale, math.log(nu), *coefficients] + ([correction] if has_correction else [])
        checks["parameter_encoding"] = len(parameters) == len(expected_parameters) and all(
            close(a, b) for a, b in zip(parameters, expected_parameters))
        x_values, probabilities = [], []
        for row in points:
            x = ((float(row["p"]) - pc) / scale) * (int(row["Ly"]) / reference) ** (1 / nu)
            x_values.append(x)
            eta = math.fsum(coefficient * x ** power for power, coefficient in enumerate(coefficients))
            if has_correction:
                eta += correction * reference / int(row["Ly"])
            q = 1 / (1 + math.exp(-eta)) if eta >= 0 else math.exp(eta) / (1 + math.exp(eta))
            probabilities.append(q)
        saved_probabilities = candidate["fitted_probabilities"]
        checks["fitted_probabilities"] = len(probabilities) == len(saved_probabilities) and all(
            close(a, b) for a, b in zip(probabilities, saved_probabilities))
        terms = []
        for row, q in zip(points, probabilities):
            n, k = int(row["shots"]), int(row["failures"])
            safe = min(1 - 1e-14, max(1e-14, q))
            terms.append(k * math.log((k / n) / safe) if k else 0.)
            terms.append((n - k) * math.log(((n - k) / n) / (1 - safe)) if k < n else 0.)
        deviance = 2 * math.fsum(terms)
        dof = len(points) - (degree + 3 + int(has_correction))
        goodness = float(chi2.sf(deviance, dof)) if dof > 0 else None
        # Log-ratio cancellation near a saturated fit is amplified by counts.
        roundoff = max(1e-10, 64 * math.ulp(1.) * sum(int(r["shots"]) for r in points))
        checks["deviance"] = math.isclose(deviance, candidate["deviance"], rel_tol=1e-8, abs_tol=roundoff)
        checks["degrees_of_freedom"] = dof == candidate["degrees_of_freedom"]
        probability_range = [float(chi2.sf(max(0., deviance + roundoff), dof)),
                             float(chi2.sf(max(0., deviance - roundoff), dof))] if dof > 0 else None
        checks["goodness_probability"] = (candidate["deviance_p_value"] is None if goodness is None else
            probability_range[0] - 1e-10 <= candidate["deviance_p_value"] <= probability_range[1] + 1e-10)
        derivative_points = [min(x_values), max(x_values)]
        if degree == 3 and coefficients[3] != 0:
            vertex = -coefficients[2] / (3 * coefficients[3])
            if derivative_points[0] < vertex < derivative_points[1]:
                derivative_points.append(vertex)
        derivative_min = min(math.fsum(power * coefficients[power] * x ** (power - 1)
                                      for power in range(1, len(coefficients))) for x in derivative_points)
        checks["monotonicity"] = close(derivative_min, candidate["derivative_min"]) and candidate["monotone_increasing"] == (derivative_min > 1e-7)
        bounds = [(0., 1.), (math.log(.3), math.log(5.)), (-15., 15.)] + [(-30., 30.)] * degree
        names = ["pc", "nu"] + [f"a{i}" for i in range(degree + 1)]
        if has_correction:
            bounds.append((-15., 15.))
            names.append("correction_omega1")
        hits = [name for name, value, (a, b) in zip(names, parameters, bounds)
                if min(value - a, b - value) <= .002 * (b - a)]
        checks["bound_hits"] = hits == candidate["bound_hits"]
        return dict(passed=all(checks.values()), checks=checks, deviance=deviance,
                    degrees_of_freedom=dof, deviance_p_value=goodness,
                    deviance_roundoff_tolerance=roundoff,
                    maximum_probability_difference=max((abs(a - b) for a, b in zip(probabilities, saved_probabilities)), default=None))
    except (KeyError, TypeError, ValueError, ZeroDivisionError, OverflowError) as error:
        return dict(passed=False, checks=checks, error=str(error))


def numerical_guards(candidate):
    if candidate is None:
        return dict(interior_optimizer=False, monotonicity=False, goodness_of_fit=False)
    return dict(interior_optimizer=bool(candidate['optimizer_success'] and not candidate['bound_hits']
                    and candidate['p_min'] < candidate['pc'] < candidate['p_max']),
                monotonicity=candidate['monotone_increasing'],
                goodness_of_fit=bool(candidate['degrees_of_freedom'] > 0 and candidate['deviance_p_value'] >= .01))


def validate_fit_evidence(rows, fit, selection, protocol):
    rows = sorted([r for r in rows if r['p'] > 0], key=lambda r: (r['steps'],r['p']))
    sizes, rates = sorted({r['steps'] for r in rows}), sorted({r['p'] for r in rows})
    require(fit['channel'] == 'x_only' and fit['protocol'] == protocol, 'fit channel/protocol')
    require(fit['sizes'] == sizes and fit['rates'] == rates, 'fit input grid differs')
    validate_publication_state(fit)
    candidate, boot = fit['candidate'], fit['bootstrap']
    reconstructions = {}
    if candidate is not None:
        require(candidate['polynomial_degree'] == 2 and candidate['correction_coefficient'] is None,
                'primary model differs from frozen policy')
        reconstructed = reconstruct_candidate(rows, candidate)
        require(reconstructed['passed'], f'primary candidate reconstruction: {reconstructed}')
        reconstructions['primary'] = reconstructed
    expected = dict(grid_resolution=len(sizes) >= 4 and len(rates) >= 5, **numerical_guards(candidate))
    clusters = common_crossings(rows)
    require(fit['crossing_common_brackets'] == clusters, 'reported crossing clusters differ')
    expected['crossings'] = bool(len(sizes) >= 2 and len(clusters) == 1 and candidate is not None
                                and clusters[0][0] <= candidate['pc'] <= clusters[0][1])
    validate_bootstrap(boot, selection['bootstrap_replicates'], selection['bootstrap_seeds'][protocol])
    pc_interval, nu_interval = boot['pc_interval'], boot['nu_interval']
    expected['bootstrap'] = bool(boot['replicates'] >= 20 and boot['accepted'] >= math.ceil(.8*boot['replicates'])
        and pc_interval is not None and nu_interval is not None
        and rates[0] < pc_interval[0] < pc_interval[1] < rates[-1]
        and .3 < nu_interval[0] < nu_interval[1] < 5.)
    require([s['name'] for s in fit['sensitivity']] == list(VARIANTS), 'sensitivity variants differ')
    for sensitivity in fit['sensitivity']:
        name = sensitivity['name']
        selected = [r for r in rows if (name != 'drop_smallest' or r['steps'] != sizes[0])
                    and (name != 'narrow_window' or rates[0] < r['p'] < rates[-1])]
        enough = len({r['steps'] for r in selected}) >= 4 and len({r['p'] for r in selected}) >= 5
        fitted = sensitivity['candidate']
        if fitted is not None:
            require(enough and fitted['polynomial_degree'] == (3 if name == 'cubic' else 2)
                    and (fitted['correction_coefficient'] is not None) == (name == 'inverse_L_correction'),
                    'sensitivity model/grid differs: '+name)
            reconstruction = reconstruct_candidate(selected, fitted)
            require(reconstruction['passed'], f'{name} reconstruction: {reconstruction}')
            reconstructions[name] = reconstruction
        checks = numerical_guards(fitted)
        require(sensitivity['guards'] == checks and sensitivity['sufficient_grid'] == enough,
                'sensitivity numerical guards differ: '+name)
        stable = False
        if fitted is not None and candidate is not None:
            pc_tolerance = max(.1*(rates[-1]-rates[0]), pc_interval[1]-pc_interval[0] if pc_interval else 0.)
            nu_tolerance = max(.25*candidate['nu'], nu_interval[1]-nu_interval[0] if nu_interval else 0.)
            require(close(sensitivity['pc_tolerance'], pc_tolerance) and close(sensitivity['nu_tolerance'], nu_tolerance),
                    'sensitivity tolerance differs: '+name)
            stable = abs(fitted['pc']-candidate['pc']) <= pc_tolerance and abs(fitted['nu']-candidate['nu']) <= nu_tolerance
        else:
            require(sensitivity['pc_tolerance'] is None and sensitivity['nu_tolerance'] is None,
                    'unavailable sensitivity has tolerance')
        passed = enough and all(checks.values()) and stable
        require(sensitivity['stable'] == stable and sensitivity['passed'] == passed,
                'sensitivity acceptance differs: '+name)
        expected['sensitivity_'+name] = bool(passed)
    for name, value in expected.items():
        require(fit['guards'][name] == value, 'fit guard disagrees with evidence: '+name)
    return dict(status=fit['status'], failed_guards=fit['failed_guards'], candidate_reconstructions=reconstructions)


def validate_table(path, expected):
    rows = load_csv(path)
    require(len(rows) == len(expected), f'{path.name}: row count differs')
    for index, (row, target) in enumerate(zip(rows, expected)):
        require(set(row) == set(target), f'{path.name}: column set differs')
        for field, value in target.items():
            actual = row[field]
            if value is None:
                same = actual == ''
            elif isinstance(value, (list, dict)):
                same = json.loads(actual) == value
            elif isinstance(value, bool):
                same = actual.lower() == str(value).lower()
            elif isinstance(value, (int, float)):
                same = close(actual, value)
            else:
                same = actual == value
            require(same, f'{path.name}: row {index} field {field} differs')
    return len(rows)


def validate_analysis(study, raw_rows, selection, provenance):
    folder, repo = study/'analysis', study.parents[1]
    report = json.loads((folder/'report.json').read_text())
    require(report['channel'] == 'x_only' and report['circuit'] == 'legacy H+6-CNOT' and
            report['geometry'] == 'T=L' and report['protocols'] == ['final_only','one_step'] and
            set(report['fits']) == {'final_only','one_step'}, 'analysis protocol scope')
    require(report['threshold_difference'] is None, 'unsupported threshold-difference inference')
    require(report['frozen_selection'] == selection and report['study_provenance'] == provenance,
            'analysis frozen provenance payload differs')
    for name in ('selection.json','provenance.json'):
        require(report['study_hashes'][name] == digest(study/name), 'analysis study hash differs: '+name)
    for relative, expected in report['analysis_hashes'].items():
        require(digest(repo/relative) == expected, 'analysis source hash differs: '+relative)
    expected_analysis = {str((folder/'analyze.py').relative_to(repo)), 'examples/fit_toric3d_h6_threshold.py',
                         'examples/fit_toric3d_diagonal_feedback.py'}
    require(set(report['analysis_hashes']) == expected_analysis, 'analysis source hash coverage')
    tree = ast.parse((repo/selection['fit_policy_source']).read_text())
    policy = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'GUARD_POLICY' for target in node.targets))
    require(report['guard_policy'] == policy, 'analysis guard policy differs from frozen source')
    require(report['bootstrap_seed'] == selection['bootstrap_seeds']['final_only'], 'analysis bootstrap master seed')
    require(report['legacy_metadata_correction'] == provenance['metadata_correction'] and
            'Z-type Q' in report['measured_checks'], 'analysis metadata interpretation')
    require(all(v == '1' for v in report['thread_environment'].values()) and
            set(report['thread_environment']) == {'OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'},
            'analysis thread declaration')
    require(report['python_executable'] == provenance['python_executable'] and
            all(report['versions'][k] == provenance['packages'][k] for k in ('numpy','scipy','matplotlib')),
            'analysis environment differs')
    require(len(report['inputs']) == len(selection['shards']) and
            {Path(item['directory']).name for item in report['inputs']} == set(selection['shards']), 'analysis input attribution')
    expected_metadata = []
    for item in report['inputs']:
        shard = study/Path(item['directory']).name
        require(set(item['hashes']) == {STEM+'-'+suffix for suffix in ('raw.csv','metadata.toml','checkpoint.toml')},
                'analysis input hash coverage')
        for name, expected in item['hashes'].items():
            require(digest(shard/name) == expected, 'analysis input hash differs: '+name)
        expected_metadata.append(load_toml(shard/(STEM+'-metadata.toml')))
    require(report['input_metadata'] == expected_metadata, 'analysis metadata differs from inputs')
    grouped = {}
    for row in raw_rows:
        grouped.setdefault((int(row['steps']),float(row['p'])), {})[row['metric']] = row
    margins, comparisons, reconstructed = [], [], {}
    for protocol, column in (('final_only','final_only_failures'), ('one_step','slice_feedback_failures')):
        fit_rows = []
        for (size,p), metrics in sorted(grouped.items()):
            row = metrics['state_failure']
            n, k = int(row['shots']), int(row[column])
            low, high = wilson(k,n)
            margin = dict(protocol=protocol, channel='x_only', steps=size, Ly=size, Lz=size, p=p,
                shots=n, failures=k, logical_1_failures=int(metrics['logical_1'][column]),
                logical_2_failures=int(metrics['logical_2'][column]), seed=int(row['seed']),
                point_seed=row['point_seed'], decoder='BP+OSD', complete=True,
                elapsed_seconds=float(row['elapsed_seconds']), rate=k/n, ci_low=low, ci_high=high)
            margins.append(margin)
            fit_rows.append(margin)
        reconstructed[protocol] = validate_fit_evidence(fit_rows, report['fits'][protocol], selection, protocol)
    for (size,p), metrics in sorted(grouped.items()):
        row = metrics['state_failure']
        n,f,s,b = [int(row[k]) for k in ('shots','final_only_failures','slice_feedback_failures','both_failures')]
        stats = paired_statistics(n,f,s,b)
        comparisons.append(dict(L=size,p=p,shots=n,base_seed=int(row['seed']),point_seed=row['point_seed'],
            neither=n-f-s+b,both=b,final_only_only=f-b,one_step_only=s-b,
            difference=stats['difference_feedback_minus_final'],standard_error=stats['difference_standard_error'],
            ci_low=stats['difference_ci_low'],ci_high=stats['difference_ci_high']))
    table_counts = {}
    for name, expected in [('points.csv',margins), ('paired-differences.csv',comparisons),
        ('bootstrap-samples.csv',[dict(protocol=p, **s) for p,fit in report['fits'].items() for s in fit['bootstrap']['samples']]),
        ('sensitivity-fits.csv',[dict(protocol=p, **s) for p,fit in report['fits'].items() for s in fit['sensitivity']])]:
        table_counts[name] = validate_table(folder/name,expected)
    files = [folder/name for name in ('report.json', *table_counts)]
    for stem in ('x-one-step-failure-rates','x-one-step-paired-differences'):
        for suffix, signature in (('png',b'\x89PNG'),('pdf',b'%PDF'),('svg',b'<?xml')):
            path = folder/(stem+'.'+suffix)
            require(path.read_bytes().startswith(signature), 'missing/invalid plot: '+path.name)
            files.append(path)
    return dict(fits=reconstructed, table_rows=table_counts,
                output_hashes={p.name:digest(p) for p in files})


def validate_snapshots(folder, current):
    directory = folder/'checkpoint-snapshots'
    ledger_path = directory/'ledger.json'
    index_path = directory/'index.jsonl'
    if ledger_path.exists():
        ledger = json.loads(ledger_path.read_text())
    elif index_path.exists():
        ledger_path = index_path
        indexed = [json.loads(line) for line in index_path.read_text().splitlines() if line.strip()]
        ledger = dict(scope='Observed immutable snapshots; not every batch was captured.', snapshots=[
            dict(entry, observed_at_unix=entry['captured_at_unix'], paired_samples=sum(entry['completed_shots']))
            for entry in indexed])
    else:
        return dict(snapshots_checked=0, scope='No observed snapshots supplied.')
    previous, previous_time, hashes = None, -math.inf, {}
    last_pairs = 0
    for entry in ledger['snapshots']:
        path = directory/entry['path']
        require(path.parent == directory and path.name not in hashes, 'snapshot path/duplicate')
        require(digest(path) == entry['sha256'], 'snapshot hash differs: '+path.name)
        hashes[path.name] = entry['sha256']
        saved = load_toml(path)
        result = validate_shard(saved)
        require(result['completed_pairs'] == entry['paired_samples'], 'snapshot ledger pair count')
        if 'completed_shots' in entry:
            require(entry['completed_shots'] == [s['completed_shots'] for s in saved['states']],
                    'snapshot index per-point count')
        require(previous_time <= entry['observed_at_unix'] and
                saved['started_at_unix'] <= entry['observed_at_unix'], 'snapshot observation order')
        for key in ('config','point_seeds','started_at_unix'):
            require(saved[key] == current[key], 'snapshot immutable provenance differs: '+key)
        comparisons = [(saved,current)] + ([(previous,saved)] if previous else [])
        for older, newer in comparisons:
            for left, right in zip(older['states'],newer['states']):
                require(left['completed_shots'] <= right['completed_shots'], 'snapshot completed count decreased')
                for key in ('final_counts','feedback_counts','both_counts'):
                    require(all(a <= b for a,b in zip(left[key],right[key])), 'snapshot metric count decreased')
        previous, previous_time, last_pairs = saved, entry['observed_at_unix'], entry['paired_samples']
    return dict(snapshots_checked=len(hashes), latest_observed_pairs=last_pairs,
                scope=ledger['scope'], hashes=hashes, ledger_sha256=digest(ledger_path))


def validate_replay(evidence, folder, provenance):
    require(evidence['status'] == 'passed' and evidence['all_point_seeds_verified'] is True,
            'replay status/seed regeneration')
    for field, suffix in (('raw_sha256','raw.csv'), ('metadata_sha256','metadata.toml'),
                          ('checkpoint_sha256','checkpoint.toml')):
        require(digest(folder/(STEM+'-'+suffix)) == evidence[field], 'replay input hash differs: '+field)
    require(evidence['source_commit'] == provenance['source_commit'] and
            evidence['source_files_verified'] == len(provenance['source_hashes']), 'replay source provenance')
    require(evidence['julia_threads'] == evidence['blas_threads'] == 1 and evidence['julia_version'] == '1.12.6'
            and evidence['ldpc_version'] == '2.4.1' and evidence['decoder_settings'] == SETTINGS and
            evidence['python_executable'] == provenance['python_executable'], 'replay runtime/decoder')
    require(evidence['metric_order'] == list(METRICS), 'replay metric ordering')
    cp = load_toml(folder/(STEM+'-checkpoint.toml'))
    grid = [(d[0],p) for d in cp['config']['dimensions'] for p in cp['config']['error_rates']]
    index = grid.index((evidence['L'],evidence['p']))
    require(evidence['point_seed_hex'] == cp['point_seeds'][index] and
            evidence['shots'] == cp['states'][index]['completed_shots'], 'replay point identity')
    for field in ('final_counts','feedback_counts','both_counts'):
        require(evidence[field] == cp['states'][index][field], 'replay counts differ: '+field)
    return dict(shard=folder.name, L=evidence['L'], p=evidence['p'],
                paired_shots_replayed=evidence['shots'], all_point_seeds_regenerated=len(grid),
                final_counts=evidence['final_counts'], feedback_counts=evidence['feedback_counts'],
                both_counts=evidence['both_counts'])


def audit_study(study, require_complete=False):
    study = Path(study).resolve()
    repo = study.parents[1]
    report = dict(format_version=1, audited_at_unix=time.time(), study=str(study),
                  auditor_sha256=digest(__file__), checks=[], errors=[], pending=[], shards={}, hashes={})
    selection = json.loads((study/'selection.json').read_text())
    provenance = json.loads((study/'provenance.json').read_text())
    for name in ('selection.json', 'provenance.json'):
        report['hashes'][name] = digest(study/name)
    def check(name, action):
        try:
            result = action()
            report['checks'].append(dict(name=name, passed=True))
            return result
        except (ValueError, KeyError, TypeError, OSError, subprocess.SubprocessError) as error:
            report['checks'].append(dict(name=name, passed=False))
            report['errors'].append(f'{name}: {error}')
            return None
    report['provenance'] = check('frozen provenance',
        lambda: validate_provenance(selection, provenance, study, repo))
    all_seeds, production_pairs, production_points = [], 0, 0
    production_rows = []
    for name in ['pilot-x', *selection['shards']]:
        folder = study/name
        cp_path, raw_path, meta_path = [folder/(STEM+'-'+suffix)
                                      for suffix in ('checkpoint.toml', 'raw.csv', 'metadata.toml')]
        if not cp_path.exists():
            report['pending'].append(name)
            continue
        # One atomic checkpoint snapshot; no reread during the count validation.
        checkpoint_bytes = cp_path.read_bytes()
        checkpoint = tomllib.loads(checkpoint_bytes.decode())
        rows = load_csv(raw_path) if raw_path.exists() else None
        meta = load_toml(meta_path) if meta_path.exists() else None
        expected = None
        if name != 'pilot-x':
            shard = selection['shards'][name]
            expected = dict(dimensions=[[s,s,s] for s in shard['sizes']],
                            error_rates=selection['rates'], shots=selection['paired_shots_per_point'],
                            seed=shard['seed'])
        result = check(name+' counts/statistics', lambda: validate_shard(checkpoint, rows, meta, expected))
        for path in (cp_path, raw_path, meta_path):
            if path.exists():
                report['hashes'][str(path.relative_to(study))] = (hashlib.sha256(checkpoint_bytes).hexdigest()
                                                               if path == cp_path else digest(path))
        if result:
            report['shards'][name] = result
            result['snapshot_audit'] = check(name+' observed snapshots', lambda: validate_snapshots(folder,checkpoint))
            all_seeds.extend(result['point_seeds_hex'])
            if not result['complete'] or rows is None or meta is None:
                report['pending'].append(name)
            if name != 'pilot-x':
                production_pairs += result['completed_pairs']
                production_points += result['completed_points']
                if rows:
                    production_rows.extend(rows)
    check('cross-shard point seeds', lambda: require(len(all_seeds) == len(set(all_seeds)), 'duplicate seed'))
    report['production_completed_pairs'] = production_pairs
    report['production_completed_points'] = production_points
    report['replay_evidence'] = {}
    for filename, shard in (('replay-pilot-point.toml','pilot-x'),
                            ('replay-L9-p015.toml','production-small'), ('replay-L11-p015.toml','production-L11')):
        path = study/'verification'/filename
        if path.exists():
            report['replay_evidence'][filename] = check(filename, lambda: validate_replay(load_toml(path),study/shard,provenance))
            report['hashes']['verification/'+filename] = digest(path)
        else:
            report['pending'].append('replay:'+shard)
    replay_script = study/'verification'/'replay-point.jl'
    if replay_script.exists():
        report['hashes']['verification/replay-point.jl'] = digest(replay_script)
    if require_complete:
        check('complete frozen production', lambda: require(not report['pending'] and
            production_pairs == selection['total_paired_shots'], 'production incomplete'))
    if (study/'analysis'/'report.json').exists():
        report['analysis'] = check('analysis numerical evidence and exports',
            lambda: validate_analysis(study, production_rows, selection, provenance))
    else:
        report['pending'].append('analysis')
        if require_complete:
            check('analysis available', lambda: require(False, 'analysis not written'))
    report['passed'] = not report['errors']
    report['complete'] = not report['pending']
    report['limitations'] = [
        'Recorded hashes and recorded timestamps establish artifact consistency; they are not external timestamp attestations. Current file mtimes are observations only.',
        'Python checks exact saved hexadecimal seed identities, not Julia RNG generation; separate Julia replay supplies that evidence.',
        'Aggregate unions and per-metric paired tables do not retain the full per-shot four-logical-bit joint distribution.',
        'Thread settings are recorded configuration/provenance, not a continuous operating-system trace.',
        'Candidate probabilities, deviance, bounds, monotonicity and guard decisions are reconstructed; optimizer convergence flags and bootstrap sample fits are not independently rerun.',
    ]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-dir', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--require-complete', action='store_true')
    args = parser.parse_args()
    report = audit_study(args.study_dir, args.require_complete)
    output = args.output or args.study_dir/'verification'/'audit.json'
    output.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: report[key] for key in ('passed', 'complete', 'production_completed_points',
                     'production_completed_pairs', 'pending', 'errors')}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
