# Independent orchestration: regenerate point seeds and replay both arms directly
# through the validated core APIs, without invoking the scan or pair helpers.
using TopoNoise, Random, Test, LinearAlgebra
import TOML, SHA, PythonCall

length(ARGS) == 4 || error("usage: replay-point.jl <shard-dir> <L> <p> <output-toml>")
const SHARD_DIRECTORY = abspath(ARGS[1])
const STUDY = dirname(SHARD_DIRECTORY)
const REPOSITORY = dirname(dirname(STUDY))
const SELECTED_L = parse(Int,ARGS[2])
const SELECTED_P = parse(Float64,ARGS[3])
const OUTPUT_TOML = abspath(ARGS[4])
const CHECKPOINT = joinpath(SHARD_DIRECTORY,"toric3d-x-feedback-checkpoint.toml")
const METADATA = joinpath(SHARD_DIRECTORY,"toric3d-x-feedback-metadata.toml")
const RAW = joinpath(SHARD_DIRECTORY,"toric3d-x-feedback-raw.csv")
const RESULT = Dict{String,Any}()

@testset "Independent H+6 one-step point seeds and paired replay" begin
    @test VERSION == v"1.12.6"
    @test Threads.nthreads() == 1
    @test BLAS.get_num_threads() == 1
    for variable in ("JULIA_NUM_THREADS","OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","VECLIB_MAXIMUM_THREADS")
        @test get(ENV,variable,"") == "1"
    end
    @test get(ENV,"JULIA_CONDAPKG_BACKEND","") == "Null"
    provenance=PythonCall.pyimport("json").loads(read(joinpath(STUDY,"provenance.json"),String))
    source_hashes=PythonCall.pyconvert(Dict{String,String},provenance["source_hashes"])
    for (relative,expected_hash) in source_hashes
        actual=bytes2hex(SHA.sha256(read(joinpath(REPOSITORY,relative))))
        @test actual == expected_hash
        actual == expected_hash || error("frozen source hash mismatch: "*relative)
    end
    python_executable=PythonCall.pyconvert(String,PythonCall.pyimport("sys").executable)
    @test realpath(python_executable) == realpath(PythonCall.pyconvert(String,provenance["python_executable"]))
    checkpoint_bytes=read(CHECKPOINT)
    checkpoint=TOML.parse(String(copy(checkpoint_bytes)))
    metadata=TOML.parsefile(METADATA)
    config=checkpoint["config"]
    @test config["shots"] > 0
    @test config["batch_size"] > 0
    @test config["routing"] == "one_step"
    @test metadata["complete"]
    @test all(s["completed_shots"] == config["shots"] for s in checkpoint["states"])
    point_grid=[(Tuple(Int.(dims)),Float64(p)) for dims in config["dimensions"] for p in config["error_rates"]]
    @test all(dims[1] == dims[2] == dims[3] for (dims,p) in point_grid)
    @test length(checkpoint["states"]) == length(point_grid)
    seeds=rand(MersenneTwister(config["seed"]),UInt64,length(point_grid))
    encoded=[string(s;base=16,pad=16) for s in seeds]
    @test encoded == checkpoint["point_seeds"] == metadata["point_seeds_hex"]

    csv=PythonCall.pyimport("csv")
    string_io=PythonCall.pyimport("io").StringIO(read(RAW,String))
    rows=PythonCall.pyconvert(Vector{Dict{String,String}},
        PythonCall.pyimport("builtins").list(csv.DictReader(string_io)))
    @test length(rows) == 3length(point_grid)
    for (i,(dims,p)) in enumerate(point_grid)
        matched=filter(r -> (parse(Int,r["steps"]),parse(Int,r["Ly"]),parse(Int,r["Lz"])) == dims && parse(Float64,r["p"]) == p,rows)
        @test length(matched) == 3
        for (metric_index,metric_name) in enumerate(("logical_1","logical_2","state_failure"))
            row=only(filter(r -> r["metric"] == metric_name,matched))
            @test row["point_seed"] == encoded[i]
            @test parse(Int,row["shots"]) == config["shots"]
            @test parse(Int,row["final_only_failures"]) == checkpoint["states"][i]["final_counts"][metric_index]
            @test parse(Int,row["slice_feedback_failures"]) == checkpoint["states"][i]["feedback_counts"][metric_index]
            @test parse(Int,row["both_failures"]) == checkpoint["states"][i]["both_counts"][metric_index]
        end
    end

    # Freeze the representative point before looking at its failure counts.
    index=findfirst(==(((SELECTED_L,SELECTED_L,SELECTED_L),SELECTED_P)),point_grid)
    index === nothing && error("selected L,p pair is absent from shard grid")
    p=SELECTED_P
    shots=config["shots"]
    code=Toric3DEncodedSlice(SELECTED_L,SELECTED_L,SELECTED_L)
    encoder=toric3d_encoded_encoder(code)
    intermediate=build_toric3d_slice_decoder(code.lattice)
    settings=Toric3DDecoderSettings(; (Symbol(k)=>v for (k,v) in config["settings"])...)
    final_decoder=build_toric3d_x_threshold_decoder(code;p,settings)
    rng=Random.Xoshiro(seeds[index])
    final_counts=zeros(Int,3)
    feedback_counts=zeros(Int,3)
    both_counts=zeros(Int,3)
    println("Replaying L=",SELECTED_L," p=",p,", ",shots," paired shots, seed=",encoded[index])
    flush(stdout)
    elapsed=@elapsed for shot in 1:shots
        faults=sample_toric3d_faults(rng,encoder;p_x=p,p_z=0.0)
        baseline=replay_toric3d_slice(encoder,faults,intermediate;feedback=false,routing=:one_step)
        feedback=replay_toric3d_slice(encoder,faults,intermediate;feedback=true,routing=:one_step)
        final_outcome=toric3d_x_threshold_outcome(final_decoder,baseline.frame.x)
        feedback_outcome=toric3d_x_threshold_outcome(final_decoder,feedback.frame.x)
        final_flags=[final_outcome.logical_1,final_outcome.logical_2,final_outcome.failure]
        feedback_flags=[feedback_outcome.logical_1,feedback_outcome.logical_2,feedback_outcome.failure]
        final_counts .+= final_flags
        feedback_counts .+= feedback_flags
        both_counts .+= final_flags .& feedback_flags
        if shot % 100 == 0
            println("Independent paired replay: ",shot,"/",shots)
            flush(stdout)
        end
    end
    @test final_counts == checkpoint["states"][index]["final_counts"]
    @test feedback_counts == checkpoint["states"][index]["feedback_counts"]
    @test both_counts == checkpoint["states"][index]["both_counts"]
    @test read(CHECKPOINT) == checkpoint_bytes
    merge!(RESULT,Dict("status"=>"passed","L"=>SELECTED_L,"p"=>p,"shots"=>shots,
        "source_commit"=>PythonCall.pyconvert(String,provenance["source_commit"]),
        "source_files_verified"=>length(source_hashes),"python_executable"=>python_executable,
        "julia_threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),
        "point_seed_hex"=>encoded[index],"all_point_seeds_verified"=>true,
        "metric_order"=>["logical_1","logical_2","state_failure"],
        "final_counts"=>final_counts,"feedback_counts"=>feedback_counts,"both_counts"=>both_counts,
        "elapsed_seconds"=>elapsed,"checkpoint_sha256"=>bytes2hex(SHA.sha256(checkpoint_bytes)),
        "metadata_sha256"=>bytes2hex(SHA.sha256(read(METADATA))),
        "raw_sha256"=>bytes2hex(SHA.sha256(read(RAW))),
        "julia_version"=>string(VERSION),"ldpc_version"=>final_decoder.version,
        "decoder_settings"=>config["settings"]))
end

open(OUTPUT_TOML,"w") do io
    TOML.print(io,RESULT;sorted=true)
end
