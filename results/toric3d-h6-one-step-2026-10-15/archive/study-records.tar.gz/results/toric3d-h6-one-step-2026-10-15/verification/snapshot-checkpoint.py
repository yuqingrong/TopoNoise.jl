"""Copy an observed atomic checkpoint without changing the live runner files."""
import hashlib
import json
from pathlib import Path
import sys
import time
import tomllib

directory = Path(sys.argv[1])
checkpoint = directory / "toric3d-x-feedback-checkpoint.toml"
if not checkpoint.exists():
    print(json.dumps({"status": "checkpoint_not_yet_created"}))
    raise SystemExit(0)

payload = checkpoint.read_bytes()
data = tomllib.loads(payload.decode())
counts = [state["completed_shots"] for state in data["states"]]
total = sum(counts)
digest = hashlib.sha256(payload).hexdigest()
snapshots = directory / "checkpoint-snapshots"
snapshots.mkdir(exist_ok=True)
snapshot = snapshots / f"shots-{total:05d}.toml"
if snapshot.exists():
    if snapshot.read_bytes() != payload:
        raise RuntimeError("Checkpoint changed without advancing its sample count")
else:
    snapshot.write_bytes(payload)
    with (snapshots / "index.jsonl").open("a") as stream:
        stream.write(json.dumps({
            "captured_at_unix": time.time(),
            "completed_shots": counts,
            "sha256": digest,
            "path": snapshot.name,
        }) + "\n")

print(json.dumps({"completed_shots": counts, "total": total,
                  "target": len(counts) * data["config"]["shots"],
                  "checkpoint_sha256": digest}))
