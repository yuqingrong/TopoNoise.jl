"""Adversarial checks for the independent, results-local artifact audit."""
import copy
import csv
import importlib.util
import math
import json
import shutil
import tempfile
from pathlib import Path
import tomllib
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('one_step_audit', HERE / 'audit_artifacts.py')
AUDIT = None
if (HERE / 'audit_artifacts.py').exists():
    AUDIT = importlib.util.module_from_spec(SPEC)
    SPEC.loader.exec_module(AUDIT)


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(AUDIT, 'independent artifact audit has not been implemented')

    def pilot(self):
        folder = HERE.parent / 'pilot-x'
        with (folder / 'toric3d-x-feedback-raw.csv').open() as stream:
            rows = list(csv.DictReader(stream))
        return (tomllib.loads((folder / 'toric3d-x-feedback-checkpoint.toml').read_text()),
                rows, tomllib.loads((folder / 'toric3d-x-feedback-metadata.toml').read_text()))

    def test_paired_statistics_keep_uncertainty_when_no_pairs_differ(self):
        stats = AUDIT.paired_statistics(20, 0, 0, 0)
        self.assertEqual(stats['difference_feedback_minus_final'], 0)
        self.assertAlmostEqual(stats['final_only_ci_high'], .16112515805281938)
        self.assertAlmostEqual(stats['difference_ci_low'], -.2007636283872488)
        self.assertAlmostEqual(stats['difference_ci_high'], .2007636283872488)

    def test_paired_discordances_use_sample_variance(self):
        stats = AUDIT.paired_statistics(20, 1, 3, 1)
        self.assertEqual(stats['final_only_only'], 0)
        self.assertEqual(stats['slice_feedback_only'], 2)
        self.assertAlmostEqual(stats['difference_feedback_minus_final'], .1)
        self.assertAlmostEqual(stats['difference_standard_error'], .06882472016116853)

    def test_impossible_joint_counts_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'joint'):
            AUDIT.paired_statistics(10, 8, 8, 2)

    def test_valid_pilot_matches_all_three_artifacts(self):
        result = AUDIT.validate_shard(*self.pilot())
        self.assertEqual(result['completed_points'], 30)
        self.assertEqual(result['completed_pairs'], 600)
        self.assertEqual(result['raw_rows'], 90)

    def test_redundant_rate_corruption_is_rejected(self):
        checkpoint, rows, meta = self.pilot()
        rows[0]['final_only_rate'] = '.7'
        with self.assertRaisesRegex(ValueError, 'final_only_rate'):
            AUDIT.validate_shard(checkpoint, rows, meta)

    def test_hex_seed_identity_mismatch_is_rejected(self):
        checkpoint, rows, meta = self.pilot()
        rows[0]['point_seed'] = '0000000000000000'
        with self.assertRaisesRegex(ValueError, 'seed'):
            AUDIT.validate_shard(checkpoint, rows, meta)

    def test_logical_union_corruption_is_rejected(self):
        checkpoint, rows, meta = self.pilot()
        checkpoint['states'][0]['final_counts'] = [0, 0, 1]
        with self.assertRaisesRegex(ValueError, 'union'):
            AUDIT.validate_shard(checkpoint, rows, meta)

    def test_duplicate_raw_metric_cannot_hide_missing_point(self):
        checkpoint, rows, meta = self.pilot()
        rows[-1] = copy.deepcopy(rows[0])
        with self.assertRaisesRegex(ValueError, 'duplicate|grid'):
            AUDIT.validate_shard(checkpoint, rows, meta)

    def test_partial_checkpoint_is_audited_without_claiming_completion(self):
        checkpoint, rows, meta = self.pilot()
        checkpoint['states'][-1]['completed_shots'] = 0
        for key in ('final_counts', 'feedback_counts', 'both_counts'):
            checkpoint['states'][-1][key] = [0, 0, 0]
        result = AUDIT.validate_shard(checkpoint, None, None)
        self.assertFalse(result['complete'])
        self.assertEqual(result['completed_pairs'], 580)

    def test_seed_overflow_is_rejected_without_float_roundtrip(self):
        checkpoint, rows, meta = self.pilot()
        checkpoint['point_seeds'][0] = '1ffffffffffffffff'
        with self.assertRaisesRegex(ValueError, 'seed'):
            AUDIT.validate_shard(checkpoint, rows, meta)

    def provenance(self):
        study = HERE.parent
        return (json.loads((study / 'selection.json').read_text()),
                json.loads((study / 'provenance.json').read_text()), study, study.parents[1])

    def test_frozen_source_and_pilot_hashes_are_verified(self):
        result = AUDIT.validate_provenance(*self.provenance())
        self.assertGreater(result['source_hashes_checked'], 40)
        self.assertEqual(result['pilot_hashes_checked'], 4)

    def test_modified_pilot_cannot_be_used_as_frozen_selection_evidence(self):
        selection, provenance, study, repo = self.provenance()
        selection['pilot_sha256']['toric3d-x-feedback-raw.csv'] = '0'*64
        with self.assertRaisesRegex(ValueError, 'pilot hash'):
            AUDIT.validate_provenance(selection, provenance, study, repo)

    def test_modified_note_hash_is_detected(self):
        selection, provenance, study, repo = self.provenance()
        provenance['source_hashes']['document/note.tex'] = '0'*64
        with self.assertRaisesRegex(ValueError, 'source hash.*note.tex'):
            AUDIT.validate_provenance(selection, provenance, study, repo)

    def test_selection_after_execution_start_is_rejected(self):
        selection, provenance, study, repo = self.provenance()
        selection['frozen_at_unix'] += 86400
        with self.assertRaisesRegex(ValueError, 'freeze.*start'):
            AUDIT.validate_provenance(selection, provenance, study, repo)

    def test_copying_study_does_not_invalidate_frozen_provenance(self):
        selection, provenance, study, repo = self.provenance()
        with tempfile.TemporaryDirectory() as temporary:
            copied = Path(temporary)
            for name in ('selection.json', 'provenance.json'):
                shutil.copyfile(study/name, copied/name)
            shutil.copytree(study/'pilot-x', copied/'pilot-x', copy_function=shutil.copyfile)
            for name in selection['shards']:
                (copied/name).mkdir()
                shutil.copyfile(study/name/'execution.json', copied/name/'execution.json')
            result = AUDIT.validate_provenance(selection, provenance, copied, repo)
            self.assertGreater(result['source_hashes_checked'], 40)

    def constant_candidate(self):
        rows = [dict(steps=L, Ly=L, p=p, shots=10, failures=5)
                for L in (3, 5, 7) for p in (.01, .02)]
        candidate = dict(pc=.015, nu=1., coefficients=[0., 0., 0.], polynomial_degree=2,
            p_scale=.01, L_reference=105**(1/3), p_min=.01, p_max=.02, nu_bounds=[.3, 5.],
            correction_omega=None, correction_coefficient=None, parameters=[.5, 0., 0., 0., 0.],
            fitted_probabilities=[.5]*6, deviance=0., degrees_of_freedom=1,
            deviance_p_value=1., monotone_increasing=False, derivative_min=0., bound_hits=[])
        return rows, candidate

    def test_candidate_probabilities_and_deviance_reconstruct_independently(self):
        result = AUDIT.reconstruct_candidate(*self.constant_candidate())
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['deviance'], 0.)

    def test_saved_candidate_probabilities_cannot_replace_coefficient_model(self):
        rows, candidate = self.constant_candidate()
        candidate['fitted_probabilities'][0] = .7
        self.assertFalse(AUDIT.reconstruct_candidate(rows, candidate)['passed'])

    def test_candidate_deviance_cannot_be_changed_independently(self):
        rows, candidate = self.constant_candidate()
        candidate['deviance'] = 3.
        self.assertFalse(AUDIT.reconstruct_candidate(rows, candidate)['passed'])

    def test_failed_guard_forbids_public_threshold(self):
        fit = dict(status='accepted', pc=.015, nu=1.,
                   candidate={'pc': .015, 'nu': 1.},
                   guards={k: True for k in AUDIT.GUARDS}, failed_guards=['crossings'])
        fit['guards']['crossings'] = False
        with self.assertRaisesRegex(ValueError, 'publication'):
            AUDIT.validate_publication_state(fit)

    def test_missing_guard_cannot_be_silently_omitted(self):
        fit = dict(status='accepted', pc=.015, nu=1., candidate={'pc': .015, 'nu': 1.},
                   guards={k: True for k in AUDIT.GUARDS if k != 'crossings'}, failed_guards=[])
        with self.assertRaisesRegex(ValueError, 'guard set'):
            AUDIT.validate_publication_state(fit)

    def test_crossing_check_keeps_disjoint_clusters_distinct(self):
        rows = [dict(steps=L, p=p, shots=100, failures=k) for L, counts in
                ((3, [50,50,50,50,50]), (5, [40,60,60,40,40]),
                 (7, [30,70,70,30,30]))
                for p, k in zip((.01,.02,.03,.04,.05), counts)]
        self.assertEqual(AUDIT.common_crossings(rows), [[.01,.02], [.03,.04]])

    def test_equal_rates_without_sign_change_do_not_create_crossing(self):
        rows = [dict(steps=L, p=p, shots=100, failures=k)
                for L, counts in ((3,[50,50,50]), (5,[60,50,60]))
                for p, k in zip((.01,.02,.03), counts)]
        self.assertEqual(AUDIT.common_crossings(rows), [])

    def test_saved_bootstrap_intervals_must_match_saved_accepted_samples(self):
        boot = dict(replicates=3, accepted=3, seed=42,
                    samples=[dict(replicate=i, accepted=True, pc=p, nu=1., failed_guards=[])
                             for i, p in enumerate((.01,.02,.03))],
                    pc_interval=[.0105,.0295], nu_interval=[1.,1.])
        AUDIT.validate_bootstrap(boot, 3, 42)
        boot['pc_interval'][0] = .02
        with self.assertRaisesRegex(ValueError, 'bootstrap.*interval'):
            AUDIT.validate_bootstrap(boot, 3, 42)

    def null_fit(self):
        rows, _ = self.constant_candidate()
        guards = {key: False for key in sorted(AUDIT.GUARDS)}
        numerical = {key: False for key in ('interior_optimizer','monotonicity','goodness_of_fit')}
        boot = dict(replicates=200, seed=42, accepted=0, samples=[], pc_interval=None, nu_interval=None)
        fit = dict(channel='x_only', protocol='one_step', status='diagnostic_only', pc=None, nu=None,
                   candidate=None, guards=guards, failed_guards=list(guards), sizes=[3,5,7],
                   rates=[.01,.02], crossing_common_brackets=[], bootstrap=boot,
                   sensitivity=[dict(name=name, passed=False, candidate=None, sufficient_grid=False,
                       guards=numerical, stable=False, pc_tolerance=None, nu_tolerance=None)
                       for name in AUDIT.VARIANTS])
        selection = dict(bootstrap_replicates=200, bootstrap_seeds={'one_step':42})
        return rows, fit, selection

    def test_unavailable_fit_is_honestly_withheld(self):
        rows, fit, selection = self.null_fit()
        AUDIT.validate_fit_evidence(rows, fit, selection, 'one_step')

    def test_report_guard_booleans_are_checked_against_evidence(self):
        rows, fit, selection = self.null_fit()
        fit['guards']['goodness_of_fit'] = True
        fit['failed_guards'].remove('goodness_of_fit')
        with self.assertRaisesRegex(ValueError, 'goodness_of_fit'):
            AUDIT.validate_fit_evidence(rows, fit, selection, 'one_step')

    def test_observed_checkpoint_snapshots_match_their_ledger(self):
        folder = HERE.parent/'production-small'
        checkpoint = tomllib.loads((folder/'toric3d-x-feedback-checkpoint.toml').read_text())
        result = AUDIT.validate_snapshots(folder, checkpoint)
        self.assertGreaterEqual(result['snapshots_checked'], 2)
        self.assertEqual(result['latest_observed_pairs'], 14000)

    def test_corrupted_observed_snapshot_hash_is_rejected(self):
        folder = HERE.parent/'production-small'
        checkpoint = tomllib.loads((folder/'toric3d-x-feedback-checkpoint.toml').read_text())
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary)
            shutil.copytree(folder/'checkpoint-snapshots', target/'checkpoint-snapshots')
            snapshot = next((target/'checkpoint-snapshots').glob('*.toml'))
            snapshot.write_text(snapshot.read_text()+'\n# changed\n')
            with self.assertRaisesRegex(ValueError, 'snapshot hash'):
                AUDIT.validate_snapshots(target, checkpoint)

    def test_direct_replay_counts_and_hashes_match_original_artifacts(self):
        study = HERE.parent
        evidence = tomllib.loads((HERE/'replay-L9-p015.toml').read_text())
        provenance = json.loads((study/'provenance.json').read_text())
        result = AUDIT.validate_replay(evidence, study/'production-small', provenance)
        self.assertEqual(result['paired_shots_replayed'], 500)

    def test_changed_replay_count_cannot_pass_on_status_label_alone(self):
        study = HERE.parent
        evidence = tomllib.loads((HERE/'replay-L9-p015.toml').read_text())
        provenance = json.loads((study/'provenance.json').read_text())
        evidence['feedback_counts'][2] += 1
        with self.assertRaisesRegex(ValueError, 'replay counts'):
            AUDIT.validate_replay(evidence, study/'production-small', provenance)

    def test_pair_tables_must_admit_one_four_bit_logical_distribution(self):
        # In each arm logical 1 and 2 fail on the same five shots. Their
        # cross-arm intersections must therefore be equal, not five and zero.
        with self.assertRaisesRegex(ValueError, 'joint distribution'):
            AUDIT.validate_joint_feasibility(10, [5,5,5], [5,5,5], [5,0,5])

    def test_consistent_logical_joint_counts_have_integer_realization(self):
        AUDIT.validate_joint_feasibility(10, [5,5,5], [5,5,5], [3,3,3])

    def test_jsonlines_snapshot_index_is_audited_too(self):
        folder = HERE.parent/'production-L11'
        checkpoint = tomllib.loads((folder/'toric3d-x-feedback-checkpoint.toml').read_text())
        result = AUDIT.validate_snapshots(folder, checkpoint)
        self.assertEqual(result['snapshots_checked'], 17)
        self.assertEqual(result['latest_observed_pairs'], 3500)


if __name__ == '__main__':
    unittest.main()
