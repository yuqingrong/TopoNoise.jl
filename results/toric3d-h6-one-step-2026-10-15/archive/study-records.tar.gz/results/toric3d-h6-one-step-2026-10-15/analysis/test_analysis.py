"""Regression tests for the results-local, X-only one-step analysis adapter."""
import copy
import csv
import importlib.util
import json
from pathlib import Path
import tempfile
import tomllib
import unittest

import numpy as np
from scipy.special import expit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRIPT = HERE / 'analyze.py'
REFERENCE = HERE.parent / 'pilot-x'
if SCRIPT.exists():
    spec = importlib.util.spec_from_file_location('one_step_analysis', SCRIPT)
    A = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(A)
else:
    A = None


def reference():
    with (REFERENCE / 'toric3d-x-feedback-raw.csv').open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    metadata = tomllib.loads((REFERENCE / 'toric3d-x-feedback-metadata.toml').read_text())
    checkpoint = tomllib.loads((REFERENCE / 'toric3d-x-feedback-checkpoint.toml').read_text())
    return rows, metadata, checkpoint


def scaling_points():
    points = []
    for size in (3, 5, 7, 9, 11):
        for p in np.linspace(.003, .008, 11):
            row = dict(steps=size, Ly=size, Lz=size, p=float(p), shots=2000000,
                       seed=123, point_seed=f'{len(points):016x}', elapsed_seconds=0.)
            row['logical_1'], row['logical_2'] = {}, {}
            for column, center in [('final_only_failures', .005), ('slice_feedback_failures', .006)]:
                x = (p-center)/.005 * (size/7)**(1/1.2)
                k = round(row['shots'] * expit(-1+3*x+.25*x*x))
                row[column] = k
                row['logical_1'][column] = round(.6*k)
                row['logical_2'][column] = round(.55*k)
            row['both_failures'] = min(row['final_only_failures'], row['slice_feedback_failures'])
            row['final_only_only'] = row['final_only_failures'] - row['both_failures']
            row['slice_feedback_only'] = row['slice_feedback_failures'] - row['both_failures']
            points.append(row)
    return points


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(A, 'the X-only one-step guarded adapter is not implemented')

    def test_real_reference_adaptation_preserves_both_logicals_and_protocols(self):
        points = A.validate_records(*reference())
        self.assertEqual(len(points), 30)
        for protocol, column in [('final_only', 'final_only_failures'), ('one_step', 'slice_feedback_failures')]:
            adapted = A.adapt_points(points, protocol)
            self.assertEqual({r['channel'] for r in adapted}, {'x_only'})
            for original, row in zip(points, adapted):
                self.assertEqual(row['failures'], original[column])
                self.assertEqual(row['logical_1_failures'], original['logical_1'][column])
                self.assertEqual(row['logical_2_failures'], original['logical_2'][column])
                self.assertEqual(row['point_seed'], original['point_seed'])
        self.assertTrue(any(r['logical_1']['slice_feedback_failures'] !=
                            r['logical_2']['slice_feedback_failures'] for r in points))

    def test_joint_counts_seed_checkpoint_and_grid_tampering_are_rejected(self):
        for kind, message in [('joint', 'paired|joint'), ('seed', 'seed'),
                              ('checkpoint', 'checkpoint'), ('grid', 'grid|metric'),
                              ('metadata', 'metadata|H\\+6|protocol')]:
            rows, meta, checkpoint = reference()
            if kind == 'joint':
                rows[0]['both_failures'] = '1'
            elif kind == 'seed':
                rows[0]['point_seed'] = 'fedcba9876543210'
            elif kind == 'checkpoint':
                checkpoint['states'][0]['final_counts'][0] = 1
            elif kind == 'grid':
                rows = rows[3:]
            else:
                meta['transfer_schedule'] = 'H+5'
            with self.subTest(kind=kind), self.assertRaisesRegex(ValueError, message):
                A.validate_records(rows, meta, checkpoint)

    def test_paired_difference_uses_discordances_with_nonzero_zero_count_interval(self):
        points = A.validate_records(*reference())
        for point in points:
            paired = A.paired_summary(point)
            self.assertAlmostEqual(paired['difference'],
                                   (point['slice_feedback_only']-point['final_only_only'])/point['shots'])
            self.assertAlmostEqual(paired['difference'], point['difference_feedback_minus_final'])
            self.assertAlmostEqual(paired['ci_low'], point['difference_ci_low'])
            self.assertAlmostEqual(paired['ci_high'], point['difference_ci_high'])
        self.assertLess(A.paired_summary(points[0])['ci_low'], 0)
        self.assertGreater(A.paired_summary(points[0])['ci_high'], 0)

    def test_known_scaling_recovers_each_protocol_with_identical_guard_policy(self):
        points = scaling_points()
        for protocol, expected in [('final_only', .005), ('one_step', .006)]:
            fit = A.analyze_protocol(points, protocol, bootstrap=24, seed=123)
            self.assertEqual(fit['status'], 'accepted', fit['failed_guards'])
            self.assertAlmostEqual(fit['pc'], expected, delta=.00002)
            self.assertAlmostEqual(fit['nu'], 1.2, delta=.02)
            self.assertEqual(set(fit['guards']), {
                'grid_resolution', 'interior_optimizer', 'monotonicity', 'goodness_of_fit',
                'crossings', 'bootstrap', 'sensitivity_drop_smallest', 'sensitivity_narrow_window',
                'sensitivity_cubic', 'sensitivity_inverse_L_correction'})
        self.assertEqual(A.GUARD_POLICY, A.H6.GUARD_POLICY)

    def test_reference_pilot_is_diagnostic_and_missing_rates_are_rejected(self):
        points = A.validate_records(*reference())
        fit = A.analyze_protocol(points, 'one_step', bootstrap=0)
        self.assertEqual(fit['status'], 'diagnostic_only')
        self.assertIsNone(fit['pc'])
        self.assertFalse(fit['guards']['bootstrap'])
        self.assertNotIn(0., fit['rates'], 'zero-noise sanity point must stay outside scaling fits')
        with self.assertRaisesRegex(ValueError, 'grid'):
            A.validate_grid(points[:-1])

    def test_frozen_production_selection_and_source_provenance_are_enforced(self):
        selection = json.loads((HERE.parent/'selection.json').read_text())
        provenance = json.loads((HERE.parent/'provenance.json').read_text())
        points = [dict(steps=L, p=p, shots=selection['paired_shots_per_point'], seed=shard['seed'])
                  for shard in selection['shards'].values() for L in shard['sizes'] for p in selection['rates']]
        directories = [HERE.parent/name for name in selection['shards']]
        metadata = [dict(started_at_unix=selection['frozen_at_unix']+1)] * len(directories)
        self.assertTrue(hasattr(A, 'validate_selection'), 'frozen-selection validation is required')
        A.validate_selection(points, directories, metadata, selection, provenance, bootstrap=200, seed=2026101506)
        points[0]['shots'] -= 1
        with self.assertRaisesRegex(ValueError, 'selection|shots'):
            A.validate_selection(points, directories, metadata, selection, provenance, bootstrap=200, seed=2026101506)
        points[0]['shots'] += 1
        wrong = copy.deepcopy(provenance)
        wrong['source_hashes']['src/toric3d/x_feedback_threshold.jl'] = '0'*64
        with self.assertRaisesRegex(ValueError, 'source|hash'):
            A.validate_selection(points, directories, metadata, selection, wrong, bootstrap=200, seed=2026101506)

    def test_production_insets_do_not_hide_main_points_or_confidence_intervals(self):
        from matplotlib.transforms import Bbox
        points, _, _ = A.load_inputs([HERE.parent/'production-small', HERE.parent/'production-L11'])
        fits = {protocol: A.analyze_protocol(points, protocol, bootstrap=0) for protocol in A.PROTOCOLS}
        with tempfile.TemporaryDirectory() as folder:
            figure, _ = A.make_figures(points, fits, Path(folder))
            figure.canvas.draw()
            renderer = figure.canvas.get_renderer()
            for axis in figure.axes:
                obstruction = axis.child_axes[0].get_tightbbox(renderer)
                for errorbars in axis.containers:
                    for collection in errorbars.lines[2]:
                        for segment in collection.get_segments():
                            pixels = axis.transData.transform(segment)
                            extent = Bbox.from_extents(pixels[:, 0].min()-3, pixels[:, 1].min()-3,
                                                       pixels[:, 0].max()+3, pixels[:, 1].max()+3)
                            self.assertFalse(obstruction.overlaps(extent),
                                             'main failure-rate point/interval is obscured by an inset or its labels')

    def test_figures_have_insets_without_legend_overlap_and_paired_chart(self):
        points = A.validate_records(*reference())
        fits = {p: A.analyze_protocol(points, p, bootstrap=0) for p in A.PROTOCOLS}
        with tempfile.TemporaryDirectory() as folder:
            main, paired = A.make_figures(points, fits, Path(folder))
            main.canvas.draw()
            renderer = main.canvas.get_renderer()
            for axis in main.axes:
                self.assertEqual(len(axis.child_axes), 1)
                inset = axis.child_axes[0]
                self.assertIn('Diagnostic', inset.get_title())
                plotted_points = sum(len(line.get_xdata()) for line in inset.lines if line.get_marker() == 'o')
                self.assertEqual(plotted_points, sum(r['p'] > 0 for r in points),
                                 'scaling inset must exclude zero-noise sanity points')
                self.assertFalse(axis.get_legend().get_window_extent(renderer).overlaps(
                    inset.title.get_window_extent(renderer)))
            self.assertEqual(len(paired.axes), 1)
            for stem in ('x-one-step-failure-rates', 'x-one-step-paired-differences'):
                for extension in ('png', 'pdf', 'svg'):
                    self.assertGreater((Path(folder)/f'{stem}.{extension}').stat().st_size, 1000)


if __name__ == '__main__':
    unittest.main()
