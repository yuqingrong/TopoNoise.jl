#!/usr/bin/env python3
"""Results-local guarded analysis of paired H+6 X-only one-step feedback.

The two real X protocols are analyzed independently. No Z observations are
constructed, and separate marginal bootstraps never imply a threshold-difference
interval. Every publication guard and sensitivity rule matches the previous
H+6 final-only analysis; its pure numerical functions are imported unchanged.
"""
import argparse
import csv
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import tomllib

import numpy as np
from scipy.special import expit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
H6_PATH = ROOT / 'examples/fit_toric3d_h6_threshold.py'
SPEC = importlib.util.spec_from_file_location('h6_guard_engine', H6_PATH)
H6 = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H6)
GUARD_POLICY = H6.GUARD_POLICY
NU_BOUNDS = H6.NU_BOUNDS
PROTOCOLS = {'final_only': 'final_only_failures', 'one_step': 'slice_feedback_failures'}
METRICS = ('logical_1', 'logical_2', 'state_failure')
SETTINGS = ('max_iter', 'bp_method', 'ms_scaling_factor', 'schedule',
            'omp_thread_count', 'osd_method', 'osd_order')
BASENAME = 'toric3d-x-feedback'
EXPECTED_PROTOCOL = {
    'routing': 'one_step',
    'transfer_schedule': 'seven-gate diagonal transfer: H followed by six CNOTs',
    'active_gate_outputs_per_transfer_cell': 13,
    'seed_gate_fault_locations': 0,
    'initial_state': 'logical |00> prepared by ideal X-star measurement and ideal Z correction',
    'noise': 'independent Bernoulli X fault of rate p after each participating H/CNOT output',
    'feedback': 'ideal active-slice star measurement and MWPM correction after each diagonal slice',
    'final_decoder': 'full-plaquette BP+OSD X recovery, validated against the measured syndrome',
    'rng_type': 'Random.MersenneTwister', 'point_rng_type': 'Random.Xoshiro',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(actual, expected, label):
    require(math.isfinite(float(actual)) and math.isclose(float(actual), expected,
            rel_tol=1e-11, abs_tol=1e-13), f'{label} differs from recomputed value')


def paired_summary(row):
    n = row['shots']
    a, b, both = row['final_only_failures'], row['slice_feedback_failures'], row['both_failures']
    fa, fb = a-both, b-both
    delta = (fb-fa)/n
    low_b, high_b = H6.ENGINE.wilson_interval(fb, n, z=2.241402727604947)
    low_a, high_a = H6.ENGINE.wilson_interval(fa, n, z=2.241402727604947)
    return dict(neither=n-a-b+both, both=both, final_only_only=fa, one_step_only=fb,
                difference=delta, standard_error=math.sqrt(max(0, ((fa+fb)/n-delta*delta)/(n-1))) if n > 1 else None,
                ci_low=max(-1., low_b-high_a), ci_high=min(1., high_b-low_a))


def validate_grid(points):
    require(bool(points), 'empty point grid')
    keys = [(r['steps'], r['p']) for r in points]
    require(len(keys) == len(set(keys)), 'duplicate point grid entry')
    sizes = {r['steps'] for r in points}
    rates = {r['p'] for r in points}
    require(set(keys) == {(L, p) for L in sizes for p in rates}, 'incomplete rectangular point grid')
    return sorted(points, key=lambda r: (r['steps'], r['p']))


def validate_records(raw_rows, metadata, checkpoint):
    """Cross-check every raw metric against the completed checkpoint and metadata."""
    require(all(metadata.get(k) == v for k, v in EXPECTED_PROTOCOL.items()),
            'metadata protocol must be legacy H+6 X-only one_step')
    require(metadata.get('complete') is True, 'metadata must be complete')
    require(metadata.get('format_version') == checkpoint.get('format_version') == 1,
            'unsupported metadata/checkpoint format')
    config = checkpoint.get('config', {})
    comparisons = {'dimensions_steps_Ly_Lz': 'dimensions', 'error_rates': 'error_rates',
                   'shots_per_point': 'shots', 'seed_metadata': 'seed', 'batch_size': 'batch_size',
                   'routing': 'routing', 'rng_type': 'rng_type', 'point_rng_type': 'point_rng_type',
                   'decoder_settings': 'settings'}
    for mk, ck in comparisons.items():
        require(metadata.get(mk) == config.get(ck), f'metadata/checkpoint configuration mismatch: {mk}')
    dimensions, rates = config['dimensions'], config['error_rates']
    require(all(len(d) == 3 and d[0] == d[1] == d[2] and d[0] >= 2 for d in dimensions),
            'geometry must be T=L; Ly=Lz=L')
    require(len(dimensions) == len({tuple(d) for d in dimensions}) and len(rates) == len(set(rates)),
            'duplicate configured grid')
    require(all(math.isfinite(p) and 0 <= p < .5 for p in rates), 'invalid probability grid')
    seeds = checkpoint.get('point_seeds', [])
    require(seeds == metadata.get('point_seeds_hex'), 'metadata/checkpoint seed table mismatch')
    expected = [(tuple(d), p) for d in dimensions for p in rates]
    states = checkpoint.get('states', [])
    require(len(expected) == len(seeds) == len(states) == metadata.get('expected_points') == metadata.get('completed_points'),
            'metadata/checkpoint complete grid count mismatch')
    require(all(isinstance(s, str) and re.fullmatch('[0-9a-f]{16}', s) for s in seeds),
            'point seed must preserve exactly 16 lowercase hexadecimal digits')
    require(len(set(seeds)) == len(seeds), 'duplicate point seed')
    close(checkpoint['started_at_unix'], metadata['started_at_unix'], 'checkpoint start time')
    grouped = {}
    for original in raw_rows:
        row = dict(original)
        for field in ('steps', 'Ly', 'Lz', 'qubits', 'shots', 'seed',
                      'final_only_failures', 'slice_feedback_failures', 'both_failures',
                      'final_only_only', 'slice_feedback_only'):
            row[field] = H6.integer(row.get(field), field)
        for field in ('p', 'elapsed_seconds', 'final_only_rate', 'slice_feedback_rate',
                      'final_only_ci_low', 'final_only_ci_high', 'slice_feedback_ci_low',
                      'slice_feedback_ci_high', 'difference_feedback_minus_final',
                      'difference_standard_error', 'difference_ci_low', 'difference_ci_high'):
            row[field] = float(row[field])
            require(math.isfinite(row[field]), f'{field} must be finite')
        n, a, b, both = (row[k] for k in ('shots', 'final_only_failures', 'slice_feedback_failures', 'both_failures'))
        require(n > 1 and 0 <= both <= min(a, b) and max(a, b) <= n and a+b-both <= n,
                'invalid paired joint counts')
        require(row['final_only_only'] == a-both and row['slice_feedback_only'] == b-both,
                'paired discordance counts disagree')
        require(row['steps'] == row['Ly'] == row['Lz'] >= 2 and
                row['qubits'] == 3*(row['steps']+1)*row['Ly']*row['Lz'], 'raw T=L geometry mismatch')
        require(row['routing'] == 'one_step', 'raw feedback routing mismatch')
        require(row['metric'] in METRICS, 'unknown raw metric')
        key = ((row['steps'], row['Ly'], row['Lz']), row['p'])
        require(key in expected, 'raw row lies outside configured grid')
        group = grouped.setdefault(key, {})
        require(row['metric'] not in group, 'duplicate grid metric row')
        group[row['metric']] = row
        for column, prefix in [('final_only_failures', 'final_only'), ('slice_feedback_failures', 'slice_feedback')]:
            low, high = H6.wilson_interval(row[column], n)
            close(row[prefix+'_rate'], row[column]/n, prefix+' rate')
            close(row[prefix+'_ci_low'], low, prefix+' interval')
            close(row[prefix+'_ci_high'], high, prefix+' interval')
        paired = paired_summary(row)
        for field, derived in [('difference_feedback_minus_final', 'difference'),
                               ('difference_standard_error', 'standard_error'),
                               ('difference_ci_low', 'ci_low'), ('difference_ci_high', 'ci_high')]:
            close(row[field], paired[derived], field)
    require(set(grouped) == set(expected), 'raw grid does not match configured grid')
    output = []
    for (dimensions_value, p), seed, state in zip(expected, seeds, states):
        group = grouped[dimensions_value, p]
        require(set(group) == set(METRICS), 'incomplete metric grid')
        require(state['completed_shots'] == config['shots'], 'checkpoint point is incomplete')
        for index, metric in enumerate(METRICS):
            row = group[metric]
            require(row['shots'] == config['shots'] and row['seed'] == config['seed'] and
                    row['point_seed'] == seed, 'raw/checkpoint shot or seed mismatch')
            require(row['ldpc_version'] == state['decoder_version'] and
                    row['ldpc_version'] in metadata['ldpc_versions'], 'checkpoint decoder version mismatch')
            for key in SETTINGS:
                expected_setting = config['settings'][key]
                if isinstance(expected_setting, (int, float)):
                    close(row[key], expected_setting, 'decoder setting '+key)
                else:
                    require(row[key] == expected_setting, 'decoder setting mismatch: '+key)
            for column, key in [('final_only_failures', 'final_counts'),
                                ('slice_feedback_failures', 'feedback_counts'), ('both_failures', 'both_counts')]:
                require(len(state[key]) == 3 and row[column] == state[key][index],
                        'raw/checkpoint metric count mismatch')
            close(row['elapsed_seconds'], state['elapsed_seconds'], 'checkpoint elapsed time')
        point = dict(group['state_failure'], logical_1=group['logical_1'], logical_2=group['logical_2'])
        for column in PROTOCOLS.values():
            a, b, union = group['logical_1'][column], group['logical_2'][column], group['state_failure'][column]
            require(max(a, b) <= union <= a+b, 'logical union count mismatch')
        output.append(point)
    return validate_grid(output)


def load_inputs(directories):
    points, provenance, metadata_list = [], [], []
    for directory in map(Path, directories):
        files = {suffix: directory/f'{BASENAME}-{suffix}' for suffix in ('raw.csv', 'metadata.toml', 'checkpoint.toml')}
        with files['raw.csv'].open(newline='') as stream:
            raw = list(csv.DictReader(stream))
        metadata = tomllib.loads(files['metadata.toml'].read_text())
        checkpoint = tomllib.loads(files['checkpoint.toml'].read_text())
        points.extend(validate_records(raw, metadata, checkpoint))
        metadata_list.append(metadata)
        provenance.append(dict(directory=str(directory.resolve()), hashes={path.name: H6.sha256(path) for path in files.values()}))
    require(bool(metadata_list), 'at least one input directory is required')
    for key in (*EXPECTED_PROTOCOL, 'decoder_settings', 'ldpc_versions', 'shots_per_point', 'error_rates'):
        require(all(m[key] == metadata_list[0][key] for m in metadata_list), 'incompatible input metadata: '+key)
    return validate_grid(points), provenance, metadata_list


def validate_selection(points, directories, metadata, selection, provenance, *, bootstrap, seed):
    """Enforce the production grid, source snapshot, and analysis settings frozen before sampling."""
    shards = selection['shards']
    require({Path(d).name for d in directories} == set(shards), 'input directories differ from frozen selection')
    require(selection['channel'] == 'x_only' and selection['pilot_excluded_from_production'] is True,
            'invalid frozen selection protocol')
    require(selection['frozen_before_production'] is True and
            all(m['started_at_unix'] >= selection['frozen_at_unix'] for m in metadata),
            'selection was not frozen before production')
    expected = {(L, p, selection['paired_shots_per_point'], shard['seed'])
                for shard in shards.values() for L in shard['sizes'] for p in selection['rates']}
    actual = {(r['steps'], r['p'], r['shots'], r['seed']) for r in points}
    require(actual == expected and len(points) == len(expected), 'raw grid/shots/seeds differ from frozen selection')
    require(sorted({r['steps'] for r in points}) == selection['sizes'] and
            sum(r['shots'] for r in points) == selection['total_paired_shots'], 'frozen selection totals disagree')
    require(bootstrap == selection['bootstrap_replicates'] and
            {p: seed+i for i, p in enumerate(PROTOCOLS)} == selection['bootstrap_seeds'],
            'analysis bootstrap settings differ from frozen selection')
    require(selection['fit_policy_source_sha256'] == H6.sha256(H6_PATH), 'frozen fit-policy source hash mismatch')
    require(bool(provenance.get('source_hashes')), 'source provenance hashes are required')
    for relative, digest in provenance['source_hashes'].items():
        source = (ROOT/relative).resolve()
        require(source.is_relative_to(ROOT) and source.is_file() and H6.sha256(source) == digest,
                'source provenance hash mismatch: '+relative)
    require(Path(sys.executable).resolve() == Path(provenance['python_executable']).resolve(),
            'analysis Python executable differs from recorded environment')
    for name, version in provenance['packages'].items():
        require(importlib.metadata.version(name) == version, 'package version differs from provenance: '+name)


def adapt_points(points, protocol):
    require(protocol in PROTOCOLS, 'unknown protocol')
    column = PROTOCOLS[protocol]
    return [dict(channel='x_only', steps=r['steps'], Ly=r['Ly'], Lz=r['Lz'], p=r['p'],
                 shots=r['shots'], failures=r[column], none_failures=r[column],
                 logical_1_failures=r['logical_1'][column], logical_2_failures=r['logical_2'][column],
                 seed=r['seed'], point_seed=r['point_seed'], decoder='BP+OSD', complete=True,
                 elapsed_seconds=r['elapsed_seconds']) for r in validate_grid(points)]


def analyze_protocol(raw_points, protocol, *, bootstrap=200, seed=2026101506):
    """Same acceptance gates as H6.analyze_channel, over one real X protocol."""
    require(bootstrap >= 0, 'bootstrap must be nonnegative')
    points = [r for r in adapt_points(raw_points, protocol) if r['p'] > 0]
    require(bool(points), 'no positive-rate points available for scaling')
    sizes, rates = sorted({r['steps'] for r in points}), sorted({r['p'] for r in points})
    candidate = H6.candidate_fit(points)
    crossings, clusters = H6.crossing_clusters(points)
    guards = dict(grid_resolution=len(sizes) >= 4 and len(rates) >= 5)
    guards.update(H6.numerical_guards(candidate))
    guards['crossings'] = bool(len(sizes) >= 2 and len(clusters) == 1 and candidate is not None
                               and any(a <= candidate['pc'] <= b for a, b in clusters))
    boot = H6.bootstrap_candidate(points, candidate, bootstrap, seed)
    guards['bootstrap'] = bool(
        bootstrap >= GUARD_POLICY['minimum_bootstrap_replicates']
        and boot['accepted'] >= math.ceil(.8 * bootstrap)
        and boot['pc_interval'] is not None
        and rates[0] < boot['pc_interval'][0] < boot['pc_interval'][1] < rates[-1]
        and NU_BOUNDS[0] < boot['nu_interval'][0] < boot['nu_interval'][1] < NU_BOUNDS[1])
    variants = [
        ('drop_smallest', [r for r in points if r['steps'] != sizes[0]], 2, False),
        ('narrow_window', [r for r in points if rates[0] < r['p'] < rates[-1]], 2, False),
        ('cubic', points, 3, False),
        ('inverse_L_correction', points, 2, True),
    ]
    sensitivities = []
    for name, selected, degree, correction in variants:
        enough = len({r['steps'] for r in selected}) >= 4 and len({r['p'] for r in selected}) >= 5
        fitted = H6.candidate_fit(selected, degree, correction) if enough else None
        checks = H6.numerical_guards(fitted)
        stable = False
        pc_tolerance = nu_tolerance = None
        if fitted is not None and candidate is not None:
            pc_tolerance = max(.1 * (rates[-1] - rates[0]),
                               np.ptp(boot['pc_interval']) if boot['pc_interval'] else 0.)
            nu_tolerance = max(.25 * candidate['nu'],
                               np.ptp(boot['nu_interval']) if boot['nu_interval'] else 0.)
            stable = (abs(fitted['pc'] - candidate['pc']) <= pc_tolerance
                      and abs(fitted['nu'] - candidate['nu']) <= nu_tolerance)
        passed = bool(enough and all(checks.values()) and stable)
        guards[f'sensitivity_{name}'] = passed
        sensitivities.append(dict(name=name, passed=passed, candidate=fitted,
                                  sufficient_grid=enough, guards=checks, stable=bool(stable),
                                  pc_tolerance=pc_tolerance, nu_tolerance=nu_tolerance))
    accepted = all(guards.values())
    return dict(channel='x_only', protocol=protocol, status='accepted' if accepted else 'diagnostic_only',
                pc=candidate['pc'] if accepted else None, nu=candidate['nu'] if accepted else None,
                candidate=candidate, guards=guards, failed_guards=[k for k, v in guards.items() if not v],
                sizes=sizes, rates=rates, crossings=crossings, crossing_common_brackets=clusters,
                bootstrap=boot, sensitivity=sensitivities)


def make_figures(points, fits, output):
    os.environ.setdefault('MPLCONFIGDIR', '/tmp/toponoise-h6-mpl')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none'})
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 7.1))
    sizes = sorted({r['steps'] for r in points})
    colors = plt.cm.viridis(np.linspace(.1, .85, len(sizes)))
    labels = {'final_only': 'Final-only recovery', 'one_step': 'One-step feedback + final recovery'}
    for axis, protocol in zip(axes, PROTOCOLS):
        fit, adapted = fits[protocol], adapt_points(points, protocol)
        for color, size in zip(colors, sizes):
            selected = [r for r in adapted if r['steps'] == size]
            observed = np.array([r['failures']/r['shots'] for r in selected])
            ci = np.array([H6.wilson_interval(r['failures'], r['shots']) for r in selected])
            axis.errorbar([100*r['p'] for r in selected], observed,
                          yerr=np.maximum(0, [observed-ci[:, 0], ci[:, 1]-observed]),
                          color=color, marker='o', ms=4, lw=1.1, capsize=2, label=f'L={size}')
        axis.set(xlabel='X fault probability per gate output p (%)', ylabel='Either-logical failure probability')
        axis.set_title(labels[protocol], pad=40)
        axis.set_ylim(0, 1)
        axis.legend(loc='lower center', bbox_to_anchor=(.5, 1.005), ncol=3,
                    fontsize=8, frameon=False, borderaxespad=0)
        axis.grid(alpha=.15)
        inset = axis.inset_axes([.10, .64, .45, .28])
        candidate, accepted = fit['candidate'], fit['status'] == 'accepted'
        inset.set_title('Accepted scaling fit' if accepted else 'Diagnostic scaling fit', fontsize=9)
        if candidate is not None:
            all_x = []
            for color, size in zip(colors, sizes):
                selected = [r for r in adapted if r['steps'] == size and r['p'] in fit['rates']]
                x = [(r['p']-candidate['pc'])/candidate['p_scale']*(size/candidate['L_reference'])**(1/candidate['nu'])
                     for r in selected]
                all_x.extend(x)
                inset.plot(x, [r['failures']/r['shots'] for r in selected], 'o', ms=2.5, color=color)
            grid = np.linspace(min(all_x), max(all_x), 300)
            inset.plot(grid, expit(np.polynomial.polynomial.polyval(grid, candidate['coefficients'])), color='#222222', lw=1.5)
            inset.set(xlabel='Scaled p − candidate p₀', ylabel='Failure')
            inset.xaxis.label.set_fontsize(8)
            inset.yaxis.label.set_fontsize(8)
            inset.tick_params(labelsize=7)
            inset.grid(alpha=.15)
        else:
            inset.text(.5, .5, 'Fit unavailable', ha='center', va='center', transform=inset.transAxes)
        if accepted:
            interval = fit['bootstrap']['pc_interval']
            status = f'p_c = {100*fit["pc"]:.4f}% (95% CI {100*interval[0]:.4f}–{100*interval[1]:.4f}%)'
        else:
            status = 'Threshold withheld · ' + ', '.join(fit['failed_guards'][:2]).replace('_', ' ')
            if len(fit['failed_guards']) > 2:
                status += f' (+{len(fit["failed_guards"])-2} guards)'
        axis.text(.02, -.18, status, transform=axis.transAxes, fontsize=9,
                  color='#137555' if accepted else '#a23b32')
    fig.suptitle('Legacy H+6-CNOT · X faults · T=L · ideal logical |00> seed', fontsize=14, y=.98)
    fig.text(.5, .035, 'Same sampled faults for both protocols; 95% Wilson bars. Insets: separate binomial-logit scaling fits.',
             ha='center', fontsize=9)
    fig.text(.5, .012, 'No threshold-difference interval is inferred from separate marginal bootstrap samples.', ha='center', fontsize=8)
    fig.subplots_adjust(left=.065, right=.985, top=.81, bottom=.25, wspace=.24)
    paired_fig, axis = plt.subplots(figsize=(9.2, 5.7))
    for color, size in zip(colors, sizes):
        selected = [r for r in points if r['steps'] == size]
        estimates = [paired_summary(r) for r in selected]
        delta = np.array([r['difference'] for r in estimates])
        axis.errorbar([100*r['p'] for r in selected], delta,
                      yerr=np.maximum(0, [delta-np.array([r['ci_low'] for r in estimates]),
                                         np.array([r['ci_high'] for r in estimates])-delta]),
                      color=color, marker='o', lw=1.2, ms=4, capsize=2, label=f'L={size}')
    axis.axhline(0, ls=':', color='#555555', lw=1)
    axis.set(xlabel='X fault probability per gate output p (%)',
             ylabel='Failure probability: one-step − final-only',
             title='Paired one-step feedback effect · H+6-CNOT · X only · T=L')
    axis.legend(ncol=3, fontsize=9)
    axis.grid(alpha=.15)
    paired_fig.text(.5, .025, 'Negative favors one-step. Pointwise conservative 95% intervals from paired discordances; no multiple-comparison adjustment.',
                    ha='center', fontsize=8)
    paired_fig.subplots_adjust(left=.12, right=.97, bottom=.17, top=.90)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    for figure, stem in [(fig, 'x-one-step-failure-rates'), (paired_fig, 'x-one-step-paired-differences')]:
        for extension in ('png', 'pdf', 'svg'):
            figure.savefig(output/f'{stem}.{extension}', dpi=200)
    return fig, paired_fig


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', action='append', required=True, type=Path)
    parser.add_argument('--output-dir', type=Path, default=HERE)
    parser.add_argument('--bootstrap', type=int, default=200)
    parser.add_argument('--seed', type=int, default=2026101506)
    args = parser.parse_args(argv)
    thread_environment = {key: os.environ.get(key) for key in
                          ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}
    require(all(value == '1' for value in thread_environment.values()), 'analysis requires recorded single-thread environment')
    points, inputs, metadata = load_inputs(args.input_dir)
    selection_path, provenance_path = HERE.parent/'selection.json', HERE.parent/'provenance.json'
    selection = json.loads(selection_path.read_text())
    provenance = json.loads(provenance_path.read_text())
    validate_selection(points, args.input_dir, metadata, selection, provenance,
                       bootstrap=args.bootstrap, seed=args.seed)
    fits = {protocol: analyze_protocol(points, protocol, bootstrap=args.bootstrap, seed=args.seed+i)
            for i, protocol in enumerate(PROTOCOLS)}
    report = dict(format_version=1, channel='x_only', circuit='legacy H+6-CNOT', geometry='T=L',
                  protocols=list(PROTOCOLS), inputs=inputs, input_metadata=metadata, fits=fits,
                  frozen_selection=selection, study_provenance=provenance,
                  study_hashes={'selection.json': H6.sha256(selection_path), 'provenance.json': H6.sha256(provenance_path)},
                  measured_checks='Z-type Q compatibility checks on the old active slice before transfer; one-step correction propagated to fresh targets after noisy transfer',
                  legacy_metadata_correction=provenance['metadata_correction'],
                  guard_policy=GUARD_POLICY, bootstrap_seed=args.seed,
                  analysis_hashes={str(path.relative_to(ROOT)): H6.sha256(path)
                                   for path in (Path(__file__).resolve(), H6_PATH, H6.ENGINE_PATH)},
                  python_executable=sys.executable, thread_environment=thread_environment,
                  versions=dict(python=platform.python_version(), **{name: importlib.metadata.version(name)
                                for name in ('numpy', 'scipy', 'matplotlib')}),
                  seed_verification='Exact 16-hex point seeds cross-checked among raw, metadata, and checkpoint; Julia RNG regeneration is audited separately.',
                  paired_interval='Bonferroni combination of 97.5% Wilson intervals on the two paired discordances; pointwise approximate 95% coverage.',
                  threshold_difference=None,
                  interpretation='Thresholds are protocol- and decoder-specific. Rejected candidates are diagnostics; failure in this feedback-focused window does not establish absence of a lower baseline threshold. Separate marginal bootstraps do not estimate a threshold difference.')
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    (output/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    rows = []
    for protocol in PROTOCOLS:
        for row in adapt_points(points, protocol):
            low, high = H6.wilson_interval(row['failures'], row['shots'])
            rows.append(dict(protocol=protocol, **row, rate=row['failures']/row['shots'], ci_low=low, ci_high=high))
    H6.write_csv(output/'points.csv', rows, [k for k in rows[0] if k != 'none_failures'])
    paired = [dict(L=r['steps'], p=r['p'], shots=r['shots'], base_seed=r['seed'], point_seed=r['point_seed'],
                   **paired_summary(r)) for r in points]
    H6.write_csv(output/'paired-differences.csv', paired, list(paired[0]))
    H6.write_csv(output/'bootstrap-samples.csv',
                 [dict(protocol=p, **sample) for p, fit in fits.items() for sample in fit['bootstrap']['samples']],
                 ['protocol', 'replicate', 'accepted', 'pc', 'nu', 'failed_guards'])
    H6.write_csv(output/'sensitivity-fits.csv',
                 [dict(protocol=p, **sample) for p, fit in fits.items() for sample in fit['sensitivity']],
                 ['protocol', 'name', 'passed', 'sufficient_grid', 'stable', 'pc_tolerance', 'nu_tolerance', 'guards', 'candidate'])
    make_figures(points, fits, output)
    print(json.dumps({p: {k: fit[k] for k in ('status', 'pc', 'nu', 'failed_guards')}
                      for p, fit in fits.items()}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
