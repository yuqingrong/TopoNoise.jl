#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
export PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/toponoise-h6-mpl
export JULIA_CONDAPKG_BACKEND=Null
export JULIA_PYTHONCALL_EXE=/Users/rongyuqing/jcode/TopoNoise.jl/.CondaPkg/.pixi/envs/default/bin/python
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
study=results/toric3d-h6-one-step-2026-10-15
stage=${1:?Choose pilot-x, production-small, or production-L11}
case "$stage" in
  pilot-x) sizes=3,5,7,9,11; rates=0,.005,.01,.015,.02,.025; shots=20; batch=10; seed=2026101503 ;;
  production-small) sizes=3,5,7,9; rates=.0075,.01,.0125,.015,.0175,.02,.0225; shots=500; batch=50; seed=2026101504 ;;
  production-L11) sizes=11; rates=.0075,.01,.0125,.015,.0175,.02,.0225; shots=500; batch=50; seed=2026101505 ;;
  *) printf 'Unknown stage: %s\n' "$stage" >&2; exit 2 ;;
esac
shift
exec julia --project=. --startup-file=no examples/scan_toric3d_x_feedback_threshold.jl \
  --sizes "$sizes" --error-rates "$rates" --shots "$shots" --batch-size "$batch" \
  --seed "$seed" --pilot-shots 5 --routing one_step --output-dir "$study/$stage" "$@"
