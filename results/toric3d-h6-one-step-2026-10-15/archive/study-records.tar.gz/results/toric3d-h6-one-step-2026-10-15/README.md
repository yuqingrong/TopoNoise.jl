# Legacy H+6 X one-step feedback: paired finite-size study

This follows the final-only X/Z study of 2026-10-15. The user selected
**X one-step feedback first**. All five sizes are the same as the previous
X study: **L = 3, 5, 7, 9, 11**, with **T = L**. At each point, the two arms
receive the **same sampled fault record**, the same final decoder, and the
same sample count. Z feedback is outside this study.

## Results

All **17,500 production pairs** are complete, in addition to the 600-pair
pilot. One-step feedback improves several larger-size points, but it can
worsen small-size performance. **Neither protocol passes every threshold
guard in this window; no threshold or exponent is reported.**

At the central sampled error probability **p = 1.5%**, the paired results are:

| L | Final-only failure | One-step failure | Difference (percentage points) | Pointwise 95% interval for difference |
|---:|---:|---:|---:|---:|
| 3 | 7.6% (38/500) | 17.0% (85/500) | +9.4 | [+4.55, +14.06] |
| 5 | 16.0% (80/500) | 21.8% (109/500) | +5.8 | [−0.84, +12.32] |
| 7 | 27.6% (138/500) | 24.2% (121/500) | −3.4 | [−10.96, +4.23] |
| 9 | 39.2% (196/500) | 21.2% (106/500) | −18.0 | [−25.53, −10.11] |
| 11 | 48.6% (243/500) | 22.2% (111/500) | −26.4 | [−33.89, −18.38] |

Negative differences favor feedback. These estimates compare protocols at
fixed size and p; they do not establish a threshold shift. In particular,
the L=3 worsening rules out a blanket claim that one-step feedback improves
every size.

The one-step quadratic scaling fit has diagnostic candidate
**p₀ = 1.309767%**, **ν₀ = 1.074993**. Deviance **71.7048 / 30** gives
goodness p **2.86×10⁻⁵**, below the declared .01 cutoff. Adjacent-size
crossings occur near **1.044%, 1.357%, 1.760%, and 1.125%**, with no common
bracketing interval. All four mandatory sensitivity guards fail:

| One-step model/check | Diagnostic candidate p₀ | Goodness p | Sensitivity guard |
|---|---:|---:|---|
| Primary quadratic | 1.309767% | 2.86×10⁻⁵ | Primary lacks fit |
| Drop L=3 | 1.469378% | .1471 | Fails declared stability tolerance |
| Remove both endpoint rates | 1.328945% | 2.56×10⁻⁵ | Fails |
| Cubic | 1.279704% | 1.35×10⁻⁴ | Fails |
| Fixed 1/L correction | 1.855965% | .2037 | Fails declared stability tolerance |

Although 200/200 one-step bootstrap fits are numerically usable, they do not
override the failed model and sensitivity guards. Their conditional diagnostic
intervals are retained in the JSON, not presented as threshold confidence
intervals. The public `pc` and `nu` fields are null.

The final-only diagnostic candidate pins to the lower window edge, p=.0075,
with deviance 259.3923/30 and goodness p=2.31×10⁻³⁸. It has no adjacent-size
crossing and no numerically usable bootstrap fit. This window was selected
to probe feedback; it cannot resolve the lower-p final-only onset.

See the [failure curves with fitted insets](analysis/x-one-step-failure-rates.png),
[paired-difference figure](analysis/x-one-step-paired-differences.png),
[full fit report](analysis/report.json), and
[paired numerical results](analysis/paired-differences.csv).

## Protocol

The circuit is the existing legacy plaquette-transfer H+6-CNOT circuit.
The initial logical state is ideal encoded `|00>`, with no noisy seed gates.
Independent X faults of probability `p` occur after each participating gate
output: `13 L^3` fault locations. Measurements, classical processing, Pauli
corrections, and idles are ideal.

For one-step feedback, the old active slice's Z-type compatibility checks
are measured before each transfer. Global unit-weight MWPM pairs the measured
defects. The route retains the first and last distinct edge of each matching
path. After the noisy transfer, the propagated image of this partial route is
applied to fresh target qubits. Old physical data are unchanged; the partial
route need not clear the measured syndrome. “One-step” describes the retained
route, not one feedback application over the entire experiment. Classical
matching is global over the slice.

Both arms end with exactly one full-plaquette BP+OSD recovery, with a uniform
declared physical-p prior, 50 minimum-sum BP iterations, parallel schedule,
scaling factor 1, one thread, and OSD_CS order 2. Complete recoveries are
syndrome-validated. State failure is the union of the two residual logical-X
parities. The baseline arm performs no intermediate feedback.

The old runner metadata calls the intermediate measurement an “active-slice
star” measurement and loosely describes its timing. The source implementation
measures Z-type Q compatibility checks before the transfer and applies the
target correction afterwards, as described above. Original metadata is kept
unchanged; this correction is also recorded in `provenance.json`.

## Pilot and frozen follow-up

The pilot contains 600 paired samples: 20 at each combination of the five
sizes and `p = 0, .005, .010, .015, .020, .025`. It includes a zero-noise sanity
check and brackets the feedback rise. These sparse pilot counts support
runtime and grid selection, not threshold estimation.

The follow-up selection was saved before production in `selection.json`:

| Sizes | Probabilities | Paired samples per point |
|---|---|---:|
| 3, 5, 7, 9, 11 | .0075, .0100, .0125, .0150, .0175, .0200, .0225 | 500 |

This is 35 points and 17,500 independent fault records, each replayed through
two protocols, giving 35,000 protocol outcomes. Production seeds are disjoint
from the pilot. Historical data and pilot counts are excluded from every
production fit. The window targets the feedback transition; it does not
resolve the much lower-p final-only onset.

The pilot measured about 0.26–0.37 seconds per paired L=11 sample over its
positive rates. To keep elapsed time practical, production runs as two
concurrent single-thread Julia processes: sizes 3–9 and size 11. This is not
an isolated-core timing benchmark. Sizes and sample counts remain identical
between the two protocol arms.

## Inference and limitations

Each protocol's marginal failure counts are fitted independently using the
same quadratic binomial-logit finite-size model and mandatory guard policy
as the preceding H+6 study. There must be at least four sizes and five rates,
an interior optimizer, monotone fitted probability, deviance goodness p≥.01,
and exactly one common adjacent-size crossing cluster containing the fitted
candidate. At least 80% of 200 parametric bootstrap fits must be usable, with
interior 95% intervals. All four sensitivity checks—dropping the smallest
size, removing both rate endpoints, adding a cubic term, and adding a fixed
1/L correction—must also pass and satisfy the declared stability tolerances.
A failed guard withholds the public threshold and exponent.

The results-local X-only analysis adapter was written and tested while
production was sampling, before production fitting. It reuses the frozen
numerical functions and guard policy and handles the two X protocols
explicitly.

Bootstrap intervals are conditional on the chosen marginal model. Separate
marginal bootstraps do not give a paired confidence interval for a threshold
difference. Pointwise feedback-minus-final differences instead use the saved
discordant counts and conservative approximate 95% intervals formed from two
97.5% Wilson intervals. These are pointwise intervals, without adjustment for
the number of plotted size-rate points.

The small sizes, 500 samples per point, baseline decoder, ideal measurements
and corrections, pure X noise, and specific seed preparation limit inference.
Observed improvement at fixed size and p does not by itself establish an
asymptotic threshold.

## Reproduction and provenance

Run from this repository using the recorded managed decoder environment:

```sh
sh results/toric3d-h6-one-step-2026-10-15/run.sh pilot-x
sh results/toric3d-h6-one-step-2026-10-15/run.sh production-small
sh results/toric3d-h6-one-step-2026-10-15/run.sh production-L11
```

These commands create fresh runs. To continue an existing run, append
`--resume`; verify the source/runtime hashes against `provenance.json` first.
The unchanged runner checks configuration equality, restores each exact
64-bit hexadecimal point seed, regenerates its Xoshiro stream, and skips
already sampled records. Checkpoints are atomically replaced TOML files
containing per-point counts. They are preserved with each run.

The master MersenneTwister seeds are 2026101503 for the pilot, 2026101504 for
production sizes 3–9, and 2026101505 for production L=11. Each master draws the
point seeds in size-major, rate-minor order. Preserve the existing sampler:
it consumes both X draws and zero-probability Z draws. Warmup and timing
samples are excluded from scientific counts.

`provenance.json` records source hashes, the original source commit, Python
versions, and the exact launch script. The simulation source, earlier result
directories, and `document/note.tex` are unchanged. Each shard contains raw
counts, metadata, checkpoint, timing records, execution logs, and its original
comparison plots. Analysis and independent verification are saved separately
under `analysis/` and `verification/`.

The Julia runtime is 1.12.6. The unchanged dependency manifest and complete
Python package inventory are preserved with the preceding study in
[Manifest.snapshot.toml](../toric3d-h6-final-only-2026-10-15/Manifest.snapshot.toml)
and [requirements-python.txt](../toric3d-h6-final-only-2026-10-15/requirements-python.txt).
This study's provenance checks the manifest hash and records the numerical,
decoder, and plotting package versions actually used.

After both production shards complete, analyze and audit them with:

```sh
export PYTHONDONTWRITEBYTECODE=1 MPLCONFIGDIR=/tmp/toponoise-h6-mpl
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
study=results/toric3d-h6-one-step-2026-10-15
python_exe=/Users/rongyuqing/jcode/TopoNoise.jl/.CondaPkg/.pixi/envs/default/bin/python
"$python_exe" "$study/analysis/analyze.py" \
  --input-dir "$study/production-small" --input-dir "$study/production-L11"
"$python_exe" "$study/verification/audit_artifacts.py" --require-complete
```

Analysis writes a JSON fit report, all marginal points, paired differences,
bootstrap samples, sensitivity fits, a two-panel failure-rate figure with
fit insets, and a separate paired-difference figure. PNG, PDF, and SVG
versions are preserved.

## Verification

- Existing focused Julia regressions: **4,218 assertions passed**; existing
  Python fitter regressions: **9 tests passed**.
- Results-local analysis adapter: **8 tests passed**, including exact paired
  statistics, frozen selection/provenance, known synthetic scaling, and a
  rendered check that the insets do not cover production points or error bars.
- Independent artifact auditor: **32 tests passed**, including adversarial
  counts, seed/checkpoint changes, fit guards, portable provenance, and
  feasibility of a common four-logical-bit joint distribution.
- Independent complete seeded replays: pilot L=3,p=.015 (20 pairs; 558
  assertions), production L=9,p=.015 (500 pairs; 526 assertions), and
  production L=11,p=.015 (500 pairs; 190 assertions). Every saved marginal
  and paired count matched. The production replays regenerate every point
  seed across both shards and verify all 56 frozen file hashes.
- Final PNGs were visually inspected. A layout regression caught an inset
  covering a baseline data point; the revised common-scale layout preserves
  all points and intervals. The complete numerical fit results are identical
  before and after this plotting-only revision.

The [independent review](verification/independent-review.md),
[artifact audit](verification/audit.json),
[replay records](verification/replay-L11-p015.toml), and
[visual review](verification/visual-review.json) provide the evidence and
limits of these checks. The audit independently reconstructs model
probabilities, deviances, crossing clusters, bootstrap quantiles, sensitivity
guard decisions, and paired statistics. It does not independently repeat
every optimizer run. Nineteen observed checkpoint snapshots are preserved;
they are a sample of the atomic checkpoints, not a complete batch history.

The raw metadata's legacy wording is documented above. Earlier test-invocation
and test-first RED logs are retained as development evidence; they are not
unresolved simulation failures. No simulator code or `document/note.tex` was
changed. Work is retained locally without a push or merge.
