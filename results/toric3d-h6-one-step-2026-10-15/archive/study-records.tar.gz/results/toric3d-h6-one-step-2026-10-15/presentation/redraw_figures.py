#!/usr/bin/env python3
"""Restyle saved H+6 results without resampling or changing any fitted model."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

os.environ.setdefault('MPLCONFIGDIR', '/tmp/toponoise-h6-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import expit

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'examples'))
from plotting_theme import paper_theme, save_figure, style_axes, STYLE_PATH

SPEC = importlib.util.spec_from_file_location('one_step_saved_analysis', STUDY / 'analysis/analyze.py')
ANALYSIS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ANALYSIS)
COLORS = {3: '#7F7F7F', 5: '#0072B2', 7: '#E69F00', 9: '#009E73', 11: '#CC79A7'}
XLABEL = r'Physical X fault probability $p$'
YLABEL = 'Logical X state failure rate'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def draw_points(axis, points, *, collapse=None, small=False):
    for size in sorted({r['steps'] for r in points}):
        rows = sorted((r for r in points if r['steps'] == size), key=lambda r: r['p'])
        x = np.array([r['p'] for r in rows])
        if collapse is not None:
            x = (x - collapse['pc']) * size ** (1 / collapse['nu'])
        y = np.array([r['failures'] / r['shots'] for r in rows])
        ci = np.array([ANALYSIS.H6.wilson_interval(r['failures'], r['shots']) for r in rows])
        axis.errorbar(x, y, yerr=np.maximum(0, [y - ci[:, 0], ci[:, 1] - y]),
                      color=COLORS[size], marker='o', label=fr'$L={size}$',
                      ms=2.6 if small else 3.8, lw=0.9 if small else 1.5,
                      elinewidth=0.65 if small else 0.85, capsize=1.4 if small else 2.2,
                      zorder=3)


def draw_collapse(axis, points, fit, *, small=False):
    draw_points(axis, points, collapse=fit, small=small)
    x = [(r['p'] - fit['pc']) * r['steps'] ** (1 / fit['nu']) for r in points]
    grid = np.linspace(min(x), max(x), 300)
    normalized = grid / (fit['p_scale'] * fit['L_reference'] ** (1 / fit['nu']))
    axis.plot(grid, expit(np.polynomial.polynomial.polyval(normalized, fit['coefficients'])),
              color='0.2', lw=1.0 if small else 1.4, zorder=2)
    axis.set(xlabel=r'$(p-p_c)L^{1/\nu}$', ylabel='Logical error' if small else YLABEL)
    style_axes(axis, inset=small)
    axis.margins(x=.05, y=.12)


def collapse_inset(axis, points, fit, *, title, bounds):
    inset = axis.inset_axes(bounds)
    draw_collapse(inset, points, fit, small=True)
    inset.set_title(title, fontsize=8, pad=4)
    inset.locator_params(axis='x', nbins=4)
    inset.locator_params(axis='y', nbins=3)
    return inset


def base_axis(axis, title, *, top):
    style_axes(axis)
    axis.set(title=title, xlabel=XLABEL, ylabel=YLABEL, ylim=(0, top), xlim=(.007, .023))
    axis.set_xticks([.0075, .010, .0125, .015, .0175, .020, .0225])
    axis.tick_params(axis='x', labelsize=9)


def all_axes(figure):
    def descendants(axis):
        yield axis
        for child in axis.child_axes:
            yield from descendants(child)
    for axis in figure.axes:
        yield from descendants(axis)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE)
    args = parser.parse_args()
    raw, provenance, _ = ANALYSIS.load_inputs([STUDY / 'production-small', STUDY / 'production-L11'])
    points = {p: ANALYSIS.adapt_points(raw, p) for p in ('final_only', 'one_step')}
    report = json.loads((STUDY / 'analysis/report.json').read_text())
    diagnostic = json.loads((HERE / 'near-critical-fits.json').read_text())
    assert diagnostic['points'] == points['one_step'], 'Diagnostic and production samples differ'
    local = next(r for r in diagnostic['results'] if r['min_L'] == 5 and r['p_min'] == .01 and r['p_max'] == .02)
    local_fit = local['fit']
    local_points = [r for r in points['one_step'] if r['steps'] >= 5 and .01 <= r['p'] <= .02]
    assert diagnostic['results'][0]['fit']['pc'] == report['fits']['one_step']['candidate']['pc']
    figures = []
    with paper_theme():
        fig, ax = plt.subplots(figsize=(7.8, 5.2))
        base_axis(ax, 'H+6 · X one-step feedback', top=.74)
        ax.axvspan(.01, .02, color='0.2', alpha=.055, lw=0, zorder=0)
        ax.axvline(local_fit['pc'], color='0.35', ls='--', lw=1, zorder=1)
        draw_points(ax, points['one_step'])
        collapse_inset(ax, local_points, local_fit, title='Local collapse · L ≥ 5', bounds=[.12, .62, .42, .29])
        ax.text(.04, .51, 'Exploratory local fit\n' + fr'$p_c={local_fit["pc"]:.5f}$' + '\n' +
                fr'$\nu={local_fit["nu"]:.2f}$' + '\nNo validated threshold',
                transform=ax.transAxes, ha='left', va='top', fontsize=10)
        ax.legend(loc='lower right', ncol=2, fontsize=9)
        fig.text(.12, .025, '95% Wilson bars · shade: fit window, not confidence interval · T = L', fontsize=9)
        fig.subplots_adjust(left=.12, right=.97, bottom=.16, top=.90)
        figures.append((fig, 'x-one-step-local-fit'))

        fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.6), sharey=True)
        for ax, protocol, title in zip(axes, ('final_only', 'one_step'),
                                      ('Final-only recovery', 'One-step feedback + final recovery')):
            base_axis(ax, title, top=1)
            draw_points(ax, points[protocol])
            collapse_inset(ax, points[protocol], report['fits'][protocol]['candidate'],
                           title='Original diagnostic fit · rejected', bounds=[.12, .69, .44, .24])
            ax.text(.97, .75, 'Threshold unresolved', transform=ax.transAxes, ha='right', fontsize=10)
            ax.legend(loc='upper right', ncol=2, fontsize=9)
        fig.text(.07, .025, 'H+6 · X faults · T = L · same 500 sampled fault records per point in both protocols · 95% Wilson bars', fontsize=9)
        fig.subplots_adjust(left=.07, right=.98, bottom=.16, top=.89, wspace=.24)
        figures.append((fig, 'x-one-step-failure-rates'))

        fig, ax = plt.subplots(figsize=(7.8, 5.2))
        for size in COLORS:
            rows = [r for r in raw if r['steps'] == size]
            paired = [ANALYSIS.paired_summary(r) for r in rows]
            y = np.array([r['difference'] for r in paired])
            ax.errorbar([r['p'] for r in rows], y,
                        yerr=np.maximum(0, [y - np.array([r['ci_low'] for r in paired]),
                                           np.array([r['ci_high'] for r in paired]) - y]),
                        marker='o', color=COLORS[size], label=fr'$L={size}$', elinewidth=.85)
        ax.axhline(0, color='0.35', ls='--', lw=.9)
        style_axes(ax)
        ax.set(title='H+6 · Effect of X one-step feedback', xlabel=XLABEL,
               ylabel='Failure rate: one-step − final-only', xlim=(.007, .023), ylim=(-.52, .27))
        ax.legend(loc='lower left', ncol=3, fontsize=9)
        ax.text(.97, .04, 'Negative favors feedback', transform=ax.transAxes, ha='right', fontsize=9)
        fig.text(.14, .025, 'Pointwise conservative 95% paired intervals · no multiple-comparison adjustment', fontsize=8.5)
        fig.subplots_adjust(left=.14, right=.97, bottom=.16, top=.90)
        figures.append((fig, 'x-one-step-paired-differences'))

        fig, axes = plt.subplots(1, 2, figsize=(12.6, 4.9), sharey=True)
        for ax, selected, fit, title in (
            (axes[0], points['one_step'], report['fits']['one_step']['candidate'], 'Original fit · all sizes'),
            (axes[1], local_points, local_fit, 'Local fit · L ≥ 5, p = 0.01–0.02'),
        ):
            draw_collapse(ax, selected, fit)
            ax.set(title=title, ylim=(0, .74))
            ax.text(.03, .96, fr'Candidate $p_c={fit["pc"]:.5f}$' + '\n' +
                    fr'$\nu={fit["nu"]:.2f}$' + '\n' + f'Fit p-value = {fit["deviance_p_value"]:.3g}',
                    transform=ax.transAxes, va='top', fontsize=10)
            ax.legend(loc='lower right', ncol=2, fontsize=9)
        fig.text(.07, .025, 'H+6 · X one-step · 95% Wilson bars · quadratic-logit fits · local fit is exploratory', fontsize=9)
        fig.subplots_adjust(left=.07, right=.98, bottom=.17, top=.89, wspace=.19)
        figures.append((fig, 'x-one-step-scaling-collapse'))

        outputs = []
        for figure, name in figures:
            figure.canvas.draw()
            for axis in all_axes(figure):
                assert not any(line.get_visible() for line in axis.get_xgridlines() + axis.get_ygridlines())
            outputs.extend(save_figure(figure, args.output / name))
            plt.close(figure)
    sources = [STYLE_PATH, ROOT / 'examples/plotting_theme.py', Path(__file__),
               HERE / 'near-critical-fits.json', STUDY / 'analysis/report.json', STUDY / 'analysis/analyze.py']
    manifest = {'description': 'Presentation-only redraw; no sampling or refitting.',
                'theme': str(STYLE_PATH.relative_to(ROOT)), 'grids_visible': False,
                'local_fit_status': 'exploratory; no threshold confidence interval',
                'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sources},
                'production_inputs': provenance,
                'outputs': {str(p.name): digest(p) for p in outputs}}
    (args.output / 'redraw-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'Wrote {len(figures)} figures in PNG/PDF/SVG; all main and inset grids verified off.')


if __name__ == '__main__':
    main()
