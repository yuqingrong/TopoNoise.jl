# Figures in the paper theme

These are presentation-only redraws in the requested reference style, with
no gridlines. All four figures are available as 300-dpi PNG, PDF, and SVG.

- [One-step curves with a local-collapse inset](x-one-step-local-fit.png)
- [Final-only and one-step comparison](x-one-step-failure-rates.png)
- [Paired differences](x-one-step-paired-differences.png)
- [Original and local scaling collapses](x-one-step-scaling-collapse.png)

The reusable theme is
[`examples/styles/paper-no-grid.mplstyle`](../../../examples/styles/paper-no-grid.mplstyle),
with [usage instructions](../../../examples/styles/README.md).
Size colors are consistent across all four figures: gray for L=3, blue for
L=5, orange for L=7, green for L=9, and pink for L=11.

The redraw reads the original production records and saved fits. It performs
no simulation or parameter fitting and leaves the audited analysis unchanged.
Main curves retain all 35 production points. Wilson error bars are 95%
intervals; difference bars retain the original conservative paired intervals.

The exploratory local inset uses only L=5,7,9,11 and p=0.010–0.020, totaling
20 points. Its saved candidate is pc=0.015037596830288196 and
nu=1.1773374135485979. The gray band shows the fitting window, not a confidence
interval. No validated threshold or local parameter confidence interval is
claimed. The paired comparison retains the original rejected diagnostic fits.
The scaling variable uses lattice size L, not code distance d.

`near-critical-fits.json` preserves the nine exploratory fits shown in the
preceding discussion. The renderer verifies that its samples equal the
production samples and transforms the stored normalized scaling coordinate
before evaluating the fitted curves. `redraw-manifest.json` records source
and output hashes, together with production-input provenance.

From the repository root, using the analysis Python environment described
in the study README:

```sh
python -B results/toric3d-h6-one-step-2026-10-15/presentation/redraw_figures.py
```

An optional `--output /path/to/figures` selects another output directory.
