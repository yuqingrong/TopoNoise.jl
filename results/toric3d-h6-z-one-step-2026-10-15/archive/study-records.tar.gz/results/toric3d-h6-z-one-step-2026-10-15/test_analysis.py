import importlib.util
import importlib.metadata
import copy
import csv
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

PATH = Path(__file__).with_name('analyze.py')
M = None
if PATH.exists():
    spec = importlib.util.spec_from_file_location('z_one_step_analysis', PATH)
    M = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(M)


class JointAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(M, 'The four-arm analysis has not been implemented')

    def test_all_joint_masks_and_direction(self):
        for mask in range(16):
            joint = [0] * 16
            joint[mask] = 50
            for a in range(4):
                for b in range(4):
                    if a == b:
                        continue
                    result = M.paired(joint, M.ARMS[a], M.ARMS[b])
                    self.assertEqual(result['difference'], bool(mask & (1 << b)) - bool(mask & (1 << a)))
                    self.assertEqual(sum(result[k] for k in ('neither', 'both', 'first_only', 'second_only')), 50)
                    self.assertLessEqual(result['ci_low'], result['difference'])
                    self.assertGreaterEqual(result['ci_high'], result['difference'])

    def test_known_discordant_counts(self):
        joint = [0] * 16
        joint[0], joint[1], joint[4], joint[5] = 50, 30, 10, 10
        result = M.paired(joint, 'final_only', 'one_step')
        self.assertEqual(result['difference'], -.2)
        self.assertEqual((result['first_only'], result['second_only']), (30, 10))
        self.assertAlmostEqual(result['standard_error'], ((.4 - .2**2) / 99)**.5)

    def test_joint_marginals_and_logical_union_validation(self):
        joint = list(range(16))
        row = dict(steps=3, Ly=3, Lz=3, p=.02, shots=sum(joint), target_shots=sum(joint),
                   seed=1234, point_seed='0123456789abcdef', complete='true', elapsed_seconds=1)
        for mask, n in enumerate(joint):
            row[f'joint_{mask:02d}'] = n
        for i, arm in enumerate(M.ARMS):
            count = sum(n for mask, n in enumerate(joint) if mask & (1 << i))
            row[arm + '_failures'] = count
            row[arm + '_logical_1_failures'] = count
            row[arm + '_logical_2_failures'] = 0
        parsed = M.validate_point(row)
        self.assertEqual(parsed['joint'], joint)
        self.assertEqual(parsed['point_seed'], row['point_seed'])
        invalid = dict(row, one_step_failures=row['one_step_failures'] + 1)
        with self.assertRaises(ValueError):
            M.validate_point(invalid)
        invalid = dict(row, one_step_logical_1_failures=0)
        with self.assertRaises(ValueError):
            M.validate_point(invalid)

    def test_partial_points_and_invalid_counts_rejected(self):
        with self.assertRaises(ValueError):
            M.paired([0] * 16, 'final_only', 'one_step')
        with self.assertRaises(ValueError):
            M.paired([-1] + [2] * 15, 'final_only', 'one_step')
        with self.assertRaises(ValueError):
            M.validate_point(dict(complete='false'))


def fixture_toml(data):
    """Small TOML fixture writer; exercise the actual file-reading boundary."""
    def value(item):
        if isinstance(item, dict):
            return '{' + ', '.join(json.dumps(k) + ' = ' + value(v) for k, v in item.items()) + '}'
        if isinstance(item, list):
            return '[' + ', '.join(value(v) for v in item) + ']'
        return json.dumps(item)
    return ''.join(json.dumps(k) + ' = ' + value(v) + '\n' for k, v in data.items())


class InputIntegrityTests(unittest.TestCase):
    def fixture(self, parent, name='input', sizes=(3,), seed=1234):
        directory = Path(parent) / name
        directory.mkdir()
        config = dict(sizes=list(sizes), rates=[0., .01], shots=4, seed=seed,
                      batch_size=2, dimensions=[[L, L, L] for L in sizes])
        runtime = dict(julia_version='1.12.0', julia_threads=1, blas_threads=1,
                       python_executable=sys.executable, python_version=sys.version,
                       packages={n: importlib.metadata.version(n) for n in ('numpy', 'scipy', 'pymatching')},
                       environment={k: '1' for k in ('JULIA_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                                                     'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
        runtime['environment'].update(JULIA_CONDAPKG_BACKEND='Null', JULIA_PYTHONCALL_EXE=sys.executable)
        protocol = dict(circuit='legacy H+6-CNOT plaquette transfer', channel='z_only',
                        geometry='T=L; Ly=Lz=L', initial_state='logical |++>', arm_order=list(M.ARMS),
                        final_only='no seed or intermediate correction; one final MWPM',
                        seed_only='complete seed correction; no intermediate correction; one final MWPM',
                        one_step='complete seed correction; causal local one-step intermediate correction; one final MWPM',
                        window_complete='complete seed correction and full local-window recovery; one final MWPM',
                        noise='independent Bernoulli-p Z faults on 3 L^2 seed-H outputs and 13 L^3 transfer outputs',
                        sampler='sample_toric3d_diagonal_z_faults: seed bits first, then participating transfer outputs in schedule order',
                        shared_final_decoder='family.prefixes[end], unit-weight data-edge PyMatching MWPM, syndrome-validated recovery',
                        failure='either residual logical-Z parity after final recovery',
                        joint_histogram_encoding='mask = final_only + 2*seed_only + 4*one_step + 8*window_complete; each term is its state-failure Boolean',
                        point_order='sizes outer loop, rates inner loop; both strictly increasing',
                        point_seed_generation='MersenneTwister(integer base seed); repeated scalar rand(rng,UInt64); discard duplicate values; 16 lowercase hexadecimal digits',
                        point_rng='Random.Xoshiro(point_seed)',
                        resume='recreate point Xoshiro and sample/discard completed records without decoding; rebuild raw CSV from authoritative checkpoint')
        sources = [M.ROOT / 'Project.toml', PATH.with_name('run_study.jl'), *sorted((M.ROOT / 'src').rglob('*.jl'))]
        if (M.ROOT / 'Manifest.toml').exists():
            sources.append(M.ROOT / 'Manifest.toml')
        hashes = {str(p.relative_to(M.ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
        rows, states, seeds = [], [], []
        for L in sizes:
            for rate in config['rates']:
                index = len(rows)
                point_seed = f'{seed + index:016x}'
                joint = [3] + [0] * 14 + [1]
                row = dict(steps=L, Ly=L, Lz=L, p=rate, shots=4, target_shots=4,
                           seed=seed, point_seed=point_seed, complete='true', elapsed_seconds=.25)
                for arm in M.ARMS:
                    row.update({arm + '_logical_1_failures': 1, arm + '_logical_2_failures': 0,
                                arm + '_failures': 1})
                row.update({f'joint_{mask:02d}': n for mask, n in enumerate(joint)})
                rows.append(row)
                states.append(dict(completed_shots=4, logical_1_counts=[1]*4,
                                   logical_2_counts=[0]*4, failures=[1]*4,
                                   joint_counts=joint, elapsed_seconds=.25))
                seeds.append(point_seed)
        checkpoint = dict(format_version=1, config=config, runtime=runtime, source_hashes=hashes,
                          protocol=protocol, point_seeds_hex=seeds, states=states, generation=3,
                          started_at_unix=100., updated_at_unix=101., payload_sha256='a'*64)
        self.seal(directory, rows, checkpoint)
        return directory, rows, checkpoint

    def seal(self, directory, rows, checkpoint):
        with (directory / 'raw.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        checkpoint_bytes = fixture_toml(checkpoint).encode()
        (directory / 'checkpoint.toml').write_bytes(checkpoint_bytes)
        snapshot = f'checkpoints/checkpoint-{checkpoint["generation"]:06d}-{checkpoint["payload_sha256"][:12]}.toml'
        (directory / 'checkpoints').mkdir(exist_ok=True)
        (directory / snapshot).write_bytes(checkpoint_bytes)
        metadata = {k: copy.deepcopy(checkpoint[k]) for k in ('format_version', 'config', 'runtime',
                    'source_hashes', 'protocol', 'point_seeds_hex', 'generation', 'started_at_unix', 'updated_at_unix')}
        metadata.update(expected_points=len(rows), completed_points=len(rows),
                        completed_shots=sum(r['shots'] for r in rows), complete=True,
                        raw_sha256=hashlib.sha256((directory / 'raw.csv').read_bytes()).hexdigest(),
                        checkpoint_sha256=hashlib.sha256(checkpoint_bytes).hexdigest(), current_snapshot=snapshot)
        (directory / 'metadata.toml').write_text(fixture_toml(metadata))
        return metadata

    def test_complete_shards_load_and_retain_exact_record_hashes(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, _, _ = self.fixture(tmp)
            second, _, _ = self.fixture(tmp, 'second', sizes=(5,), seed=4321)
            points, inputs = M.load_points([second, first])
            self.assertEqual([(r['steps'], r['p']) for r in points], [(3, 0.), (3, .01), (5, 0.), (5, .01)])
            self.assertEqual(inputs[0]['hashes']['raw.csv'], hashlib.sha256((second / 'raw.csv').read_bytes()).hexdigest())

    def test_embedded_python_compile_time_may_differ_but_release_must_match(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory, rows, checkpoint = self.fixture(tmp)
            # PythonCall loads libpython, whose build timestamp differs from the
            # executable's sys.version even within the same Conda installation.
            checkpoint['runtime']['python_version'] = sys.version.split()[0] + ' | separately compiled libpython'
            self.seal(directory, rows, checkpoint)
            try:
                points, _ = M.load_points([directory])
            except ValueError as error:
                self.fail(f'Same-release embedded Python was rejected: {error}')
            self.assertEqual(len(points), 2)
            checkpoint['runtime']['python_version'] = '0.0.0 | incompatible libpython'
            self.seal(directory, rows, checkpoint)
            with self.assertRaises(ValueError):
                M.load_points([directory])

    def test_row_identity_must_match_recorded_grid_and_config(self):
        mutations = ('rate', 'size', 'base_seed', 'shot_target', 'row_order', 'elapsed')
        for mutation in mutations:
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as tmp:
                directory, rows, checkpoint = self.fixture(tmp)
                if mutation == 'rate':
                    rows[1]['p'] = .02
                elif mutation == 'size':
                    for row in rows:
                        row.update(steps=5, Ly=5, Lz=5)
                elif mutation == 'base_seed':
                    rows[1]['seed'] += 1
                elif mutation == 'shot_target':
                    checkpoint['config']['shots'] = 8
                elif mutation == 'row_order':
                    rows.reverse()
                    checkpoint['states'].reverse()
                    checkpoint['point_seeds_hex'].reverse()
                else:
                    rows[1]['elapsed_seconds'] = 9.
                self.seal(directory, rows, checkpoint)
                with self.assertRaises(ValueError):
                    M.load_points([directory])

    def test_truncated_seeds_cannot_skip_checkpoint_count_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory, rows, checkpoint = self.fixture(tmp)
            checkpoint['point_seeds_hex'].pop()
            checkpoint['states'][1]['joint_counts'] = [4] + [0]*15
            self.seal(directory, rows, checkpoint)
            with self.assertRaises(ValueError):
                M.load_points([directory])

    def test_protocol_runtime_and_sources_must_describe_this_study(self):
        for mutation in ('circuit', 'arm_order', 'shared_decoder', 'threads', 'python', 'source_digest', 'missing_source'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as tmp:
                directory, rows, checkpoint = self.fixture(tmp)
                if mutation == 'circuit':
                    checkpoint['protocol']['circuit'] = 'H+5'
                elif mutation == 'arm_order':
                    checkpoint['protocol']['arm_order'].reverse()
                elif mutation == 'shared_decoder':
                    checkpoint['protocol']['shared_final_decoder'] = 'different decoder per arm'
                elif mutation == 'threads':
                    checkpoint['runtime']['environment']['OMP_NUM_THREADS'] = '2'
                elif mutation == 'python':
                    checkpoint['runtime']['packages']['scipy'] = '0.0.0'
                elif mutation == 'source_digest':
                    checkpoint['source_hashes']['src/toric3d/h6_z_one_step.jl'] = '0'*64
                else:
                    checkpoint['source_hashes'].pop('src/toric3d/h6_z_one_step.jl')
                self.seal(directory, rows, checkpoint)
                with self.assertRaises(ValueError):
                    M.load_points([directory])

    def test_metadata_integrity_and_completion_are_required(self):
        for mutation in ('raw_hash', 'checkpoint_hash', 'config', 'protocol', 'seeds', 'complete', 'total', 'generation'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as tmp:
                directory, rows, checkpoint = self.fixture(tmp)
                metadata = self.seal(directory, rows, checkpoint)
                if mutation in ('raw_hash', 'checkpoint_hash'):
                    metadata[mutation.replace('_hash', '_sha256')] = '0'*64
                elif mutation == 'config':
                    metadata['config']['seed'] += 1
                elif mutation == 'protocol':
                    metadata['protocol']['channel'] = 'x_only'
                elif mutation == 'seeds':
                    metadata['point_seeds_hex'].pop()
                elif mutation == 'complete':
                    metadata['complete'] = False
                elif mutation == 'total':
                    metadata['completed_shots'] -= 1
                else:
                    metadata['generation'] += 1
                (directory / 'metadata.toml').write_text(fixture_toml(metadata))
                with self.assertRaises(ValueError):
                    M.load_points([directory])

    def test_snapshot_must_be_exact_and_named_by_checkpoint(self):
        for mutation in ('missing', 'different', 'outside'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as tmp:
                directory, rows, checkpoint = self.fixture(tmp)
                metadata = self.seal(directory, rows, checkpoint)
                snapshot = directory / metadata['current_snapshot']
                if mutation == 'missing':
                    snapshot.unlink()
                elif mutation == 'different':
                    snapshot.write_bytes(snapshot.read_bytes() + b'\n')
                else:
                    metadata['current_snapshot'] = '../checkpoint.toml'
                    (directory / 'metadata.toml').write_text(fixture_toml(metadata))
                with self.assertRaises(ValueError):
                    M.load_points([directory])


class FrozenSelectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.selection_path = PATH.with_name('selection.json')
        cls.reference = json.loads(cls.selection_path.read_text())
        cls.points, cls.inputs = M.load_points([PATH.with_name('production')])

    def setUp(self):
        self.assertTrue(callable(getattr(M, 'validate_selection', None)),
                        'Frozen selection must be checked before fitting')
        self.selection = copy.deepcopy(self.reference)

    def check(self, selection=None, inputs=None, **overrides):
        options = dict(bootstrap=200, seed=2026101514)
        options.update(overrides)
        return M.validate_selection(self.points, inputs or self.inputs,
                                    self.selection if selection is None else selection,
                                    self.selection_path, **options)

    def test_actual_production_matches_frozen_selection_without_fitting(self):
        result = self.check()
        self.assertTrue(result['validated'])
        self.assertEqual(result['bootstrap_replicates'], 200)
        self.assertEqual(result['bootstrap_seed'], 2026101514)
        self.assertEqual(result['selection_sha256'], hashlib.sha256(self.selection_path.read_bytes()).hexdigest())

    def test_cli_cannot_override_bootstrap_replication_or_seed(self):
        for override in ({'bootstrap': 20}, {'seed': 2026101515}):
            with self.subTest(override=override), self.assertRaises(ValueError):
                self.check(**override)

    def test_shard_identity_master_seed_and_declared_totals_are_binding(self):
        for mutation in ('name', 'master_seed', 'sizes', 'total', 'outcomes', 'pilot_excluded'):
            with self.subTest(mutation=mutation):
                selection = copy.deepcopy(self.reference)
                if mutation == 'name':
                    selection['shards']['different-run'] = selection['shards'].pop('production')
                elif mutation == 'master_seed':
                    selection['shards']['production']['seed'] += 1
                elif mutation == 'sizes':
                    selection['shards']['production']['sizes'].pop()
                elif mutation == 'total':
                    selection['total_fault_records'] -= 1
                elif mutation == 'outcomes':
                    selection['total_protocol_outcomes'] -= 1
                else:
                    selection['pilot_excluded'] = False
                with self.assertRaises(ValueError):
                    self.check(selection)

    def test_selection_must_precede_production_and_follow_completed_pilot(self):
        earliest = min(item['metadata']['started_at_unix'] for item in self.inputs)
        for frozen in (earliest, earliest + 1., 1., float('nan')):
            with self.subTest(frozen=frozen):
                selection = copy.deepcopy(self.reference)
                selection['frozen_at_unix'] = frozen
                with self.assertRaises(ValueError):
                    self.check(selection)
        self.selection['frozen_before_sampling'] = False
        with self.assertRaises(ValueError):
            self.check()

    def test_pilot_and_numerical_source_hashes_cannot_be_omitted_or_changed(self):
        for group in ('pilot_input_sha256', 'pilot_source_sha256', 'numerical_fit_source_sha256'):
            for mutation in ('changed', 'missing'):
                with self.subTest(group=group, mutation=mutation):
                    selection = copy.deepcopy(self.reference)
                    key = next(iter(selection[group]))
                    if mutation == 'changed':
                        selection[group][key] = '0'*64
                    else:
                        selection[group].pop(key)
                    with self.assertRaises(ValueError):
                        self.check(selection)

    def test_primary_window_cannot_silently_drop_absent_or_zero_rates(self):
        for rate in (0., .12345):
            with self.subTest(rate=rate):
                self.selection['fit_rates'] = [rate] + self.reference['fit_rates']
                with self.assertRaises(ValueError):
                    self.check()

    def test_main_rejects_override_before_fitter_is_reached(self):
        with tempfile.TemporaryDirectory() as tmp:
            argv = ['analyze.py', '--input', str(PATH.with_name('production')),
                    '--selection', str(self.selection_path), '--output', tmp, '--bootstrap', '20']
            with mock.patch.object(sys, 'argv', argv), mock.patch.object(
                    M, 'scaling_diagnostics', side_effect=AssertionError('Unvalidated data reached fitting')):
                with self.assertRaises(ValueError):
                    M.main()
            self.assertFalse((Path(tmp) / 'report.json').exists())


class PlotContractTests(unittest.TestCase):
    def test_other_supported_sizes_render_and_intervals_are_labeled_approximately(self):
        points, marginals, differences = [], [], []
        for L in (2, 13):
            for p in (.01, .02):
                points.append(dict(steps=L, p=p))
                for arm in M.ARMS:
                    marginals.append(dict(arm=arm, L=L, p=p, rate=.25, ci_low=.10, ci_high=.50))
                for first in ('final_only', 'seed_only', 'window_complete'):
                    differences.append(dict(first=first, second='one_step', L=L, p=p,
                                            difference=-.1, ci_low=-.3, ci_high=.1))
        with tempfile.TemporaryDirectory() as tmp:
            try:
                M.plot_figures(points, marginals, differences, None, Path(tmp))
            except KeyError as error:
                self.fail(f'Supported lattice size failed to render: {error}')
            self.assertEqual(len(list(Path(tmp).glob('*.png'))), 3)
            svg = (Path(tmp) / 'z-one-step-paired-differences.svg').read_text()
            self.assertIn('approximate pointwise 95% paired intervals (Bonferroni–Wilson)', svg)
            self.assertNotIn('conservative 95%', svg)


if __name__ == '__main__':
    unittest.main()
