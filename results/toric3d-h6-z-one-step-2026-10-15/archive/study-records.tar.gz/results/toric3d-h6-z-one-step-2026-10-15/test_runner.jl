using Test, Random, TopoNoise
import TOML, SHA

const Z_RUNNER_PATH = joinpath(@__DIR__,"run_study.jl")
@testset "H+6 four-arm Z runner exists" begin
    @test isfile(Z_RUNNER_PATH)
end

if isfile(Z_RUNNER_PATH)
include(Z_RUNNER_PATH)

function z_runner_args(directory;rates="0,.05",shots="4",seed="1234",extra=String[])
    return vcat(["--output",directory,"--sizes","2","--rates",rates,
        "--shots",shots,"--seed",seed,"--batch-size","2"],extra)
end

function z_runner_counts(path)
    rows=split.(readlines(path),',')
    # The sole intentionally nondeterministic field is elapsed wall time.
    return [row[[1:9;11:length(row)]] for row in rows]
end

@testset "H+6 Z CLI and joint histogram contracts" begin
    options=H6ZOneStepStudy.parse_arguments(z_runner_args("out"))
    @test options.config["sizes"] == [2]
    @test options.config["rates"] == [0.0,0.05]
    @test !options.resume
    @test options.max_batches == typemax(Int)
    @test H6ZOneStepStudy.failure_mask((true,false,true,false)) == 5
    @test H6ZOneStepStudy.failure_mask((false,true,false,true)) == 10
    seeds=H6ZOneStepStudy.point_seeds(1234,10)
    @test length(unique(seeds)) == 10
    @test seeds == H6ZOneStepStudy.point_seeds(1234,10)
    @test seeds != H6ZOneStepStudy.point_seeds(1235,10)
    for extra in (["--sizes","2,2"],["--sizes","1"],["--rates",".05,.01"],
            ["--rates",".05,.05"],["--rates","-.01"],["--rates",".5"],
            ["--shots","0"],["--seed","-1"],["--batch-size","0"],
            ["--max-batches","0"],["--unknown","1"])
        args=z_runner_args("out")
        index=findfirst(==(extra[1]),args)
        index === nothing ? append!(args,extra) : (args[index+1]=extra[2])
        @test_throws ArgumentError H6ZOneStepStudy.parse_arguments(args)
    end
    @test_throws ArgumentError H6ZOneStepStudy.parse_arguments(["--output"])
end

@testset "H+6 Z resume restores the exact next immutable record" begin
    @test isdefined(H6ZOneStepStudy,:resume_rng)
    if isdefined(H6ZOneStepStudy,:resume_rng)
        encoder=toric3d_encoded_encoder(Toric3DEncodedSlice(2,2,2))
        rng=Random.Xoshiro(UInt64(0x1234))
        records=[sample_toric3d_diagonal_z_faults(rng,encoder;p=.05) for _ in 1:4]
        for completed in 0:3
            resumed=H6ZOneStepStudy.resume_rng(UInt64(0x1234),completed,encoder,.05)
            @test sample_toric3d_diagonal_z_faults(resumed,encoder;p=.05) == records[completed+1]
        end
        mktempdir() do directory
            H6ZOneStepStudy.dump_failure(directory,(L=2,p=.05),UInt64(0x1234),3,records[3],ErrorException("invariant fixture"))
            dump=TOML.parsefile(joinpath(directory,"failed-record.toml"))
            @test dump["point_seed_hex"] == "0000000000001234"
            @test dump["shot_index"] == 3
            @test dump["dimensions"] == [2,2,2]
            @test dump["seed_true_indices"] == findall(records[3].seed)
            @test dump["transfer_shape"] == collect(size(records[3].transfer.z))
            @test dump["transfer_z_true_indices"] == findall(vec(records[3].transfer.z))
        end
    end
end

@testset "H+6 Z tiny four-arm scan and exact partial resume" begin
    mktempdir() do directory
        direct=joinpath(directory,"direct")
        resumed=joinpath(directory,"resumed")
        # Stop inside the nonzero-noise point, not merely the zero-noise point.
        partial=H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(
            z_runner_args(resumed;extra=["--max-batches","3"]));io=devnull)
        @test partial["completed_shots"] == 6
        @test !partial["complete"]
        state=TOML.parsefile(joinpath(resumed,"checkpoint.toml"))
        @test [s["completed_shots"] for s in state["states"]] == [4,2]
        H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(
            z_runner_args(resumed;extra=["--resume"]));io=devnull)
        full=H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(z_runner_args(direct));io=devnull)
        @test full["complete"]
        @test full["completed_shots"] == 8
        @test length(readlines(joinpath(direct,"raw.csv"))) == 3
        @test haskey(full,"decoder_build_count_by_size")
        if haskey(full,"decoder_build_count_by_size")
            @test full["decoder_build_count_by_size"]["2"] == 1
            @test full["decoder_build_seconds_by_size"]["2"] >= 0
        end
        @test z_runner_counts(joinpath(direct,"raw.csv")) == z_runner_counts(joinpath(resumed,"raw.csv"))
        state=TOML.parsefile(joinpath(resumed,"checkpoint.toml"))
        @test state["states"][1]["joint_counts"] == [4;zeros(Int,15)]
        @test state["states"][1]["failures"] == zeros(Int,4)
        for point in state["states"]
            @test sum(point["joint_counts"]) == point["completed_shots"]
            for arm in 1:4
                marginal=sum(point["joint_counts"][mask+1] for mask in 0:15 if mask & (1 << (arm-1)) != 0)
                @test marginal == point["failures"][arm]
            end
        end
        raw_before=read(joinpath(resumed,"raw.csv"))
        checkpoint_before=read(joinpath(resumed,"checkpoint.toml"))
        complete=H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(
            z_runner_args(resumed;extra=["--resume"]));io=devnull)
        @test complete["complete"]
        @test read(joinpath(resumed,"raw.csv")) == raw_before
        @test read(joinpath(resumed,"checkpoint.toml")) == checkpoint_before
        @test complete["raw_sha256"] == bytes2hex(SHA.sha256(raw_before))
        @test_throws ArgumentError H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(z_runner_args(resumed));io=devnull)
        @test_throws ArgumentError H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(
            z_runner_args(resumed;shots="5",extra=["--resume"]));io=devnull)
        # A damaged checkpoint cannot be accepted merely because its counts look plausible.
        state["states"][2]["joint_counts"][1] += 1
        open(joinpath(resumed,"checkpoint.toml"),"w") do io
            TOML.print(io,state;sorted=true)
        end
        @test_throws ArgumentError H6ZOneStepStudy.run_study(H6ZOneStepStudy.parse_arguments(
            z_runner_args(resumed;extra=["--resume"]));io=devnull)
    end
end
end
