#!/usr/bin/env python3
"""Independent H+6 Z artifact audit; never imports simulation or analysis code."""
import argparse
import ast
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
import time
import tomllib
import unittest

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
ROOT = STUDY.parents[1]
ARMS = ('final_only', 'seed_only', 'one_step', 'window_complete')
NOTE_HASH = '3a40710c2ab6bd43e53f5f7703b7c8716b209dc1e060a5092f17e0edce073f3a'
HELPER = ROOT / 'results/toric3d-h6-one-step-2026-10-15/verification/audit_artifacts.py'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def independent_helpers():
    """Reuse independently derived statistics, never a fitter/analysis adapter."""
    if not hasattr(independent_helpers, 'module'):
        spec = importlib.util.spec_from_file_location('independent_previous_audit', HELPER)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        independent_helpers.module = module
    return independent_helpers.module


def load_csv(path):
    with Path(path).open(newline='') as stream:
        return list(csv.DictReader(stream))


def load_toml(path):
    return tomllib.loads(Path(path).read_text())


def validate_payload(blob):
    data = tomllib.loads(blob.decode())
    # Julia's sorted writer inserts this one scalar line without changing any
    # other bytes. Verify the archived bytes, not Python's TOML serialization.
    body, count = re.subn(rb'^payload_sha256 = "[0-9a-f]{64}"\n', b'', blob, flags=re.M)
    require(count == 1 and hashlib.sha256(body).hexdigest() == data['payload_sha256'],
            'checkpoint payload checksum differs')
    return data


def validate_state(state, target):
    n = state['completed_shots']
    require(type(n) is int and 0 <= n <= target, 'invalid completed count')
    for field, length in (('joint_counts', 16), ('failures', 4), ('logical_1_counts', 4), ('logical_2_counts', 4)):
        vector = state[field]
        require(len(vector) == length and all(type(k) is int and 0 <= k <= n for k in vector), 'invalid '+field)
    require(sum(state['joint_counts']) == n, 'histogram total differs')
    for index in range(4):
        k = state['failures'][index]
        require(sum(v for mask, v in enumerate(state['joint_counts']) if mask & (1 << index)) == k,
                'histogram marginal differs')
        a, b = state['logical_1_counts'][index], state['logical_2_counts'][index]
        require(max(a, b) <= k <= min(n, a+b), 'logical union algebra differs')
    require(math.isfinite(state['elapsed_seconds']) and state['elapsed_seconds'] >= 0, 'invalid elapsed time')


def paired(joint, first, second):
    old = independent_helpers()
    n = sum(joint)
    a, b = 1 << ARMS.index(first), 1 << ARMS.index(second)
    cells = [sum(k for mask, k in enumerate(joint) if bool(mask & a) == x and bool(mask & b) == y)
             for x, y in ((False, False), (True, False), (False, True), (True, True))]
    neither, first_only, second_only, both = cells
    delta = (second_only-first_only)/n
    low_a, high_a = old.wilson(first_only, n, 2.241402727604947)
    low_b, high_b = old.wilson(second_only, n, 2.241402727604947)
    return dict(first=first, second=second, neither=neither, first_only=first_only,
                second_only=second_only, both=both, difference=delta,
                standard_error=math.sqrt(max(0., (first_only+second_only-n*delta*delta)/(n*(n-1)))) if n > 1 else None,
                ci_low=max(-1., low_b-high_a), ci_high=min(1., high_b-low_a))


def audit_directory(directory, expected, require_complete):
    checkpoint_bytes = (directory/'checkpoint.toml').read_bytes()
    checkpoint = validate_payload(checkpoint_bytes)
    metadata = load_toml(directory/'metadata.toml')
    rows = load_csv(directory/'raw.csv')
    require(not (directory/'failed-record.toml').exists(), 'failed simulation record exists')
    for key in ('format_version', 'config', 'runtime', 'protocol', 'source_hashes', 'point_seeds_hex',
                'started_at_unix', 'updated_at_unix', 'generation', 'decoder_build_count_by_size', 'decoder_build_seconds_by_size'):
        require(metadata[key] == checkpoint[key], 'metadata/checkpoint mismatch: '+key)
    config = checkpoint['config']
    for key, value in expected.items():
        require(config[key] == value, 'frozen configuration differs: '+key)
    require(config['dimensions'] == [[L,L,L] for L in config['sizes']], 'geometry differs')
    require(type(config['batch_size']) is int and config['batch_size'] > 0, 'invalid batch size')
    grid = [(L,p) for L in config['sizes'] for p in config['rates']]
    states, seeds = checkpoint['states'], checkpoint['point_seeds_hex']
    require(len(grid) == len(states) == len(rows) == len(seeds), 'grid length differs')
    require(len(set(seeds)) == len(seeds) and all(re.fullmatch('[0-9a-f]{16}', v) for v in seeds), 'hex seed identity')
    require(metadata['raw_sha256'] == digest(directory/'raw.csv') and
            metadata['checkpoint_sha256'] == hashlib.sha256(checkpoint_bytes).hexdigest(), 'raw/checkpoint file hash')
    parsed = []
    for row, state, seed, (L,p) in zip(rows, states, seeds, grid):
        validate_state(state, config['shots'])
        n = state['completed_shots']
        require([int(row[k]) for k in ('steps','Ly','Lz')] == [L,L,L] and float(row['p']) == p, 'row grid identity')
        require(int(row['seed']) == config['seed'] and row['point_seed'] == seed, 'row seed identity')
        require(int(row['shots']) == n and int(row['target_shots']) == config['shots'] and
                row['complete'] == str(n == config['shots']).lower(), 'row completeness')
        require(float(row['elapsed_seconds']) == state['elapsed_seconds'], 'row timing')
        require([int(row[f'joint_{i:02d}']) for i in range(16)] == state['joint_counts'], 'row joint histogram')
        for i, arm in enumerate(ARMS):
            for key, suffix in (('logical_1_counts','logical_1_failures'),('logical_2_counts','logical_2_failures'),('failures','failures')):
                require(int(row[arm+'_'+suffix]) == state[key][i], 'row arm counts')
        if p == 0:
            require(not any(state['failures']), 'zero-noise failure')
        parsed.append(dict(L=L, p=p, shots=n, point_seed=seed, state=state))
    count = sum(s['completed_shots'] == config['shots'] for s in states)
    complete = count == len(states)
    require(metadata['completed_points'] == count and metadata['expected_points'] == len(states)
            and metadata['completed_shots'] == sum(s['completed_shots'] for s in states)
            and metadata['complete'] == complete, 'metadata completeness differs')
    require(not require_complete or complete, 'production incomplete')
    fixed = ('format_version','config','runtime','protocol','source_hashes','point_seeds_hex','started_at_unix')
    snapshots, previous = {}, None
    for generation, path in enumerate(sorted((directory/'checkpoints').glob('*.toml')), 1):
        blob = path.read_bytes(); saved = validate_payload(blob)
        require(saved['generation'] == generation and path.name == f'checkpoint-{generation:06d}-{saved["payload_sha256"][:12]}.toml', 'snapshot order/name')
        require(all(saved[k] == checkpoint[k] for k in fixed), 'snapshot fixed provenance differs')
        require(len(saved['states']) == len(states), 'snapshot state count')
        require(saved['started_at_unix'] <= saved['updated_at_unix'] <= checkpoint['updated_at_unix'], 'snapshot time ordering')
        for i, state in enumerate(saved['states']):
            validate_state(state, config['shots'])
            if previous:
                old = previous['states'][i]
                require(state['completed_shots'] >= old['completed_shots'] and state['elapsed_seconds'] >= old['elapsed_seconds'], 'snapshot count/time decreased')
                for key in ('joint_counts','failures','logical_1_counts','logical_2_counts'):
                    require(all(a <= b for a,b in zip(old[key],state[key])), 'snapshot histogram decreased')
        require(previous is None or previous['updated_at_unix'] <= saved['updated_at_unix'], 'snapshot clock decreased')
        if previous is None:
            require(not any(s['completed_shots'] for s in saved['states']), 'initial snapshot contains samples')
        previous = saved
        snapshots[str(path.relative_to(directory))] = hashlib.sha256(blob).hexdigest()
    require(previous == checkpoint and len(snapshots) == checkpoint['generation'], 'snapshot ledger final mismatch')
    current = f'checkpoints/checkpoint-{checkpoint["generation"]:06d}-{checkpoint["payload_sha256"][:12]}.toml'
    require(metadata['current_snapshot'] == current and (directory/current).read_bytes() == checkpoint_bytes, 'current snapshot mismatch')
    return dict(complete=complete, points=len(states), records=sum(s['completed_shots'] for s in states),
                point_seeds_hex=seeds, snapshot_count=len(snapshots), snapshot_hashes=snapshots,
                input_hashes={name:digest(directory/name) for name in ('raw.csv','metadata.toml','checkpoint.toml')}), parsed, checkpoint


def validate_fit(points, fit, selection):
    old = independent_helpers()
    rows = [dict(steps=p['L'], Ly=p['L'], p=p['p'], shots=p['shots'], failures=p['state']['failures'][2])
            for p in points if p['p'] in selection['fit_rates']]
    sizes, rates = selection['sizes'], selection['fit_rates']
    require(fit['sizes'] == sizes and fit['rates'] == rates, 'fit selection differs')
    old.validate_publication_state(fit)
    policy = next(ast.literal_eval(node.value) for node in ast.parse((ROOT/'examples/fit_toric3d_h6_threshold.py').read_text()).body
                  if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'GUARD_POLICY' for t in node.targets))
    require(fit['guard_policy'] == policy, 'fit guard policy differs')
    candidate, boot = fit['candidate'], fit['bootstrap']
    reconstructions = {}
    if candidate:
        require(candidate['polynomial_degree'] == 2 and candidate['correction_coefficient'] is None, 'primary model differs')
        reconstructions['primary'] = old.reconstruct_candidate(rows,candidate)
        require(reconstructions['primary']['passed'], 'primary candidate probability/deviance reconstruction')
    expected = dict(grid_resolution=len(sizes)>=4 and len(rates)>=5, **old.numerical_guards(candidate))
    clusters = old.common_crossings(rows)
    require(fit['crossing_common_brackets'] == clusters, 'crossings differ from raw')
    expected['crossings'] = bool(len(clusters)==1 and candidate and clusters[0][0] <= candidate['pc'] <= clusters[0][1])
    old.validate_bootstrap(boot, selection['bootstrap_replicates'], selection['bootstrap_seed'])
    pc_ci, nu_ci = boot['pc_interval'], boot['nu_interval']
    expected['bootstrap'] = bool(boot['replicates']>=20 and boot['accepted']>=math.ceil(.8*boot['replicates']) and
        pc_ci and nu_ci and rates[0]<pc_ci[0]<pc_ci[1]<rates[-1] and .3<nu_ci[0]<nu_ci[1]<5)
    require([s['name'] for s in fit['sensitivity']] == list(old.VARIANTS), 'sensitivity models missing')
    for variant in fit['sensitivity']:
        name, fitted = variant['name'], variant['candidate']
        selected = [r for r in rows if (name!='drop_smallest' or r['steps']!=sizes[0]) and
                    (name!='narrow_window' or rates[0]<r['p']<rates[-1])]
        enough = len({r['steps'] for r in selected})>=4 and len({r['p'] for r in selected})>=5
        pc_tol = max(.1*(rates[-1]-rates[0]), pc_ci[1]-pc_ci[0] if pc_ci else 0.)
        nu_tol = max(.25*candidate['nu'],nu_ci[1]-nu_ci[0] if nu_ci else 0.) if candidate else None
        if fitted:
            require(fitted['polynomial_degree'] == (3 if name=='cubic' else 2) and
                    (fitted['correction_coefficient'] is not None)==(name=='inverse_L_correction'), 'sensitivity model differs')
            reconstructions[name] = old.reconstruct_candidate(selected,fitted)
            require(reconstructions[name]['passed'], 'sensitivity candidate reconstruction '+name)
        stable = bool(candidate and fitted and abs(fitted['pc']-candidate['pc'])<=pc_tol and abs(fitted['nu']-candidate['nu'])<=nu_tol)
        passed = bool(enough and stable and all(old.numerical_guards(fitted).values()))
        require(variant['enough']==enough and variant['stable']==stable and variant['passed']==passed and
                old.close(variant['pc_tolerance'],pc_tol) and (variant['nu_tolerance']==nu_tol if nu_tol is None else old.close(variant['nu_tolerance'],nu_tol)), 'sensitivity decision differs')
        expected['sensitivity_'+name] = passed
    require(expected == fit['guards'], 'fit guard decisions differ from evidence')
    return dict(status=fit['status'], failed_guards=fit['failed_guards'], reconstructions=reconstructions)


def audit_analysis(directory, points, selection, production):
    old = independent_helpers()
    report = json.loads((directory/'report.json').read_text())
    require(report['selection'] == selection and report['arms'] == list(ARMS), 'analysis scope/selection')
    require(report['total_fault_records']==sum(p['shots'] for p in points) and
            report['total_protocol_outcomes']==4*report['total_fault_records'], 'analysis total counts')
    require(report['analysis_source_sha256'] == digest(STUDY/'analyze.py'), 'analysis source hash')
    evidence=report['selection_validation']
    require(evidence['validated'] is True and evidence['selection_sha256']==digest(STUDY/'selection.json') and
            evidence['frozen_at_unix']==selection['frozen_at_unix'] and
            evidence['bootstrap_replicates']==selection['bootstrap_replicates'] and
            evidence['bootstrap_seed']==selection['bootstrap_seed'] and
            evidence['pilot_input_sha256']==selection['pilot_input_sha256'] and
            evidence['numerical_fit_source_sha256']==selection['numerical_fit_source_sha256'], 'analysis selection validation evidence')
    require(len(report['inputs'])==1 and Path(report['inputs'][0]['directory']).name=='production', 'pilot pooled into analysis')
    for name, value in production['input_hashes'].items():
        require(report['inputs'][0]['hashes'][name]==value, 'analysis input hash differs')
    require(report['inputs'][0]['metadata'] == load_toml(STUDY/'production/metadata.toml'), 'analysis metadata differs')
    marginal, differences = [], []
    require(len(report['points'])==len(points), 'analysis point count')
    for point, recorded in zip(points, report['points']):
        L,p,n,state = point['L'],point['p'],point['shots'],point['state']
        require(recorded['steps']==recorded['Ly']==recorded['Lz']==L and recorded['p']==p and recorded['shots']==n
                and recorded['point_seed']==point['point_seed'] and recorded['joint']==state['joint_counts'], 'analysis point identity')
        for i,arm in enumerate(ARMS):
            require(recorded[arm+'_failures']==state['failures'][i] and
                    recorded[arm+'_logical_1_failures']==state['logical_1_counts'][i] and
                    recorded[arm+'_logical_2_failures']==state['logical_2_counts'][i], 'analysis point counts')
            k=state['failures'][i]; low,high=old.wilson(k,n)
            marginal.append(dict(L=L,p=p,arm=arm,failures=k,shots=n,rate=k/n,ci_low=low,ci_high=high))
        differences.extend(dict(L=L,p=p,shots=n,**paired(state['joint_counts'],first,'one_step'))
                           for first in ('final_only','seed_only','window_complete'))
    for name,expected,key in (('marginals.csv',marginal,'marginals'),('paired-differences.csv',differences,'paired_differences')):
        old.validate_table(directory/name,expected)
        require(len(report[key])==len(expected), 'analysis embedded table size')
        for actual,target in zip(report[key],expected):
            require(set(actual)==set(target) and all(old.close(actual[k],v) if isinstance(v,(int,float)) else actual[k]==v
                    for k,v in target.items()), 'analysis embedded statistics differ')
    fit = validate_fit(points,report['fit'],selection)
    for base in ('z-one-step-four-protocols','z-one-step-paired-differences','z-one-step-local-fit'):
        for extension in ('png','pdf','svg'):
            require((directory/(base+'.'+extension)).stat().st_size>0, 'missing figure')
    return dict(marginal_intervals_recomputed=len(marginal),paired_intervals_recomputed=len(differences),fit=fit,
                output_hashes={p.name:digest(p) for p in directory.iterdir() if p.is_file()})


def audit(require_complete=False, require_analysis=False, require_replays=False):
    selection=json.loads((STUDY/'selection.json').read_text())
    pilot_selection=json.loads((STUDY/'pilot-selection.json').read_text())
    result=dict(status='passed', recorded_at_unix=time.time(), audit_source_sha256=digest(__file__),
                independent_statistics_helper_sha256=digest(HELPER), selection_sha256=digest(STUDY/'selection.json'),
                pilot_selection_sha256=digest(STUDY/'pilot-selection.json'), note_sha256=digest(ROOT/'document/note.tex'))
    require(result['note_sha256']==NOTE_HASH, 'document/note.tex changed')
    expected_pilot={k:pilot_selection[k] for k in ('sizes','rates','shots','seed','batch_size')}
    expected_production={k:selection[k] for k in ('sizes','rates','shots')}
    expected_production['seed']=selection['shards']['production']['seed']
    pilot,pilot_points,pilot_checkpoint=audit_directory(STUDY/'pilot',expected_pilot,True)
    production,points,checkpoint=audit_directory(STUDY/'production',expected_production,require_complete)
    result.update(pilot=pilot,production=production)
    require(selection['pilot_excluded'] is True and selection['shards']['production']['sizes']==selection['sizes'], 'selection scope')
    require(selection['total_fault_records']==len(points)*selection['shots'] and
            selection['total_protocol_outcomes']==4*selection['total_fault_records'], 'selection totals')
    require(set(selection['fit_rates'])<=set(selection['rates']) and len(selection['fit_rates'])==7, 'fit window')
    require(selection['bootstrap_replicates']==200 and selection['bootstrap_seed']==2026101514, 'frozen bootstrap')
    for frozen,cp in ((pilot_selection,pilot_checkpoint),(selection,checkpoint)):
        require(frozen['frozen_before_sampling'] is True and frozen['frozen_at_unix']<cp['started_at_unix'], 'freeze after sampling')
    require(pilot_checkpoint['updated_at_unix']<=selection['frozen_at_unix'], 'production selection precedes pilot completion')
    require(not set(pilot['point_seeds_hex']) & set(production['point_seeds_hex']), 'pilot/production seed overlap')
    sources=checkpoint['source_hashes']
    required={str(p.relative_to(ROOT)) for p in (ROOT/'src').rglob('*.jl')}|{'Project.toml','Manifest.toml',str((STUDY/'run_study.jl').relative_to(ROOT))}
    require(set(sources)==required and sources==pilot_checkpoint['source_hashes']==pilot_selection['source_sha256']==selection['pilot_source_sha256'], 'source coverage/freeze mismatch')
    for name,expected in {**sources,**selection['numerical_fit_source_sha256']}.items():
        require(digest(ROOT/name)==expected, 'source changed: '+name)
    for name,expected in selection['pilot_input_sha256'].items():
        require(digest(STUDY/'pilot'/name)==expected, 'frozen pilot file changed')
    require(checkpoint['runtime']==pilot_checkpoint['runtime'], 'pilot/production runtime mismatch')
    runtime=checkpoint['runtime']; environment=runtime['environment']
    require(runtime['julia_threads']==runtime['blas_threads']==1 and all(environment[k]=='1' for k in
            ('JULIA_NUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')), 'thread environment')
    require(environment['JULIA_CONDAPKG_BACKEND']=='Null' and Path(environment['JULIA_PYTHONCALL_EXE']).resolve()==Path(runtime['python_executable']).resolve(), 'Python backend')
    protocol=checkpoint['protocol']
    require(protocol==pilot_checkpoint['protocol'] and protocol['arm_order']==list(ARMS) and protocol['channel']=='z_only'
            and protocol['circuit']=='legacy H+6-CNOT plaquette transfer' and protocol['geometry']=='T=L; Ly=Lz=L'
            and protocol['initial_state']=='logical |++>', 'protocol metadata scope')
    result['source_files_checked']=len(sources)
    result['numerical_source_hashes']=selection['numerical_fit_source_sha256']
    result['replays']=[]
    verified=set()
    for path in sorted(HERE.glob('replay-*.toml')):
        replay=load_toml(path)
        name=Path(replay['input_directory']).name
        cp=pilot_checkpoint if name=='pilot' else checkpoint
        pointset=pilot_points if name=='pilot' else points
        require(name in ('pilot','production') and replay['status']=='passed' and replay['source_hashes']==sources, 'replay status/source')
        require(replay['verifier_sha256']==digest(HERE/'replay_point.jl'), 'replay verifier hash')
        require(replay['input_checkpoint_sha256']==digest(STUDY/name/'checkpoint.toml') and
                replay['input_payload_sha256']==cp['payload_sha256'], 'replay input hash')
        require(replay['regenerated_point_seeds_hex']==cp['point_seeds_hex'], 'replay regenerated seeds')
        p=pointset[replay['point_index']-1]
        require(replay['point_seed_hex']==p['point_seed'] and replay['dimensions']==[p['L']]*3 and
                replay['p']==p['p'] and replay['shots']==p['shots'], 'replay point identity')
        for key in ('failures','logical_1_counts','logical_2_counts','joint_counts'):
            require(replay[key]==p['state'][key], 'replay counts differ')
        require(replay['assertions_total']==sum(replay['assertions_by_category'].values()), 'replay assertions total')
        verified.add(name)
        result['replays'].append(dict(file=path.name,sha256=digest(path),points_seeds_verified=len(cp['point_seeds_hex']),
                                     assertions=replay['assertions_total'],records=p['shots'],L=p['L'],p=p['p']))
    require(not require_replays or verified=={'pilot','production'}, 'missing pilot/production Julia replay evidence')
    result['seed_regeneration_evidence_complete']=verified=={'pilot','production'}
    analysis=STUDY/'analysis'
    require(not require_analysis or (analysis/'report.json').exists(), 'missing analysis')
    result['analysis']=audit_analysis(analysis,points,selection,production) if (analysis/'report.json').exists() else None
    result['limits']=['No simulation or optimizer rerun by this Python audit; representative Julia replays supply exact seed regeneration and selected record replay.',
        'Hashes and recorded timestamps establish artifact consistency, not an external trusted timestamp or raw per-shot bit archive.',
        'All 16 recorded joint failure cells and arm logical union bounds are checked; individual per-shot logical bit histories are not saved.',
        'Bootstrap intervals are recomputed from recorded accepted replicates; bootstrap optimization is not rerun.']
    return result


class AuditTests(unittest.TestCase):
    def state(self):
        return dict(completed_shots=4, elapsed_seconds=1., joint_counts=[1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2],
                    failures=[3, 2, 2, 2], logical_1_counts=[2, 2, 1, 0], logical_2_counts=[2, 0, 2, 2])

    def test_state_good(self):
        validate_state(self.state(), 4)

    def test_histogram_marginal_tamper(self):
        state = self.state(); state['failures'][0] = 2
        with self.assertRaisesRegex(ValueError, 'marginal'):
            validate_state(state, 4)

    def test_logical_union_impossible(self):
        state = self.state(); state['logical_1_counts'][0] = 0
        with self.assertRaisesRegex(ValueError, 'union'):
            validate_state(state, 4)

    def test_negative_histogram(self):
        state = self.state(); state['joint_counts'][0] = -1
        with self.assertRaises(ValueError):
            validate_state(state, 4)

    def test_boolean_count(self):
        state = self.state(); state['logical_1_counts'][0] = True
        with self.assertRaises(ValueError):
            validate_state(state, 4)

    def test_payload(self):
        body = b'format_version = 1\n'
        payload = hashlib.sha256(body).hexdigest()
        blob = body + ('payload_sha256 = "' + payload + '"\n').encode()
        validate_payload(blob)
        with self.assertRaisesRegex(ValueError, 'payload'):
            validate_payload(blob.replace(b'version = 1', b'version = 2'))

    def test_paired_histogram(self):
        value = paired(self.state()['joint_counts'], 'final_only', 'one_step')
        self.assertEqual((value['neither'], value['first_only'], value['second_only'], value['both']), (1, 1, 0, 2))
        self.assertEqual(value['difference'], -.25)
        self.assertLess(value['ci_low'], value['difference'])
        self.assertGreater(value['ci_high'], value['difference'])

    def test_unpublished_failure_guard(self):
        old = independent_helpers()
        fit = dict(guards={name: True for name in old.GUARDS}, status='accepted', pc=.02, nu=1.,
                   candidate={'pc': .02, 'nu': 1.}, failed_guards=[])
        old.validate_publication_state(fit)
        fit['guards']['crossings'] = False; fit['failed_guards'] = ['crossings']
        with self.assertRaisesRegex(ValueError, 'publication'):
            old.validate_publication_state(fit)


if __name__ == '__main__':
    if '--self-test' in sys.argv:
        unittest.main(argv=[sys.argv[0]])
    else:
        parser=argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--require-complete',action='store_true')
        parser.add_argument('--require-analysis',action='store_true')
        parser.add_argument('--require-replays',action='store_true')
        parser.add_argument('--output',type=Path)
        options=parser.parse_args()
        try:
            report=audit(options.require_complete,options.require_analysis,options.require_replays)
        except (ValueError,KeyError,OSError,TypeError) as error:
            report=dict(status='failed',error=str(error))
        if options.output:
            options.output.write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps({k:v for k,v in report.items() if k in ('status','error','source_files_checked','seed_regeneration_evidence_complete')}))
        else:
            print(json.dumps(report,indent=2))
        raise SystemExit(0 if report['status']=='passed' else 1)
