# Independent review: H+6 causal one-step Z feedback

The implemented protocol is a valid causal, Z-specific partial recovery on the
legacy H+6 plaquette-transfer circuit. The four paired arms permit a fair
comparison at fixed physical error probability. The production scaling fit
does **not** establish a threshold. No simulation source or frozen selection
was changed by this review.

## Protocol and implementation

`src/toric3d/h6_z_one_step.jl:11–38` checks the physical three-sheet graph and
preserves physical edge identifiers, including parallel edges. At lines 51–95,
the decoder receives only the measured even window syndrome, matches its
defects, reconstructs deterministic shortest physical paths, and validates the
complete path recovery. It applies only endpoint edges whose endpoints lie on
the retiring sheet. Each applied edge connects that sheet to the middle sheet;
middle/newest endpoints do not trigger an edge. Thus a retiring defect is
transported forward without creating a different retiring defect.

At lines 98–130, correction follows the current transfer and acts on the older
of its two recovery slices. Complete-prefix measurements verify the retired
region is clear; they do not enter the matching decision. The newest two
check sheets may retain defects. Complete seed recovery establishes the
induction: all previously retired checks are clear, old Z errors stay on old
qubits, and the next transfer adds effective faults only within the new
window. Consequently its closed syndrome has even parity. The tests include
the counterexample showing why blindly applying the X rule to both endpoints
can create a retiring Z defect, retained-defect advancement, and undetectable
logical Z errors that must remain logical errors.

`replay_toric3d_h6_z_one_step` at lines 143–175 performs complete seed recovery,
partial correction after every nonfinal transfer, and exactly one final full
MWPM recovery. Disabling its intermediate feedback produces **seed-only**,
not final-only. `run_study.jl:273–290` selects separate final-only, seed-only,
one-step, and complete-window APIs, shares one immutable fault record, checks
all logical/union outcomes, and reuses the same final decoder family. This is
not the H+5 vertex-projector model. Matching uses global classical information
within a transverse window; “one-step” describes the applied physical route,
not a spatially local classical decoder.

All arms have T=Ly=Lz=L, noisy logical |++> preparation, independent Bernoulli-p
Z faults on 3L² seed-H outputs and 13L³ transfer outputs, ideal measurements,
idles and corrections, and unit-data-weight final MWPM. The seed-only control
separates seed repair from intermediate feedback. Complete-window recovery can
use different physical path ties. These are protocol comparisons under the
declared noise model, not a direct X/Z threshold comparison.

## Frozen inputs and artifact verification

The pilot was frozen before its first checkpoint and completed before the
production selection. Production uses exactly five sizes 3,5,7,9,11, ten
declared rates, and 1,000 shared records per point: 50,000 fault records and
200,000 arm outcomes. All 420 pilot records remain excluded. The seven central
fit rates, 200 bootstrap replicates, bootstrap seed 2026101514, and two numerical
source hashes were frozen before production. The 53 simulation source files
match both selections and all checkpoints; new implementation files are bound
by their recorded content hashes, not inferred to belong to the older base
commit. `document/note.tex` retains SHA256
`3a40710c2ab6bd43e53f5f7703b7c8716b209dc1e060a5092f17e0edce073f3a`.

`audit_study.py` imports neither the simulation runner nor either analysis
adapter. It reuses independent mathematical checks from the prior X artifact
auditor and records that dependency's hash. It checks exact row order and
point-seed identity, all 16 histogram cells and four state-failure marginals,
logical union bounds, metadata/raw/checkpoint agreement, source coverage,
runtime/thread settings, and every snapshot payload and monotone count history.
There are 25 pilot and 1,006 production snapshots. Its eight focused mutation
and arithmetic tests were first observed failing for absent implementations,
then passed; the red/green output is in the task transcript, not reconstructed
as historical log files.

Independent Julia replay evidence verifies every point seed by scalar UInt64
MersenneTwister draws and replays pilot L=3,p=.02 (20 records; 2,385 assertions)
and production L=11,p=.02 (1,000 records; 2,451,420 assertions). Both reproduce
all four logical-count triples and the exact 16-bin histogram. The production
replay also audits 10,000 one-step windows and independently scores final
physical syndromes and logical membranes. The Python audit binds both replay
reports to their actual checkpoint, verifier and source hashes.

## Analysis and review finding

The initial analysis entry point enforced sizes, rates and shots but did not
enforce the remaining frozen provenance and bootstrap choices. This was
reported before final fitting. The owner added explicit selection validation
and observed red/green regression tests; the resulting code binds the exact
production directory/master seed, pilot hashes and exclusion, recorded freeze
times, numerical source hashes, and bootstrap settings. This closes the
identified attribution gap without changing the numerical model or policy.

The audit independently recomputes all 200 Wilson intervals, 150 paired
differences and their conservative pointwise intervals. It reconstructs fitted
probabilities and binomial deviance directly from raw counts for the primary
model and all four sensitivity models, then independently evaluates crossing,
bootstrap and publication guards. Bootstrap intervals are recomputed from the
recorded accepted samples. The primary diagnostic candidate is
p=0.01727934443, nu=1.026687599, with deviance 116.6344453 on 30 degrees of
freedom and goodness probability 3.7171e-12. Monotonicity, goodness, crossings,
bootstrap and all four sensitivity guards fail. Only 51/200 bootstrap samples
pass their numerical guards. Published `pc` and `nu` are correctly null;
the conditional interval of the surviving bootstrap fits is not a threshold
confidence interval. An inverse-L correction passes its own goodness check
but shifts the candidate to 0.02162371284 and fails stability, so it cannot
rescue the claim.

## Proof limits

This audit checks complete aggregate records and their provenance. It does not
rerun all 50,000 simulations or bootstrap optimizations, and the archive does
not contain every individual fault bit or logical outcome. Representative
replays supply direct seed and per-record evidence. Content hashes and
recorded timestamps establish internal consistency, not an external trusted
timestamp. The fixed-p paired intervals are pointwise and have no simultaneous
coverage guarantee across rates, sizes or protocol pairs. These limits do not
invalidate the measured comparisons or justify accepting the failed threshold
fit.

## Completed artifact review

The final invocation with `--require-complete --require-analysis --require-replays`
passed after the final plot/source refresh. `audit.json` binds the complete
71-point pilot/production archive, all 1,031 snapshots, both independent Julia
replays, all statistics, and the final analysis/figure hashes. The final
`analysis/report.json` SHA256 is
`c8803756112544bce4ce0f12c5f02dac25680cb600db41ec10b98fec23b0f42c`.

The README's p=.02 table, L=11 logical counts, paired intervals, diagnostic
candidate table, and timings agree with the raw counts and independently
recomputed quantities. The final figures preserve a clearly rejected
diagnostic candidate rather than asserting an accepted threshold. No remaining
scientific, provenance, or artifact-consistency issue was identified within
this review's stated scope. Figure layout was reviewed separately by the root
reviewer; this audit checks figure presence and hashes.
