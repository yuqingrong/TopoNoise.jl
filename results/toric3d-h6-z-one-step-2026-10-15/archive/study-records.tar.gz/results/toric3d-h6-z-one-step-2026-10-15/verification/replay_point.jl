"""Independently replay one saved point; never import the study runner."""
module H6ZIndependentPointReplay

using TopoNoise, Random, LinearAlgebra, SparseArrays
import TOML, SHA, PythonCall

const ROOT = abspath(joinpath(@__DIR__, "..", "..", ".."))
const ARMS = ("final_only", "seed_only", "one_step", "window_complete")
const USAGE = "Usage: replay_point.jl INPUT_DIR L P OUTPUT_TOML"

digest(bytes) = bytes2hex(SHA.sha256(bytes))
parity(matrix, bits) = BitVector(isodd.(matrix * Vector{UInt8}(bits)))
measured(checks, bits) = BitVector(isodd(count(bits[check])) for check in checks)

function check!(counts, category, condition, message)
    condition || error("independent replay [$category]: $message")
    counts[category] = get(counts, category, 0) + 1
    return nothing
end

function canonical_toml(data)
    io = IOBuffer()
    TOML.print(io, data; sorted=true)
    return String(take!(io))
end

function regenerate_seeds(base_seed, number)
    stream = MersenneTwister(base_seed)
    unique_seeds = Set{UInt64}()
    seeds = UInt64[]
    while length(seeds) < number
        seed = rand(stream, UInt64) # Scalar draws: array draws use a different stream.
        seed in unique_seeds && continue
        push!(unique_seeds, seed)
        push!(seeds, seed)
    end
    return seeds
end

function check_runtime!(counts, saved)
    check!(counts, "runtime", string(VERSION) == saved["julia_version"], "Julia version differs")
    check!(counts, "runtime", Threads.nthreads() == BLAS.get_num_threads() == 1,
        "Julia and BLAS must each use one thread")
    for name in ("JULIA_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
        check!(counts, "runtime", get(ENV, name, "") == "1", "$name must equal 1")
    end
    check!(counts, "runtime", get(ENV, "JULIA_CONDAPKG_BACKEND", "") == "Null",
        "JULIA_CONDAPKG_BACKEND must equal Null")
    python = PythonCall.pyconvert(String, PythonCall.pyimport("sys").executable)
    check!(counts, "runtime", realpath(python) == realpath(saved["python_executable"]) ==
        realpath(ENV["JULIA_PYTHONCALL_EXE"]), "Python executable differs")
    versions = PythonCall.pyimport("importlib.metadata")
    for (name, version) in saved["packages"]
        observed = PythonCall.pyconvert(String, versions.version(name))
        check!(counts, "runtime", observed == version, "$name version differs")
    end
    return Dict("julia_version"=>string(VERSION), "python_executable"=>python,
        "julia_threads"=>Threads.nthreads(), "blas_threads"=>BLAS.get_num_threads(),
        "packages"=>saved["packages"])
end

function check_final!(counts, result, matrix, logical_matrix)
    n = size(matrix, 2)
    check!(counts, "final", length(result.frame.z) == length(result.recovery) ==
        length(result.residual) == n, "final data dimensions differ")
    check!(counts, "final", !any(result.frame.x), "Z-only replay produced an X frame")
    check!(counts, "final", parity(matrix, result.frame.z) == result.syndrome,
        "final measured syndrome differs from physical frame")
    check!(counts, "final", parity(matrix, result.recovery) == result.syndrome,
        "final full recovery does not reproduce syndrome")
    check!(counts, "final", result.residual == result.frame.z .⊻ result.recovery,
        "final residual is not frame XOR recovery")
    check!(counts, "final", !any(parity(matrix, result.residual)),
        "final residual has nonzero syndrome")
    logical = parity(logical_matrix, result.residual)
    check!(counts, "final", (result.logical_1, result.logical_2) == Tuple(logical),
        "final logical flags differ from independent membrane parities")
    check!(counts, "final", result.failure == any(logical), "final union failure differs")
    return nothing
end

function check_history!(counts, result, code, encoder, faults)
    steps = code.lattice.steps
    cells = code.lattice.Ly * code.lattice.Lz
    history = result.history
    check!(counts, "history", length(history) == steps, "one-step history has wrong depth")
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    seed_window = toric3d_z_feedback_window(code, 0)
    frame.z[seed_window.qubits] .= faults.seed
    seed = first(history)
    check!(counts, "history", seed.kind === :seed && seed.checkpoint == 0, "missing seed history")
    check!(counts, "history", seed.qubits == seed_window.qubits, "seed support mapping differs")
    check!(counts, "history", seed.syndrome == measured(seed_window.checks, frame.z),
        "seed measurement differs from regenerated seed faults")
    check!(counts, "history", parity(seed_window.matrix, seed.recovery) == seed.syndrome,
        "seed recovery does not clear complete seed syndrome")
    check!(counts, "history", seed.support == seed.qubits[findall(seed.recovery)],
        "seed physical recovery support differs")
    frame.z[seed.qubits] .⊻= seed.recovery
    seed_post = measured(seed_window.checks, frame.z)
    check!(counts, "history", seed.post_syndrome == seed_post && !any(seed_post),
        "seed post-syndrome differs or remains nonzero")
    first_operation = 1
    for r in 1:steps
        propagate_toric3d_segment!(frame, encoder, faults.transfer,
            first_operation, encoder.checkpoints[r])
        first_operation = encoder.checkpoints[r] + 1
        r == steps && continue
        entry = history[r + 1]
        window = toric3d_z_feedback_window(code, r)
        prefix = toric3d_encoded_prefix(code, r)
        prefix_matrix = star_check_matrix(prefix.code; sparse=true)
        syndrome = measured(window.checks, frame.z)
        check!(counts, "history", entry.kind === :window && entry.checkpoint == r,
            "intermediate checkpoint order differs")
        check!(counts, "history", entry.qubits == window.qubits, "window mapping differs")
        check!(counts, "history", entry.syndrome == syndrome,
            "measured window differs from independently propagated fault frame")
        check!(counts, "history", entry.prefix_syndrome == parity(prefix_matrix, frame.z[prefix.qubits]),
            "pre-correction prefix audit differs")
        check!(counts, "history", parity(window.matrix, entry.recovery) == syndrome,
            "full path recovery does not reproduce measured syndrome")
        check!(counts, "history", length(entry.paths) == length(entry.matched_pairs) == count(syndrome) ÷ 2,
            "number of matching endpoints differs")
        endpoints = falses(3cells)
        full = falses(6cells)
        route = falses(6cells)
        for ((a, b), path) in zip(entry.matched_pairs, entry.paths)
            check!(counts, "history", 1 <= a <= 3cells && 1 <= b <= 3cells && a != b,
                "matching contains a boundary or invalid endpoint")
            check!(counts, "history", !isempty(path), "matching path is empty")
            endpoints[a] ⊻= true
            endpoints[b] ⊻= true
            current = a
            for edge in path
                check!(counts, "history", 1 <= edge <= 6cells, "path edge is not physical")
                incident = findall(@view window.matrix[:, edge])
                check!(counts, "history", length(incident) == 2 && current in incident,
                    "physical path is not contiguous")
                current = incident[1] == current ? incident[2] : incident[1]
                full[edge] ⊻= true
            end
            check!(counts, "history", current == b, "physical path ends at wrong detector")
            a <= cells && (route[first(path)] ⊻= true)
            b <= cells && (route[last(path)] ⊻= true)
        end
        check!(counts, "history", endpoints == syndrome, "matched endpoints omit measured defects")
        check!(counts, "history", full == entry.recovery, "full recovery differs from physical paths")
        check!(counts, "history", route == entry.route, "route does not trim only retiring endpoints")
        check!(counts, "history", !any(route[3cells+1:end]), "route touches fresh data")
        check!(counts, "history", entry.support == window.qubits[findall(route)],
            "partial physical support differs")
        check!(counts, "history", entry.full_support == window.qubits[findall(full)],
            "full physical support differs")
        check!(counts, "history", all(data_qubit_coordinate(code, q)[2] == r - 1 for q in entry.support),
            "partial route touches a data slice other than r-1")
        predicted = syndrome .⊻ parity(window.matrix, route)
        check!(counts, "history", entry.residual_syndrome == predicted, "predicted partial syndrome differs")
        check!(counts, "history", entry.retiring_syndrome == syndrome[1:cells],
            "retiring measurement differs")
        check!(counts, "history", entry.predicted_retiring_syndrome == predicted[1:cells],
            "retiring prediction differs")
        frame.z[window.qubits] .⊻= route
        observed = measured(window.checks, frame.z)
        check!(counts, "history", observed == predicted == entry.window_post_syndrome,
            "observed window residual differs")
        check!(counts, "history", entry.observed_retiring_syndrome == observed[1:cells],
            "observed retiring history differs")
        check!(counts, "history", !any(observed[1:cells]), "retiring syndrome remains nonzero")
        post = parity(prefix_matrix, frame.z[prefix.qubits])
        check!(counts, "history", entry.post_syndrome == post, "full prefix post-syndrome differs")
        check!(counts, "history", entry.retired_prefix_rows == 1:r*cells, "retired prefix row range differs")
        check!(counts, "history", !any(post[1:r*cells]), "an earlier retired prefix check remains nonzero")
    end
    check!(counts, "history", frame.z == result.frame.z && frame.x == result.frame.x,
        "independent history propagation differs from replay's pre-final frame")
    return nothing
end

function main(arguments=ARGS)
    length(arguments) == 4 || throw(ArgumentError(USAGE))
    directory = abspath(arguments[1])
    selected_L, selected_p = parse(Int, arguments[2]), parse(Float64, arguments[3])
    output = abspath(arguments[4])
    checkpoint_path = joinpath(directory, "checkpoint.toml")
    output == checkpoint_path && throw(ArgumentError("output cannot overwrite the checkpoint"))
    counts = Dict{String,Int}()
    bytes = read(checkpoint_path)
    saved = TOML.parse(String(copy(bytes)))
    check!(counts, "checkpoint", saved["format_version"] == 1, "unsupported checkpoint format")
    payload = copy(saved)
    checksum = pop!(payload, "payload_sha256")
    check!(counts, "checkpoint", checksum == digest(canonical_toml(payload)), "payload checksum differs")
    snapshot_name = "checkpoint-" * lpad(saved["generation"], 6, '0') * "-" * checksum[1:12] * ".toml"
    snapshot = joinpath(directory, "checkpoints", snapshot_name)
    check!(counts, "checkpoint", read(snapshot) == bytes, "immutable checkpoint snapshot differs")
    config = saved["config"]
    check!(counts, "checkpoint", config["dimensions"] == [[L, L, L] for L in config["sizes"]],
        "dimensions do not satisfy T=Ly=Lz=L")
    check!(counts, "checkpoint", saved["protocol"]["arm_order"] == collect(ARMS), "arm order differs")
    grid = [(L, p) for L in config["sizes"] for p in config["rates"]]
    check!(counts, "checkpoint", length(grid) == length(saved["states"]), "grid and states differ")
    selected = findall(==((selected_L, selected_p)), grid)
    check!(counts, "checkpoint", length(selected) == 1, "requested point is absent or duplicated")
    index = only(selected)
    state = saved["states"][index]
    shots = state["completed_shots"]
    check!(counts, "checkpoint", 0 < shots <= config["shots"], "requested point has no saved samples")
    seeds = regenerate_seeds(config["seed"], length(grid))
    hex_seeds = [string(seed; base=16, pad=16) for seed in seeds]
    check!(counts, "seeds", all(occursin(r"^[0-9a-f]{16}$", seed) for seed in saved["point_seeds_hex"]),
        "point seeds are not 16 lowercase hexadecimal digits")
    check!(counts, "seeds", hex_seeds == saved["point_seeds_hex"], "regenerated point seed list differs")
    check!(counts, "seeds", parse(UInt64, saved["point_seeds_hex"][index]; base=16) == seeds[index],
        "chosen point seed differs")
    observed_sources = Dict{String,String}()
    for (path, expected) in saved["source_hashes"]
        observed_sources[path] = digest(read(joinpath(ROOT, path)))
        check!(counts, "sources", observed_sources[path] == expected, "source hash differs: $path")
    end
    runtime = check_runtime!(counts, saved["runtime"])
    code = Toric3DEncodedSlice(selected_L, selected_L, selected_L)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    one_step = build_toric3d_h6_z_one_step_decoder(family)
    check!(counts, "decoder", one_step.family === family, "one-step does not share decoder family")
    matrix = star_check_matrix(code; sparse=true)
    logical_matrix = falses(2, data_qubit_count(code))
    for (i, support) in enumerate(toric3d_encoded_logical_x(code))
        logical_matrix[i, support] .= true
    end
    joint = zeros(Int, 16)
    logical_1 = zeros(Int, 4)
    logical_2 = zeros(Int, 4)
    failures = zeros(Int, 4)
    rng = Xoshiro(seeds[index])
    elapsed = @elapsed for shot in 1:shots
        faults = sample_toric3d_diagonal_z_faults(rng, encoder; p=selected_p)
        original = (copy(faults.seed), copy(faults.transfer.x), copy(faults.transfer.z))
        mask = 0
        for arm in 1:4
            # Direct protocol calls: no runner import, aggregation helper, or second final decode.
            result = if arm == 1
                replay_toric3d_z_strength(encoder, faults, family; protocol=:none)
            elseif arm == 2
                replay_toric3d_h6_z_one_step(encoder, faults, one_step; intermediate_feedback=false)
            elseif arm == 3
                replay_toric3d_h6_z_one_step(encoder, faults, one_step; record_history=true)
            else
                replay_toric3d_z_strength(encoder, faults, family; protocol=:slice_local)
            end
            check!(counts, "immutability", (faults.seed, faults.transfer.x, faults.transfer.z) == original,
                "$(ARMS[arm]) mutated record $shot")
            check_final!(counts, result, matrix, logical_matrix)
            arm == 3 && check_history!(counts, result, code, encoder, faults)
            logical_1[arm] += result.logical_1
            logical_2[arm] += result.logical_2
            failures[arm] += result.failure
            result.failure && (mask |= 1 << (arm - 1))
        end
        joint[mask + 1] += 1
    end
    for mask in 0:15
        check!(counts, "counts", joint[mask + 1] == state["joint_counts"][mask + 1],
            "joint histogram bin $mask differs")
    end
    for arm in 1:4
        check!(counts, "counts", logical_1[arm] == state["logical_1_counts"][arm], "logical-1 marginal differs")
        check!(counts, "counts", logical_2[arm] == state["logical_2_counts"][arm], "logical-2 marginal differs")
        check!(counts, "counts", failures[arm] == state["failures"][arm], "failure marginal differs")
        marginal = sum(joint[mask + 1] for mask in 0:15 if !iszero(mask & (1 << (arm - 1))))
        check!(counts, "counts", marginal == failures[arm], "joint marginal differs from failure count")
    end
    check!(counts, "counts", sum(joint) == shots, "joint counts do not sum to saved samples")
    summary = Dict{String,Any}("status"=>"passed", "verification"=>"independent deterministic point replay",
        "dimensions"=>[selected_L, selected_L, selected_L], "p"=>selected_p,
        "shots"=>shots, "target_shots"=>config["shots"], "point_index"=>index,
        "base_seed"=>config["seed"], "point_seed_hex"=>hex_seeds[index],
        "regenerated_point_seeds_hex"=>hex_seeds, "arm_order"=>collect(ARMS),
        "joint_counts"=>joint, "logical_1_counts"=>logical_1, "logical_2_counts"=>logical_2,
        "failures"=>failures, "assertions_total"=>sum(values(counts)), "assertions_by_category"=>counts,
        "one_step_histories_checked"=>shots, "one_step_windows_checked"=>shots*(selected_L-1),
        "final_outcomes_checked"=>4shots, "elapsed_seconds"=>elapsed,
        "input_directory"=>directory, "input_checkpoint"=>checkpoint_path,
        "input_checkpoint_sha256"=>digest(bytes), "input_payload_sha256"=>checksum,
        "input_snapshot"=>snapshot, "input_generation"=>saved["generation"],
        "source_hashes"=>observed_sources, "verifier_sha256"=>digest(read(@__FILE__)), "runtime"=>runtime,
        "final_validation"=>"physical star and logical-membrane matrix products; no second final decoder call",
        "history_validation"=>"independent fault propagation with recorded seed and partial corrections; matching paths, retiring slice support, and complete retired-prefix audit")
    mkpath(dirname(output))
    open(output * ".tmp", "w") do io
        TOML.print(io, summary; sorted=true)
    end
    mv(output * ".tmp", output; force=true)
    println("Passed L=", selected_L, " p=", selected_p, " shots=", shots,
        ": ", summary["assertions_total"], " assertions; joint=", joint)
    println("Saved ", output)
    return summary
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    H6ZIndependentPointReplay.main()
end
