# H+6 causal one-step Z feedback

This study evaluates a new Z-specific one-step feedback rule on the **legacy
H+6 plaquette-transfer circuit**. It does not substitute the separate H+5
vertex-projector circuit. Measurements, idle qubits, and corrections are ideal.

## Four paired protocols

Each fault record is replayed through all four arms, with the same circuit,
logical |++> preparation, final decoder, and logical scoring:

| Arm | Seed correction | Intermediate correction |
|---|---|---|
| Final-only | None | None |
| Seed-only | Complete seed MWPM | None |
| One-step | Same complete seed MWPM | Retiring endpoints move one physical edge |
| Complete-window | Same complete seed MWPM | Existing full window MWPM recovery |

Seed-only separates the effect of initial seed repair from the effect of
feedback during preparation. All arms retain independent Z faults of rate p
on all 3L² seed-H outputs and 13L³ transfer-gate outputs, with T=Ly=Lz=L.
Every arm performs exactly one final full-code, unit-data-weight MWPM recovery.
Failure means either of the two residual logical-Z parities is nonzero.
Shared fault records are checked for mutation after each arm.

## Causal correction rule

After each nonfinal transfer, measure the three adjacent X-star check sheets.
Their graph is `retiring — middle — newest`, with physical data on the links.
Match the entire measured even syndrome and construct physical shortest paths.
Validate that the complete paths reproduce the syndrome. Apply an endpoint
edge **only if that matched endpoint lies on the retiring sheet**. The applied
Z correction therefore acts only on the older of the two recovery slices.
Endpoints on the middle and newest sheets wait.

Every selected edge joins its retiring endpoint to a middle-sheet vertex. It
clears that retiring defect and cannot create another retiring defect. After
correction, defects can remain on the newest two check sheets. In the next
transfer, old Z errors stay on old qubits, the previous frontier check becomes
a bulk check, and new effective faults occupy only the newest two data slices.
Thus all nonzero syndrome remains inside the next three-sheet window. Complete
seed correction establishes the induction. The full syndrome has even parity
and omitted older sheets are zero, so the measured window also has even parity.

The replay checks the complete retired-prefix invariant after every partial
correction, independently of the decoder input. It does not require the newest
two sheets to be clear. Hidden fault records and logical parities are never
used to choose a recovery. Zero syndrome can still contain a logical error.

This is one-edge transport with a three-sheet measurement window. Matching
uses global classical information across that transverse window. The full
MWPM paths are reconstructed by deterministic shortest-path traversal; path
ties can differ from the existing complete-window decoder's internal choice.

## Validation and study records

The core passed 24,033 new assertions and 5,384 existing regression assertions.
Checks cover all 2,048 even syndromes on the smallest window, all small-system
seed and transfer single faults, random multifault histories, rectangular
geometries, retained-defect advancement, logical information preservation,
seed-only manual propagation, and the T=1 boundary case. Logs are in
[`verification`](verification).

The runner saves all 16 joint failure counts and both individual logical
counts for every arm. Point seeds are preserved as exact 16-digit hexadecimal
UInt64 values. Immutable batch checkpoints and their hashes permit exact
resumption and independent seeded replays.

Pilot settings and production selection are recorded separately. The 420 pilot
records are excluded from production estimates. Production uses L=3,5,7,9,11,
the same sizes as the preceding X study, with 1,000 shared records at each of
ten physical rates: .005, .01, .0125, .015, .0175, .02, .0225, .025, .0275, .04.
All 50 points completed, for 50,000 records and 200,000 protocol outcomes.
No correction-invariant failure occurred.

An independent script regenerated and replayed all 1,000 production records
at L=11, p=.02. Its 2,451,420 assertions verified the final physical syndromes,
logical scores, causal correction paths, and complete retired prefixes.
All 16 joint failure bins and per-arm logical counts matched the checkpoint.
The separate L=3, p=.02 pilot replay also passed (20 records, 2,385 assertions).

## Measured results

At p=.02, the measured logical state failure rates are:

| L | Final-only | Seed-only | One-step | Complete-window |
|---|---:|---:|---:|---:|
| 3 | 37.4% | 33.6% | 26.7% | 13.4% |
| 5 | 66.7% | 65.5% | 39.0% | 6.8% |
| 7 | 72.3% | 72.8% | 41.3% | 2.9% |
| 9 | 75.0% | 76.0% | 43.2% | 1.2% |
| 11 | 74.8% | 75.6% | 42.6% | 0.3% |

Each entry has 1,000 trials. At this rate, adding intermediate one-step
correction improves on seed-only correction at every sampled size, while
complete-window correction has a lower measured failure rate than one-step.
These are comparisons at fixed p; they do not by themselves establish an
asymptotic threshold. The noise model contains only Z faults on gate outputs.

At L=11, p=.02, the paired one-step minus seed-only difference is -33.0
percentage points, with approximate pointwise 95% interval [-38.55, -27.12]
points. Relative to complete-window recovery the difference is +42.3 points,
with interval [38.35, 45.83]. These intervals use differences of Bonferroni–Wilson
intervals for the two discordant event probabilities. They are not simultaneous
intervals across the scanned points. Benefits are not resolved at every rate;
for example, the protocols become difficult to distinguish near saturation.

## Local finite-size fit

The fit uses only the seven preselected rates .0125 through .0275, with a
quadratic logit scaling function of x=(p-pc)L^(1/nu), internally normalized
for numerical conditioning. Thus the analysis attempts a local collapse
near the crossing, rather than fitting the full .005–.04 curve.

**No threshold or critical exponent is established.** The primary optimizer
converged, but the proposed scaling model fails the goodness and monotonicity
checks. Its binomial deviance is 116.63 for 30 degrees of freedom
(goodness-test probability 3.72e-12). There is no single common crossing
bracket across all adjacent-size pairs, and only 51/200 bootstrap fits pass
the numerical bootstrap checks. Sensitivity checks also fail:

| Diagnostic model | Candidate pc | Candidate nu | Goodness-test probability |
|---|---:|---:|---:|
| Primary quadratic | .01728 | 1.027 | 3.72e-12 |
| Omit L=3 | .01843 | 1.035 | .00158 |
| Narrow rate window | .01745 | 1.021 | 1.63e-7 |
| Cubic scaling function | .01719 | 1.029 | 7.76e-12 |
| Add fixed 1/L logit correction | .02162 | 1.447 | .0786 |

All entries are diagnostic candidates, not accepted estimates or confidence
intervals. The 1/L model improves the residuals but moves both parameters
beyond the frozen stability tolerances. This is evidence that the sampled
small sizes need better control of finite-size effects. More samples alone
would not repair the mismatch of the primary model. The report preserves
every candidate and guard decision while keeping its public pc and nu null.

The failure metric is the union of two logical parities; it does not imply
equal protection of them. At L=11, p=.02, one-step has 323 logical-1 failures
and 250 logical-2 failures. Circuit/path ordering may matter, but these data
do not identify the cause. Path tie choices also differ between the one-step
and existing complete-window decoders, so their entire performance gap cannot
be attributed solely to correction distance. Conclusions are restricted to
T=L, Z-only gate-output faults, and ideal measurements and corrections.

## Figures and data

All figures use the reusable boxed-axis, no-grid theme, with connected points
and capped uncertainty bars. The collapse inset explicitly labels its rejected
candidate and does not mark an accepted critical point.

- [One-step curve and diagnostic collapse](analysis/z-one-step-local-fit.png)
  ([PDF](analysis/z-one-step-local-fit.pdf), [SVG](analysis/z-one-step-local-fit.svg)).
- [Four protocols](analysis/z-one-step-four-protocols.png)
  ([PDF](analysis/z-one-step-four-protocols.pdf), [SVG](analysis/z-one-step-four-protocols.svg)).
- [Paired differences](analysis/z-one-step-paired-differences.png)
  ([PDF](analysis/z-one-step-paired-differences.pdf), [SVG](analysis/z-one-step-paired-differences.svg)).
- [Raw counts](production/raw.csv), [marginal estimates](analysis/marginals.csv),
  [paired estimates](analysis/paired-differences.csv), [full analysis](analysis/report.json),
  [frozen selection](selection.json), and [independent review](verification/independent-review.md).

The runner's recorded wall time was 284.69 seconds, including decoder builds,
sampling, decoding, and checkpoint writes, but excluding process startup.
Summed per-point sampling/decoding time was 266.86 seconds. All runs used one
Julia thread and one BLAS thread; runtime/package versions are in
[`production/metadata.toml`](production/metadata.toml).

## Reproduction

Use the Julia project environment and a Python environment with the versions
recorded in the metadata. The saved runner checks that PythonCall uses the
requested interpreter and that the thread settings equal one. For this run:

```sh
export JULIA_CONDAPKG_BACKEND=Null
export JULIA_PYTHONCALL_EXE=/Users/rongyuqing/jcode/TopoNoise.jl/.CondaPkg/.pixi/envs/default/bin/python
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export MPLCONFIGDIR=/tmp/h6-z-mpl
julia --compiled-modules=existing --project=. --startup-file=no \
  results/toric3d-h6-z-one-step-2026-10-15/run_study.jl \
  --output results/toric3d-h6-z-one-step-2026-10-15/production \
  --sizes 3,5,7,9,11 \
  --rates .005,.01,.0125,.015,.0175,.02,.0225,.025,.0275,.04 \
  --shots 1000 --seed 2026101512 --batch-size 50 --resume
"$JULIA_PYTHONCALL_EXE" -B results/toric3d-h6-z-one-step-2026-10-15/analyze.py \
  --input results/toric3d-h6-z-one-step-2026-10-15/production \
  --output results/toric3d-h6-z-one-step-2026-10-15/analysis \
  --selection results/toric3d-h6-z-one-step-2026-10-15/selection.json \
  --bootstrap 200 --seed 2026101514
```

The runner command above validates/resumes the saved run. For a fresh repeat,
use a new output directory and omit `--resume`; the original provenance audit
continues to refer to the saved production directory. The frozen primary fit
uses only .0125 through .0275, selected from the excluded pilot before
production. Size/window/model sensitivity checks use the unchanged H+6 fit
policy; a diagnostic collapse is not an accepted threshold estimate.
