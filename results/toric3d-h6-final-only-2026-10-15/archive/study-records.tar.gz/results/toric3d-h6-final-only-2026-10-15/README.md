# Legacy H+6-CNOT final-only X/Z finite-size study

This experiment uses only the legacy H+6-CNOT plaquette-transfer circuit,
`(T,Ly,Lz)=(L,L,L)`, no intermediate feedback, and one final decode. The two
channels are simulated and fitted independently. Historical H+5 data,
intermediate-feedback results, and `T=2L` aspect-ratio points are excluded.
All production samples are fresh; historical counts were used only to choose
the pilot and the frozen rate range.

## Result

All 80 production points completed: **35,000 X trials and 450,000 Z trials**,
plus 2,540 independent pilot trials. The final artifact audit passed all
396 checks, including independent reconstruction of both primary fits and
all eight sensitivity fits. The final figures were visually inspected.

**Z passes every declared fit guard.** Its protocol-specific threshold is

- **p_c = 0.00534660 = 0.534660%**, with a 95% parametric-bootstrap interval
  **[0.00530812, 0.00537976] = [0.530812%, 0.537976%]**;
- **nu = 0.91509**, with 95% bootstrap interval **[0.86284, 0.97158]**;
- binomial deviance **42.2584 / 40 degrees of freedom**, goodness p=**0.37366**;
- **200/200** usable bootstrap replicates; all four adjacent-size crossings
  share the bracket **[0.00525, 0.0055]**.

The interval is statistical and conditional on the primary quadratic model.
The primary and declared sensitivity fits span **0.525086% to 0.534660%**;
this model sensitivity range is not a confidence interval. In particular,
the leading 1/L correction shifts the estimate below the primary bootstrap
interval while remaining within the declared sensitivity tolerance. The
result is therefore a guarded finite-size estimate for this preparation,
noise model and unit-weight decoder, rather than a universal threshold or a
proof of an infinite-size critical point.

**X does not support a threshold claim under these guards.** The diagnostic
primary candidate is **p0=0.00298108 (0.298108%)**, **nu=0.85970**. Its deviance
is **84.4122 / 30 degrees of freedom**, goodness p=**4.50e-7**, and the
adjacent-size crossing brackets have no common intersection. Both published
X fields (`pc`, `nu`) remain null. All 200 bootstrap fits are numerically
usable, but that cannot validate a rejected scaling model.

The six failed X guards are `goodness_of_fit`, `crossings`,
`sensitivity_drop_smallest`, `sensitivity_narrow_window`, `sensitivity_cubic`,
and `sensitivity_inverse_L_correction`. Every sensitivity model fails the
0.01 goodness criterion; the correction model also places p0 on the lower
fit-window boundary. This withholds an estimate; it does not establish that
no X threshold exists.

| Fit | X diagnostic p0 (%) | X goodness p | Z p_c (%) | Z goodness p |
|---|---:|---:|---:|---:|
| Primary quadratic | 0.298108 | 4.50e-7 | 0.534660 | 0.37366 |
| Drop smallest size | 0.225927 | 0.00518 | 0.533215 | 0.72084 |
| Remove endpoint rates | 0.301837 | 5.10e-5 | 0.534005 | 0.75333 |
| Cubic | 0.313966 | 3.92e-5 | 0.533015 | 0.83961 |
| Add leading 1/L correction | 0.150000 (boundary) | 0.00201 | 0.525086 | 0.59938 |

![Failure-rate panels and their separate fitted insets](analysis/h6-threshold-failure-rates.png)

The figure is also available as [PDF](analysis/h6-threshold-failure-rates.pdf)
and [SVG](analysis/h6-threshold-failure-rates.svg). Exact numerical fits,
guards, bootstrap records, and sensitivity results are in
[`threshold-report.json`](analysis/threshold-report.json),
[`threshold-points.csv`](analysis/threshold-points.csv),
[`bootstrap-samples.csv`](analysis/bootstrap-samples.csv), and
[`sensitivity-fits.csv`](analysis/sensitivity-fits.csv).

## Protocol

The encoded slab has `n=3(L+1)L²` data qubits and two logical qubits, with
`dX=(L+1)L` and `dZ=2L`. Each transfer cell contains one H and six CNOTs,
with 13 independent participating-output fault locations.

- **X channel:** ideal logical `|00>` seed, independent Bernoulli-p X faults
  on all `13L³` transfer gate outputs, no intermediate corrections, and final
  full-plaquette BP+OSD. The fixed decoder uses minimum-sum BP, 50 iterations,
  scaling factor 1, parallel schedule, one OpenMP thread, OSD_CS order 2,
  and a uniform data prior equal to physical p (clamped only at 0 and 1).
- **Z channel:** noisy-H preparation of logical `|++>`, with independent Z
  faults on `3L²` seed-H outputs and `13L³` transfer outputs. Exact sparse
  GF(2) propagation preserves circuit correlations. The final decoder is
  unit-data-weight PyMatching MWPM.

Both channels check that every recovery reproduces the measured syndrome.
A failure is either of the two corresponding residual logical parities.
The preparation and decoders differ by channel; any accepted threshold is
specific to that complete protocol. Measurement, classical processing,
corrections and idles are ideal.

## Pilot and frozen production design

The pilot used 100 samples at each of 25 points: X at L=3,5,7,9 and
p=.002,.0035,.005,.007; Z at L=9,17,25 and p=.0045,.0055,.0065. A separate
40-sample X pilot timed L=11 at p=.0035 and .007. Seeds are independent of
production. The warm first point includes compilation and is not used alone
for runtime extrapolation.

The pilot measured X L=9 costs of .063–.121 seconds/sample, and L=11 costs
of .330–.392 seconds/sample. Z L=25 cost .012–.019 seconds/sample. Historical
X crossings move downward with size, so L=11 is retained to test that drift.
The Z pilot brackets the crossing region: at L=25 it measured 0/100 failures
at .0045, 1/100 at .0055, and 34/100 at .0065. These small pilot counts do not
estimate a threshold.

[`selection.json`](selection.json) freezes the following production grids,
counts, independent master seeds and fit windows before production started:

| Channel | Sizes L | Rates p | Samples/point | Total |
|---|---|---|---:|---:|
| X | 3,5,7,9,11 | .0015,.0025,.0035,.0045,.0055,.007,.009 | 1,000 | 35,000 |
| Z | 9,13,17,21,25 | .0045,.00475,.005,.00525,.0055,.00575,.006,.00625,.0065 | 10,000 | 450,000 |

The initial selection records the model, windows, bootstrap count and major
guards. [`fit-guard-policy.json`](fit-guard-policy.json) records the detailed
numerical tolerances supplied by the fitter implementation during startup,
before production counts were inspected. No production outcomes select or
narrow the primary windows. All sensitivity variants are reported.
The policy file preserves a later clarification: a synthetic regression
exposed acceptance of disconnected crossing clusters, so the crossing guard
was tightened to exactly one connected cluster during production, before
production fitting. The original wording and clarification time are retained.

## Fit and reporting rules

The primary binomial likelihood uses

`logit(Pfail) = a0 + a1 x + a2 x²`,

where `x=((p-p0)/(pmax-pmin)) (L/Lref)^(1/nu)` and `Lref` is the geometric
mean size. The reported threshold and exponent remain null unless every
guard passes: sufficient grid, converged interior parameters with
`.3 < nu < 5`, increasing fitted failure probability, positive goodness
of fit degrees of freedom and deviance p>=.01, consistent adjacent-size
sign-changing crossings, and at least 80% usable bootstrap replicates with
interior 95% intervals.

The 200-replicate parametric binomial bootstrap is conditional on the fitted
candidate model. Its numerical acceptance checks do not rescue a failed
primary goodness-of-fit or crossing guard. The seed is 20261015 for X and
20261016 for Z.

Mandatory sensitivities drop the smallest size, remove both endpoint rates,
use a cubic polynomial, and add a fixed-omega=1 term `c Lref/L` to the logit.
Each must itself pass numerical and goodness guards. Threshold shifts must
be no larger than the maximum of 10% of the full window and the primary
bootstrap 95% interval width; exponent shifts must be no larger than the
maximum of 25% of the primary exponent and its bootstrap interval width.
This is a finite-size consistency screen, not a proof of asymptotic scaling.
Failed candidates remain visible in the figures and machine-readable files.

## Reproducibility

The study starts from `3dTC` at `d63e49a`, containing the H+6 aspect-ratio
implementation `2835029`. The new runner, guarded fitter, independent auditor
and tests are committed locally in `08ad0cc`. The app supplied an isolated worktree of the
requested repository. The original ignored Manifest was copied unchanged;
its archived version is [`Manifest.snapshot.toml`](Manifest.snapshot.toml).
The Julia/Python executables and package versions are recorded in
[`runtime-environment.json`](runtime-environment.json) and each run's metadata.
All installed Python distribution versions are listed in
[`requirements-python.txt`](requirements-python.txt). When recreating a fresh
checkout, restore the archived Manifest as the repository's `Manifest.toml`.

Every point has an independent MersenneTwister. Its 60-bit integer seed is
the first 15 hex digits of SHA256 over UTF-8
`base_seed|channel|L|p_bits`, where p_bits is the 16-character lowercase hex
IEEE754 Float64 bit pattern. CSV stores that exact integer without conversion
to floating point. Point ordering therefore cannot change a point's stream.
Each batch saves the RNG and accumulated counts in an immutable serialized
checkpoint; atomic metadata identifies the committed snapshot. A matching
rerun resumes, rejects altered configuration/source/runtime/checkpoints, and
never adds samples to a completed point.

From the repository root, with the recorded installed environment:

```bash
export JULIA_CONDAPKG_BACKEND=Null
export JULIA_PYTHONCALL_EXE=/Users/rongyuqing/jcode/TopoNoise.jl/.CondaPkg/.pixi/envs/default/bin/python
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 MPLCONFIGDIR=/tmp/toponoise-h6-mpl
julia --project=. --startup-file=no examples/scan_toric3d_h6_threshold.jl \
  --config results/toric3d-h6-final-only-2026-10-15/configs/production-x.toml \
  --output-dir results/toric3d-h6-final-only-2026-10-15/production-x
julia --project=. --startup-file=no examples/scan_toric3d_h6_threshold.jl \
  --config results/toric3d-h6-final-only-2026-10-15/configs/production-z.toml \
  --output-dir results/toric3d-h6-final-only-2026-10-15/production-z
"$JULIA_PYTHONCALL_EXE" examples/fit_toric3d_h6_threshold.py \
  --input-dir results/toric3d-h6-final-only-2026-10-15/production-x \
  --input-dir results/toric3d-h6-final-only-2026-10-15/production-z \
  --output-dir results/toric3d-h6-final-only-2026-10-15/analysis \
  --bootstrap 200 --seed 20261015
"$JULIA_PYTHONCALL_EXE" examples/audit_toric3d_h6_threshold.py \
  --input-dir results/toric3d-h6-final-only-2026-10-15/production-x \
  --input-dir results/toric3d-h6-final-only-2026-10-15/production-z \
  --analysis-dir results/toric3d-h6-final-only-2026-10-15/analysis \
  --output results/toric3d-h6-final-only-2026-10-15/verification/artifact-audit.json
julia --project=. --startup-file=no \
  results/toric3d-h6-final-only-2026-10-15/verification/verify-checkpoints.jl
```

The two production processes each use one Julia/BLAS/OpenMP thread. Running
separate channels concurrently changes wall-clock timing but not seeded
samples. Python analysis uses the same recorded one-thread environment.
Historical result directories and `document/note.tex` are preserved.

## Verification and artifacts

- Full Julia regression: **46,562 assertions in 159 testsets passed**.
- Full Python regression: **89 tests passed**.
- Independent artifact audit: **396 checks passed**, 80 exact grid points,
  485,000 production trials, no failures. It verifies all **2,152 production
  checkpoint hashes** and reconstructs all ten numerical candidates without
  importing the fitting engine.
- Independent Julia checkpoint/replay checks: **3,204 assertions passed**.
  Every serialized final count agrees with CSV. Complete seed replays reproduce
  X L=3,p=.009: `(30,10,27)/1000`; X L=9,p=.0055: `(31,17,27)/1000`;
  Z L=9,p=.0045: `(38,25,26)/10000`; Z L=25,p=.0055:
  `(228,157,141)/10000`. Each tuple is `(union, logical1, logical2)`.
- Resuming twice at nonzero noise gives the same counts and continuing RNG
  state as uninterrupted runs in both channels; the runner has 49 focused
  assertions. Config/source/runtime/snapshot changes are rejected.
- Final PNG panels, legends, intervals, labels and both fit insets were
  visually inspected. The accepted Z estimate and withheld X status are
  explicitly distinguished.
- `document/note.tex` is byte-for-byte unchanged (SHA256
  `3a40710c2ab6bd43e53f5f7703b7c8716b209dc1e060a5092f17e0edce073f3a`).

Verification evidence: [regressions](verification/regression-summary.json),
[artifact audit](verification/artifact-audit.json),
[independent implementation review](verification/independent-review.md),
[X checkpoint/replay](verification/checkpoint-replay-x.txt),
[Z checkpoint/replay](verification/checkpoint-replay-z.txt), and
[visual review](verification/visual-review.json). Deliberately failing
implementation tests are preserved in files named `*-red.txt`; the final
full regression logs are `julia-full.txt` and `python-full.txt`.

Raw data and resumable metadata/checkpoints are retained under
[`production-x`](production-x/) and [`production-z`](production-z/), with
pilot provenance under [`pilot`](pilot/) and [`pilot-x11`](pilot-x11/).
The production run wall times were 45.93 minutes for X and 41.61 minutes for
Z, with concurrent single-thread processes; these are not isolated-core
benchmark times. All work remains local on `codex/h6-final-only-threshold`.
No push, merge, or publication was performed.
