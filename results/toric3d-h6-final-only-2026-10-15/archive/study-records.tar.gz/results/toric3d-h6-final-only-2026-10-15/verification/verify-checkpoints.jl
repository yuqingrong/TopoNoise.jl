# Independent verification: inspect serialized counts and replay selected saved seeds.
using TopoNoise, Random, Test
import TOML, Serialization, SHA
const STUDY = dirname(@__DIR__)
const totals = Dict{String,Any}()
const CHANNELS = isempty(ARGS) ? ["x", "z"] : ARGS
all(in(("x", "z")), CHANNELS) || error("optional arguments must be x and/or z")
@testset "Independent H+6 checkpoints and exact-seed replay" begin
    for channel in CHANNELS
        directory = joinpath(STUDY, "production-" * channel)
        meta = TOML.parsefile(joinpath(directory, "metadata.toml"))
        @test meta["complete"]
        @test haskey(meta["checkpoint_hashes"], meta["current_checkpoint"])
        for (relative, digest) in meta["checkpoint_hashes"]
            @test bytes2hex(SHA.sha256(read(joinpath(directory, relative)))) == digest
        end
        state = open(Serialization.deserialize, joinpath(directory, meta["current_checkpoint"]))
        @test state["index"] == length(state["points"]) + 1
        lines = readlines(joinpath(directory, "raw.csv"))
        header = split(first(lines), ',')
        rows = [Dict(zip(header, split(line, ','))) for line in lines[2:end]]
        @test length(rows) == length(state["points"]) == meta["expected_points"]
        for (row, point) in zip(rows, state["points"])
            @test point["complete"]
            for key in ("steps", "Ly", "Lz", "shots", "failures", "logical_1_failures", "logical_2_failures", "seed")
                @test parse(Int, row[key]) == point[key]
            end
            @test parse(Float64, row["p"]) == point["p"]
            @test row["channel"] == point["channel"]
            @test row["decoder"] == point["decoder"]
            @test row["complete"] == "true"
        end
        selections = channel == "x" ? [(3, .009), (9, .0055)] : [(9, .0045), (25, .0055)]
        replays = Dict{String,Any}[]
        for (L, p) in selections
            point = only(filter(q -> q["Ly"] == L && q["p"] == p, state["points"]))
            code = Toric3DEncodedSlice(L, L, L)
            rng = MersenneTwister(point["seed"])
            n = point["shots"]
            counts = zeros(Int, 3)
            elapsed = @elapsed if channel == "x"
                encoder = toric3d_encoded_encoder(code)
                intermediate = build_toric3d_slice_decoder(code.lattice)
                decoder = build_toric3d_x_threshold_decoder(code; p)
                for shot in 1:n
                    faults = sample_toric3d_faults(rng, encoder; p_x=p, p_z=0.)
                    outcome = replay_toric3d_x_feedback(encoder, faults, intermediate, decoder; feedback=false)
                    counts .+= [outcome.failure, outcome.logical_1, outcome.logical_2]
                end
            else
                model = build_toric3d_z_fault_model(code)
                decoder = build_toric3d_z_threshold_decoder(code)
                for start in 1:meta["config"]["batch_size"]:n
                    batch = min(meta["config"]["batch_size"], n-start+1)
                    frames = sample_toric3d_z_frames(rng, model; p, shots=batch)
                    result = toric3d_z_threshold_counts(decoder, frames)
                    counts .+= [result.failures, result.logical_1_failures, result.logical_2_failures]
                end
            end
            expected = [point[k] for k in ("failures", "logical_1_failures", "logical_2_failures")]
            @test counts == expected
            push!(replays, Dict("L"=>L, "p"=>p, "seed"=>point["seed"], "shots"=>n,
                "actual_counts"=>counts, "expected_counts"=>expected, "elapsed_seconds"=>elapsed))
            println("Replayed ", channel, " L=", L, " p=", p, ": ", counts, " / ", n)
            flush(stdout)
        end
        totals[channel] = Dict("points"=>length(rows), "snapshots"=>length(meta["checkpoint_hashes"]), "replays"=>replays)
    end
end
report_name = isempty(ARGS) ? "checkpoint-replay.toml" : "checkpoint-replay-" * join(CHANNELS, "-") * ".toml"
open(joinpath(@__DIR__, report_name), "w") do io
    TOML.print(io, totals; sorted=true)
end
