# Independent implementation review

Review date: 2026-10-15. The reviewer was separate from the runner and fitter
implementers and wrote the independent artifact-audit utility. No remaining
blocking implementation finding was identified. This is an implementation
review: the production runs were still in progress when it was written. The
final artifact audit, serialized-checkpoint replay, full regressions, and
visual inspection must be read from their completed verification artifacts.
This document does not assert that a threshold was established.

## Scope and scientific identity

The reviewed runner uses the existing, tested legacy plaquette-transfer
H+6-CNOT schedule: one H and six CNOTs, with thirteen noisy participating
outputs per transfer cell. Every configured point has T=Ly=Lz=L. The X path
samples the established post-output fault record, replays it with
`feedback=false`, and calls the final X outcome exactly once. The Z path
uses the established exact sparse fault map and one final MWPM recovery.
Neither path substitutes independent final-data noise for propagated circuit
faults. Every recovery is checked against its measured syndrome by the core
decoder APIs before either logical parity is counted.

The channel-specific seed distinction is preserved. X uses an ideal logical
|00> seed with no seed gate fault locations; Z uses the noisy-H,
measurement-prepared logical |++> seed with 3L² additional fault locations.
The figures and metadata state this difference. A joint depolarizing-noise
threshold is therefore outside the study's interpretation. No H+5 data,
T=2L points, or historical feedback-assisted X threshold is included. The
frozen selection explicitly excludes all historical raw-point reuse.

The recorded single-thread Julia/Python environment and default BP+OSD/MWPM
settings are preserved. The implementation adds example-level orchestration
and analysis; it does not change the core circuit or decoder. The review's
working-tree check found no modification to `document/note.tex`.

## Provenance, checkpoints, and selection

Every point seed is independently reproducible from the master seed,
channel, size, and the exact Float64 probability bits. Configurations,
completed raw counts, both marginal logical counts, source hashes, decoder
settings, package versions, and thread controls are recorded. The artifact
auditor independently recomputes the seed assignment and checks exact grid
coverage, two-logical union algebra, metadata totals, hashes, source-file
coverage, and final-only protocol declarations.

The runner saves immutable Julia-serialized snapshots containing the point
counts and RNG state. Its atomic metadata pointer is the commit record; raw
CSV is a derived mirror that resume can reconstruct. Resume rejects altered
configuration, source/runtime provenance, or snapshot hashes. The Python
audit verifies every recorded snapshot's existence and hash, but does not
claim to deserialize Julia state. The separate `verify-checkpoints.jl`
checks serialized counts against CSV and replays complete selected point
seeds through the validated APIs. This covers different failure modes from
hash verification alone. Reusing those APIs in replay does not constitute a
second independent circuit simulator; the earlier exhaustive propagation
tests supply the circuit-level evidence.

`selection.json` froze the grid, samples, fitting windows, and high-level
analysis choices before production launch. Detailed numerical guard
constants were recorded later during startup in `fit-guard-policy.json`.
Its note records that production counts had not been inspected. A subsequent
timed clarification, recorded during production and before production
fitting, tightened the crossing requirement from "one common intersection"
to "exactly one connected common intersection" after the synthetic
multiple-crossing regression exposed an ambiguity. The policy artifact
preserves the original wording, clarified wording, reason, and timestamp;
the frozen selection, grids, rates, sample counts, seeds, and fitting
windows were unchanged. These are distinct events; this review does not
relabel the later policy document or clarification as a prelaunch
preregistration or independently prove the absence of human inspection.
The current fitter's complete `GUARD_POLICY` was checked against the
recorded policy and matched exactly, including the clarification. The audit
also checks that equality and the frozen configuration/pilot hashes.

## Fitting and refusal behavior

The fitter uses a binomial likelihood and a logistic polynomial in the
finite-size scaling variable. Publishing pc and nu requires every guard:
adequate grid, converged interior optimizer, increasing fitted failure,
acceptable deviance, one connected common crossing bracket, sufficient
usable bootstrap fits with interior intervals, and stable minimum-size,
window, polynomial-order, and leading-correction sensitivities. Failed
candidates remain explicitly diagnostic; bootstrap samples cannot override
a failed crossing, boundary, goodness, or sensitivity guard.

An adversarial multiple-crossing example initially exposed that disconnected
common crossing regions could pass. The fitter owner demonstrated the
failure and changed the guard to require exactly one connected region.
Its regression test now protects that refusal. Endpoint plotting roundoff
was likewise covered by an owner-supplied failing and passing test.
Independent review probes additionally verified that decreasing-p data
fails monotonicity, size-ordered noncrossing data fails the crossing guard,
and zero-count data triggers numerical-bound refusal. Every probe left pc
and nu unpublished.

The independent auditor imports neither the fitter nor its likelihood
engine. It reconstructs the primary and each sensitivity candidate's
coordinates, polynomial probabilities, parameter encoding, binomial
deviance, degrees of freedom, chi-square survival probability, polynomial
derivative minimum, and bound hits from raw counts and recorded candidate
parameters. Synthetic integration reproduced all five candidate variants
with a maximum probability discrepancy of 2.2e-16. The audit explicitly
allows count-scaled floating-point roundoff in nearly zero deviance; this
was demonstrated with a saturated 12-million-shot fixture. It also checks
bootstrap/sensitivity CSV agreement with the report, recomputes Wilson
intervals, requires the complete guard set, and rejects any published
estimate that differs from its guarded candidate.

These guards are evidence checks, not a proof of an infinite-size critical
point. The deviance reference distribution is asymptotic, sparse counts can
make it imperfect, and the bootstrap is conditional on the selected scaling
model. Sensitivity checks reduce, but cannot eliminate, extrapolation error
or establish universal exponents. A diagnostic-only outcome is a valid
completed result.

## Verification snapshot

The auditor's 16 focused tests passed in 3.733 seconds in the recorded Python
environment; the complete log is `audit-focused-green.txt`. Its adversarial
tests cover altered raw counts/seeds/grids, omitted sources, changed
configuration/checkpoints/runtime, omitted guards, improper publication,
changed analysis inputs/engine, missing or inconsistent sample exports,
changed detailed policy, and incorrect candidate probabilities/deviance.
The study coordinator owns the final full Julia/Python regression logs and
the actual production artifact/replay/visual checks.

Reviewed source SHA256 values:

| File | SHA256 |
|---|---|
| `examples/scan_toric3d_h6_threshold.jl` | `6906238eda06375362fe1a167fa5d7c854756e39c1dd98f9d9c676967b4376cd` |
| `examples/fit_toric3d_h6_threshold.py` | `bc5749201b237da0f9ae64967a2eefce25c0244bbd09948e0ead9375a164def2` |
| `examples/audit_toric3d_h6_threshold.py` | `0c4500e8b1edcfd70d307978681d6c6e3737bcc733ecf187d1c8e07a4ee396f3` |

## Completed artifact review

The final review supersedes the pending execution status above. A fresh,
read-only audit of the completed production and analysis directories passed
all **396 checks** for **80 points and 485,000 production trials**. Exact
SHA-derived seeds and logical-union count algebra were additionally checked
directly for production and both pilots; the 2,540 pilot trials remain
separate. All 2,152 production snapshot hashes were verified. The reviewed
runner, fitter, and auditor match implementation commit `08ad0cc` byte for
byte, and `document/note.tex` matches `d63e49a` byte for byte.

The README's substantive numerical results agree with the saved JSON/CSV.
X remains diagnostic-only: p0=0.00298107718, nu=0.85969850, deviance
84.41217/30, goodness p=4.498872e-7, no common crossing interval, and all
four sensitivity guards failed. Its public pc and nu fields are null.
Z passes every guard: pc=0.00534660248, nu=0.91508605, deviance 42.25840/40,
goodness p=0.37365995, and conditional 95% bootstrap interval
[0.00530812382, 0.00537976078], with 200/200 usable replicates.

The range [0.00525085904, 0.00534660248] includes the primary and sensitivity
fits; its upper endpoint is the primary fit. The leading-correction estimate
is below the primary bootstrap interval. The README explicitly discloses
that fact and distinguishes model sensitivity from statistical confidence;
the accepted result remains conditional on the declared finite-size guards.

The replay logs and saved count records agree: X passed 812 assertions and
Z passed 2,392, reproducing all four reported full-point count triples.
Regression-log hashes match their summary; independent log counting confirms
46,562 Julia assertions in 159 passing testsets, and the Python log records
89 passing tests. Direct inspection of the final PNG confirmed readable
separate panels and fitted insets, with the withheld X and accepted Z labels
clearly distinguished. No remaining scientific or artifact-integrity issue
was identified.
