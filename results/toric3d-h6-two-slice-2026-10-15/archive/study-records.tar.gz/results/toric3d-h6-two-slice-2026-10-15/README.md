# H+6 complete recovery on two data slices

## Completed results

All 70 production points finished, each with 1,000 independent fault records:
35,000 records per channel and 140,000 paired protocol outcomes in total.
The excluded 420-record pilot is not included in these counts or fits.

| Channel, at L=11 | Noise p | Final-only failure | Two-slice failure |
| --- | ---: | ---: | ---: |
| X-only | .050 | 723/1000 (72.3%) | 174/1000 (17.4%) |
| Z-only | .030 | 769/1000 (76.9%) | 200/1000 (20.0%) |

Both primary threshold fits remain **diagnostic only**. Their candidate
parameters and the frozen drop-L=3 sensitivity are:

| Channel and fit | Candidate p_c | nu | Deviance/df | Goodness p-value |
| --- | ---: | ---: | ---: | ---: |
| X, all sizes | 0.053565 | 1.4908 | 28.318/30 | 0.5536 |
| X, exclude L=3 | 0.052172 | 1.2854 | 19.001/23 | 0.7012 |
| Z, all sizes | 0.034378 | 1.1495 | 84.653/30 | 4.145e-07 |
| Z, exclude L=3 | 0.035792 | 1.0582 | 27.080/23 | 0.2526 |

The X primary model has acceptable goodness of fit, but lacks a common
adjacent-size crossing bracket and shifts beyond the frozen tolerance with
an inverse-L correction (candidate p_c=.050232). The Z primary model fails
goodness of fit and common-crossing checks. Excluding L=3 gives a reasonable
Z fit, while the inverse-L variant moves its candidate to .040217. These
finite-size/model effects prevent a robust threshold claim for either channel.
The report deliberately leaves the public `pc` and `nu` fields null.
Both seeded conditional bootstraps accepted 200/200 numerical fits; those
conditional intervals do not resolve the failed crossing/model checks.

Figures in `analysis/` are provided as PNG, PDF and SVG:

- `two-slice-comparison`: final-only versus two-slice recovery for X and Z.
- `x-two-slice-local-fit` and `z-two-slice-local-fit`: all-size curves and diagnostic collapse insets.
- `x-two-slice-drop-L3-fit` and `z-two-slice-drop-L3-fit`: the already-computed sensitivity fits, with L=3 excluded.
- `two-slice-paired-differences`: paired improvements with pointwise intervals.

Validation passed: 80,363 assertions in the full Julia suite, 98 study-runner
assertions, 11 analysis tests, and independent deterministic replay of 1,000
X records plus 1,000 Z records. The independent replays checked 16,000
feedback windows and 4,000 final outcomes and exactly reproduced the saved
joint and per-logical counts. All production inputs pass frozen-selection,
source, runtime, checksum, checkpoint and marginal-count validation. The
simulation executes 490,000 complete two-slice recovery windows in total.
`document/note.tex` was not edited. Evidence is retained in `verification/`.

The completed artifact bundle is copied to:
`/Users/rongyuqing/jcode/TopoNoise.jl/results/toric3d-h6-two-slice-2026-10-15/`.

## Protocol

The user specified full syndrome-consistent correction on Q_(t-1) union Q_t
after every transfer, with all required completed syndromes cleared before
retiring the older slice. This study implements that rule separately for X-only
and Z-only gate-output faults on the unchanged H+6 plaquette-transfer circuit.

The correction acts after **every transfer including the last one**. A common
final full-code decoder then scores both residual logical parities. For the
two-slice arm its input syndrome is already zero; this final scoring must not
silently substitute an unrestricted correction for the last two-slice recovery.
The final-only control performs no earlier correction and uses the same final
decoder. Each pair replays exactly the same immutable sampled fault record.

For X, use all physical plaquettes incident to the two recovery slices,
including the plaquettes crossing the retiring boundary. BP+OSD operates on
their incidence matrix restricted to the permitted recovery qubits. For Z,
use the existing three-sheet X-star matching graph and full MWPM recovery on
the same two physical slices. At interior checkpoints, measuring these full
checks can require qubits on three physical slices. Only the **correction**
support is restricted to two slices. Full-prefix syndrome recomputation is a
validation check, never a source of hidden fault information for the decoder.

X prepares ideal logical |00> and has 13L^3 noisy transfer outputs. Z prepares
logical |++>, with 3L^2 noisy seed-H outputs as well as 13L^3 transfer outputs;
the first two-slice recovery handles the seed and first-transfer faults
together, with no extra correction before transfer 1. Gate outputs receive
independent faults with probability p. Measurements, corrections and idles
are ideal. T=Ly=Lz=L in both channels. State failure means either residual
logical parity is nonzero. X and Z use different seed circuits and decoders;
their thresholds therefore describe these sector-specific protocols.

For this complete X-recovery protocol, both logical-Z scoring cycles lie on
the seed slice Q0. After correction of Q0 union Q1, subsequent transfer faults
and corrections never touch Q0. The complete-prefix invariant ensures a zero
syndrome at final scoring. Consequently the logical-X outcome is fixed after
the first corrected window, under the stated ideal-idle model. Tests check
this explicitly. The X curve measures first-window logical damage as a
function of transverse size; it is not a noisy-memory threshold along T.

The earlier Z study's `window_complete` arm omitted a local correction at the
last transfer and instead decoded globally there. Those saved counts are not
relabelled as the protocol specified here.

## Frozen production settings

The excluded pilot used L=3,7,11 and p=0,.01,.02,.03,.04,.06,.08, with 10
records per point per channel (420 records total). Production settings were
frozen in `selection.json` after the pilot and before production began:

| Setting | X-only | Z-only |
| --- | --- | --- |
| Sizes, with T=L | 3,5,7,9,11 | 3,5,7,9,11 |
| Gate-output fault probabilities | .035,.040,.045,.050,.055,.060,.065 | .0275,.0300,.0325,.0350,.0375,.0400,.0425 |
| Independent records per point | 1,000 | 1,000 |
| Points | 35 | 35 |
| Protocol arms per record | final-only and two-slice | final-only and two-slice |

There are 70,000 production fault records and 140,000 protocol outcomes.
The two outcomes of a pair are correlated; they are not two independent
samples. All seven rates are selected for each channel's primary local fit.
L=3 is retained in the primary fit, with the pre-existing drop-smallest-size
sensitivity also evaluated. The scaling model, guards, 200 bootstrap
replicates, seeds, source hashes, runtime signature, and excluded pilot files
are frozen or hash-bound in the selection. A rejected fit is reported as
rejected even if a visually appealing collapse is possible.

X production is divided into disjoint point sets to distribute decoding
cost. Every shard uses a distinct master seed and point stream. Each Julia
process and decoder uses one thread. Recorded timings reflect concurrent
processes and are not isolated performance benchmarks. Repeated execution
with `--resume` reconstructs exactly the same fault stream from its saved
point seeds. Checkpoints, raw counts, per-logical marginals and four-bin
paired histograms are retained.

Figures use the existing reusable no-grid theme and are saved as PNG, PDF
and SVG. The completed artifact bundle is copied to the usual
project results directory. Canonical simulation source is preserved in
`verification/simulation-source.tar.gz`; the earlier Z study's exact source
snapshot is separately preserved in `verification/prior-z-study-source.tar.gz`.

## Analysis and uncertainty

The measured observable is failure of either of the two logical parities,
not a per-logical average. Main-curve error bars are 95% Wilson intervals.
Each paired difference is two-slice minus final-only failure probability;
its pointwise interval is the existing approximate Bonferroni–Wilson
construction from discordant paired counts. These are not simultaneous
intervals over the entire grid.

The local finite-size model is a quadratic in x=(p-p_c)L^(1/nu) for the
log-odds of failure, fitted to the actual binomial counts. Internal rescaling
of x improves numerical conditioning without changing this model. The
primary fit uses all five sizes and the frozen seven-point window. Existing
sensitivity checks remove the smallest size, remove the two endpoint noise
rates, add a cubic term, or add an inverse-L correction. A threshold is
published only if the optimizer, monotonicity, goodness of fit, common
crossing, bootstrap, and sensitivity guards all pass. The collapse inset may
show a rejected candidate, explicitly labeled as a diagnostic. A good-looking
collapse or a small conditional bootstrap error does not override failed
model checks.

The source archive and exact commands in `verification/commands.txt` document
reproduction. Production CSV files contain actual integer counts, and
`analysis/report.json` contains the fitted candidates, failed guards, and
sensitivity results. The normal-project copy is an artifact bundle; the
canonical checkout for rerunning its scripts is
`/Users/rongyuqing/.codex/worktrees/61d4/TopoNoise.jl`.
