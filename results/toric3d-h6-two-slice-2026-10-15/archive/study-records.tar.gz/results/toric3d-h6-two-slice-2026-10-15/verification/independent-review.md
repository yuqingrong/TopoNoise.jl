# Independent review of the two-slice protocol

This is a bounded source and preproduction validation review, not an audit of
future production outcomes. The X and Z implementations match the approved
rule: complete syndrome-consistent recovery supported on Q_(r−1) union Q_r
after every transfer r=1,…,T, including the last. Neither arm performs a
separate correction at r=0. No simulation was run by this reviewer.

## Physical and logical correctness

For X, `src/toric3d/h6_two_slice_x.jl` constructs the recovery matrix from the
full physical plaquettes incident to the permitted two slices. The first
window includes the entire one-transfer prefix. Interior windows include
plaquette layers r−1 and r, so measurements also reach Q_(r−2). The row offset
agrees with the established time-major physical-plaquette ordering. Omitting
the lower-boundary plaquettes would be incorrect; the implementation includes
them and has a targeted boundary-defect regression. Translation-equivalent
interior matrices are checked before sharing their BP+OSD kernel.

Only the measured window syndrome enters BP+OSD. The resulting recovery is
validated against the restricted matrix, applied within the permitted support,
and checked against the entire completed prefix and frontier. Full-prefix
checks and logical diagnostics are audits, not hidden inputs to recovery.
The X final-only control uses the identical full-code decoder object. The
feedback arm completes its local recovery at T before calling the common
final outcome; its zero syndrome therefore cannot be repaired by an unnoticed
unrestricted final correction.

For Z, `src/toric3d/h6_two_slice_z.jl` inserts the noisy seed bits and immediately
starts transfer 1. Its first complete three-sheet recovery handles seed and
first-transfer faults together. Every subsequent window, including T, uses
the existing complete Z matching recovery and verifies all completed-prefix
stars are clear. This is a distinct protocol from the prior Z study's
`window_complete` arm, which repaired the seed separately and omitted the
local correction at T. Prior counts must not be relabelled or pooled here.

Both implementations preserve zero-syndrome logical errors and score both
residual logical parities. The runner samples one immutable record for each
pair, checks that neither replay mutates it, and records four joint state-failure
bins plus both logical counts per arm. X uses the ideal |00> seed and noisy
transfer outputs; Z uses noisy seed-H |++> preparation as well. Their noise
locations, seed circuits and decoders differ, so X/Z threshold comparisons
must retain those qualifications. Measurements, corrections and idle data are
ideal in both cases.

## Important X interpretation

The encoded logical-Z scoring cycles lie entirely on Q0
(`src/toric3d/encoded_slice_geometry.jl:76`). After the first complete X
correction, subsequent gates, gate-output faults and local recoveries have
support only on later slices. The logical-X parities are therefore fixed after
that first window. This is already checked by the X history tests and follows
from the approved circuit and support restriction; it is not a sampling bug.
At fixed transverse size and p, the X feedback failure law is consequently
independent of later preparation depth under the stated ideal-idle model.
Any fitted X transition describes this preparation/first-window decoding
protocol, not a noisy-memory lifetime threshold. Later propagation can spread
an existing logical error without changing those two parities.

## Analysis findings and fixes

The numerical adapter only relabels measured `two_slice_failures` for the
existing H+6 scaling routine. It does not synthesize observations, alter the
likelihood, or change the existing goodness, monotonicity, crossing, bootstrap
and sensitivity guards. Accepted public parameters remain conditional on all
guards passing. The paired intervals retain their pointwise Bonferroni–Wilson
interpretation.

The initial source review found two validation gaps: incomplete or empty
numerical/pilot manifests could pass, and metadata was not bound to the full
approved protocol and runtime environment. With the root reviewer's explicit
authorization, this reviewer changed only `load_points`, `validate_selection`,
their protocol/runtime helpers, and focused tests. The validator now requires:

- The exact H+6 timing, correction, seed, decoder and noise metadata for each
  channel, and the declared one-thread/Null-backend Python environment.
- Both production channels, frozen-before-sampling status, matching shard
  configuration and master seeds, ordered positive fit-rate subsets, at least
  the existing minimum number of bootstrap replicates, and nonnegative integer
  bootstrap seeds.
- Exactly the prior Z numerical adapter and both H+6 fitting-source hashes;
  exactly pilot-x and pilot-z, each with raw, metadata and checkpoint hashes.
  Both pilots are fully loaded and validated, precede the production freeze,
  match the simulation source/runtime, and have no point-seed overlap with
  production.

The first focused run observed 31 expected mutation failures across 11 tests;
the final run passed all 11 tests. Evidence is saved in
`analysis-provenance-red.log` and `analysis-provenance-green.log`. Both actual
Julia fixtures loaded successfully, each containing two points/eight records,
and matched the approved runner signatures. The fixtures intentionally reuse
one master seed and must be loaded separately; combined production channels
must use distinct point seeds. `analysis-provenance-integration.log` records
that check. No paired-statistics, scaling, plotting or main numerical path was
changed. The runner's existing log reports 98 passing assertions; this review
does not claim to have rerun that suite or the full Julia regression suite.

## Preservation and remaining scope

All 53 files inside `prior-z-study-source.tar.gz` that were named by the prior
Z production source manifest match its exact SHA256 values. This preserves
the previous simulation source before the new module includes were added.
`document/note.tex` remains unchanged, with SHA256
`3a40710c2ab6bd43e53f5f7703b7c8716b209dc1e060a5092f17e0edce073f3a`.

No unresolved scientific or implementation issue was identified within this
review's scope. Production selection, final raw/checkpoint checks, seeded
replays, fit conclusions and figure layout still require verification against
the artifacts produced by the subsequent run.

## Subsequent full-suite verification

The requested full repository Julia run later completed with exit code 0:
`julia --compiled-modules=existing --project=. --startup-file=no test/runtests.jl`,
using the managed Python/Null backend and all declared thread counts equal to
one. Its 182 printed top-level summaries contain 80,363 passing assertions,
zero failures, zero errors and zero broken tests. No unrelated baseline
failure was observed. `full-suite.log` and `full-suite-summary.json` preserve
the output, command, environment and counts. During the unusually long run,
a read-only process sample showed active Julia/LLVM compilation rather than
an interactive wait; that evidence is in `full-suite-process-sample.txt`.
No simulation source or tests were changed during this verification.
