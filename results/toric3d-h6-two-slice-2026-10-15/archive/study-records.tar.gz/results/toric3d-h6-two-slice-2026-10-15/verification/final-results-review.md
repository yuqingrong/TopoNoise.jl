# Independent completed-results review

Reviewed the completed production report on 2026-10-15. The bounded read-only
reconciliation passed 2,734 assertions. No discrepancy was found between the
saved production data, replay evidence, fitted diagnostics, and publication
decisions. Both channels correctly report `diagnostic_only`, with public `pc`
and `nu` set to null. Neither threshold is established by this study.

The reviewed `analysis/report.json` SHA-256 is
`e6eab462d8bd909bcc419fc2d699dbe78f5a8b92ac1da892e4b9c66ca699f0a3`.
The frozen `selection.json` SHA-256 is
`5c693d02fe5f010a1cb35df0502122fd267a870b1c8c5c43d3e9fe2cf8e9ee4f`.

## Production and replay reconciliation

| Production shard | Points | Independent fault records |
| --- | ---: | ---: |
| production-x-small | 21 | 21,000 |
| production-x-L9 | 7 | 7,000 |
| production-x-L11-a | 3 | 3,000 |
| production-x-L11-b | 2 | 2,000 |
| production-x-L11-c | 2 | 2,000 |
| production-z | 35 | 35,000 |
| Total | 70 | 70,000 |

Every point has 1,000 completed records. The 140,000 protocol outcomes are two
correlated outcomes per record, not 140,000 independent samples. Both channels
contain the frozen five sizes and seven rates, with no duplicated or omitted
point and no pilot point included. All raw columns agree with the report;
all logical counts, state unions, paired four-bin histograms, and hexadecimal
point seeds agree with the final checkpoints. The 70 point seeds are distinct.
The report's exact input hashes, metadata, checkpoint payload checksums, and
current-snapshot hashes agree with disk. Recorded production starts follow the
selection freeze. All 55 frozen simulation-source hashes and all three frozen
numerical-source hashes match current files; `document/note.tex` retains its
recorded unchanged hash. The report also binds the current analysis source.

All 140 Wilson marginal intervals and all 70 paired differences, standard
errors, and pointwise Bonferroni–Wilson intervals were independently recomputed
from the raw counts. Their two output CSVs agree with the report.

The two production replay records match the final raw rows exactly:

| Replay | Shots | Final-only / two-slice failures | Joint bins 00,01,02,03 | Assertions |
| --- | ---: | --- | --- | ---: |
| X, L=5, p=.05 | 1,000 | 652 / 191 | 297, 512, 51, 140 | 93,094 |
| Z, L=11, p=.035 | 1,000 | 750 / 500 | 134, 366, 116, 384 | 133,094 |

Both per-logical count vectors also agree. These replays were performed during
production; their input hashes bind preserved immutable snapshots, not the
later final `checkpoint.toml`. Those snapshots exist and match their recorded
hashes. The selected rows remain unchanged in the final production outputs.
The regenerated full seed tables match all 21 X-small and all 35 Z point seeds.
Each replay records independent propagation and complete-prefix checks after
every window, including the last, plus 2,000 final outcomes and all 55 frozen
source checks. This review reconciles the saved evidence; it does not claim to
have repeated all 70,000 simulation records.

## Frozen fit decisions

Using a separate audit helper that imports neither the analyzer nor the fitting
engine, I reconstructed all ten primary/sensitivity candidates from their
coefficients and actual counts. Their fitted probabilities, binomial deviances,
degrees of freedom, chi-square goodness probabilities, monotonicity, and bound
diagnostics agree. Bootstrap accepted counts and percentile intervals were
recomputed from the saved samples. The exact frozen guard policy, rate windows,
200-replicate settings, and seeds 2026101541/2026101542 agree with selection.
Independently rebuilt common-crossing sets, sensitivity tolerances, all guard
booleans, and failed-guard lists agree with the report.

| Channel | Diagnostic candidate p_c | Diagnostic nu | Goodness p-value | Failed primary decision guards |
| --- | ---: | ---: | ---: | --- |
| X-only | .0535651466 | 1.49075385 | .553613 | common crossings; inverse-L sensitivity |
| Z-only | .0343777795 | 1.14953121 | 4.14526e-7 | goodness of fit; common crossings; narrow-window, cubic, and inverse-L sensitivities |

For X, dropping L=3, narrowing the rate window, and using a cubic all pass their
sensitivity checks. The inverse-L candidate moves p_c to .0502320416, a shift
of .0033331050 exceeding the frozen .003 tolerance, despite its acceptable
goodness of fit. The common crossing set is empty. A good primary likelihood
fit therefore does not establish a threshold.

For Z, dropping L=3 passes with candidate p_c=.0357922787 and goodness p=.252593.
The narrow-window and cubic candidates remain close to the primary candidate
but fail goodness of fit. The inverse-L candidate improves goodness to .0562582
while moving p_c to .0402172942 and nu to 1.55133414, beyond both stability
tolerances (.0015 and .287382803). The common crossing set is again empty.
These outcomes show material model/size sensitivity; selecting the favorable
variant afterward would contradict the frozen primary decision rule.

Both conditional bootstraps accept 200/200 numerical fits. Their p_c intervals
are [.0523512675, .0546977886] for X and [.0338504434, .0348907948] for Z.
They are conditional on rejected primary models, and exclude the respective
inverse-L candidate p_c. They must not be presented as established threshold
confidence intervals or as covering model uncertainty.

The X first-window interpretation remains essential: under this ideal-idle
protocol the logical-X outcome is fixed after the first corrected window, so
its transverse-size curve is not a noisy-memory lifetime threshold. The
independent source review explains this scope. Plot layout is reviewed by the
root task; this review makes no additional visual claim. No simulation or
analysis source was changed during this final review.
