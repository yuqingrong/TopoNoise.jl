"""Independently replay one saved point; never import the study runner."""
module H6TwoSliceIndependentReplay

using TopoNoise, Random, LinearAlgebra, SparseArrays
import TOML, SHA, PythonCall

const ROOT = abspath(joinpath(@__DIR__, "..", "..", ".."))
const ARMS = ("final_only", "two_slice")
const USAGE = "Usage: replay_point.jl INPUT_DIR L P OUTPUT_TOML"

digest(bytes) = bytes2hex(SHA.sha256(bytes))
parity(matrix, bits) = BitVector(isodd.(matrix * Vector{UInt8}(bits)))
measured(checks, bits) = BitVector(isodd(count(bits[check])) for check in checks)

function check!(counts, category, condition, message)
    condition || error("independent replay [$category]: $message")
    counts[category] = get(counts, category, 0) + 1
    return nothing
end

function canonical_toml(data)
    io = IOBuffer()
    TOML.print(io, data; sorted=true)
    return String(take!(io))
end

function regenerate_seeds(base_seed, number)
    stream = MersenneTwister(base_seed)
    unique_seeds = Set{UInt64}()
    seeds = UInt64[]
    while length(seeds) < number
        seed = rand(stream, UInt64) # Scalar draws: array draws use a different stream.
        seed in unique_seeds && continue
        push!(unique_seeds, seed)
        push!(seeds, seed)
    end
    return seeds
end

function check_runtime!(counts, saved)
    check!(counts, "runtime", string(VERSION) == saved["julia_version"], "Julia version differs")
    check!(counts, "runtime", Threads.nthreads() == BLAS.get_num_threads() == 1,
        "Julia and BLAS must each use one thread")
    for name in ("JULIA_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
        check!(counts, "runtime", get(ENV, name, "") == "1", "$name must equal 1")
    end
    check!(counts, "runtime", get(ENV, "JULIA_CONDAPKG_BACKEND", "") == "Null",
        "JULIA_CONDAPKG_BACKEND must equal Null")
    python = PythonCall.pyconvert(String, PythonCall.pyimport("sys").executable)
    check!(counts, "runtime", realpath(python) == realpath(saved["python_executable"]) ==
        realpath(ENV["JULIA_PYTHONCALL_EXE"]), "Python executable differs")
    versions = PythonCall.pyimport("importlib.metadata")
    for (name, version) in saved["packages"]
        observed = PythonCall.pyconvert(String, versions.version(name))
        check!(counts, "runtime", observed == version, "$name version differs")
    end
    return Dict("julia_version"=>string(VERSION), "python_executable"=>python,
        "julia_threads"=>Threads.nthreads(), "blas_threads"=>BLAS.get_num_threads(),
        "packages"=>saved["packages"])
end

function incidence(checks, qubits)
    columns = Dict(q=>i for (i,q) in enumerate(qubits))
    rows, cols = Int[], Int[]
    for (i, check) in enumerate(checks), q in check
        column = get(columns, q, 0)
        column == 0 && continue
        push!(rows, i); push!(cols, column)
    end
    return sparse(rows, cols, ones(Int, length(rows)), length(checks), length(qubits))
end

function independent_geometry(code, channel)
    physical_checks = channel == "x_only" ? plaquette_checks : star_checks
    full_matrix = incidence(physical_checks(code), 1:data_qubit_count(code))
    logical_supports = channel == "x_only" ? toric3d_encoded_logical_z(code) : toric3d_encoded_logical_x(code)
    logical_matrix = incidence(logical_supports, 1:data_qubit_count(code))
    windows = map(1:code.lattice.steps) do r
        prefix = toric3d_encoded_prefix(code, r)
        complete = [prefix.qubits[check] for check in physical_checks(prefix.code)]
        qubits = vcat(toric3d_slice_qubits(code.lattice, r - 1), toric3d_slice_qubits(code.lattice, r))
        allowed = Set(qubits)
        # Select all physical checks incident to either recovery slice,
        # independently of the production window builders and row offsets.
        checks = filter(check -> any(q in allowed for q in check), complete)
        frontier = channel == "x_only" ?
            [prefix.qubits[check] for check in toric3d_slice_checks(prefix.code.lattice, r)] : Vector{Int}[]
        (;qubits, checks, complete, matrix=incidence(checks, qubits), frontier)
    end
    return (;full_matrix, logical_matrix, windows)
end

function check_final!(counts, result, geometry, channel)
    bits = channel == "x_only" ? result.frame.x : result.frame.z
    other = channel == "x_only" ? result.frame.z : result.frame.x
    matrix = geometry.full_matrix
    check!(counts, "final", length(bits) == length(result.recovery) == length(result.residual) == size(matrix, 2),
        "final data dimensions differ")
    check!(counts, "final", !any(other), "single-channel replay generated the other Pauli channel")
    check!(counts, "final", parity(matrix, bits) == result.syndrome, "final physical syndrome differs")
    check!(counts, "final", parity(matrix, result.recovery) == result.syndrome, "final recovery syndrome differs")
    check!(counts, "final", result.residual == bits .⊻ result.recovery, "final residual is not frame XOR recovery")
    check!(counts, "final", !any(parity(matrix, result.residual)), "final residual is not syndrome-free")
    logical = parity(geometry.logical_matrix, result.residual)
    check!(counts, "final", (result.logical_1, result.logical_2) == Tuple(logical), "logical parities differ")
    check!(counts, "final", result.failure == any(logical), "logical union differs")
end

function check_history!(counts, result, encoder, faults, code, geometry, channel)
    steps = code.lattice.steps
    check!(counts, "history", length(result.history) == steps, "history must contain exactly T windows, no r=0 seed entry")
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    if channel == "z_only"
        frame.z[toric3d_slice_qubits(code.lattice, 0)] .= faults.seed
    end
    transfer = channel == "x_only" ? faults : faults.transfer
    first_operation = 1
    for r in 1:steps
        propagate_toric3d_segment!(frame, encoder, transfer, first_operation, encoder.checkpoints[r])
        first_operation = encoder.checkpoints[r] + 1
        entry, window = result.history[r], geometry.windows[r]
        bits = channel == "x_only" ? frame.x : frame.z
        before = measured(window.checks, bits)
        reported = channel == "x_only" ? entry.pre_syndrome : entry.syndrome
        check!(counts, "history", entry.checkpoint == r, "window order differs or final transfer omitted")
        check!(counts, "history", entry.qubits == window.qubits, "recovery columns differ from newest two data slices")
        check!(counts, "history", reported == before, "measurement differs from independently propagated frame")
        check!(counts, "history", parity(window.matrix, entry.recovery) == before, "recovery does not reproduce all physical window checks")
        check!(counts, "history", entry.support == window.qubits[findall(entry.recovery)], "physical recovery support differs")
        check!(counts, "history", all(data_qubit_coordinate(code, q)[2] in (r - 1, r) for q in entry.support),
            "recovery leaves the newest two data slices")
        bits[window.qubits] .⊻= entry.recovery
        post = measured(window.checks, bits)
        prefix = measured(window.complete, bits)
        check!(counts, "history", !any(post), "window syndrome remains nonzero")
        check!(counts, "history", !any(prefix), "complete-prefix syndrome remains nonzero")
        if channel == "x_only"
            check!(counts, "history", entry.checks == window.checks, "X physical check selection differs")
            check!(counts, "history", entry.measurement_support == sort!(unique(vcat(window.checks...))),
                "X measurement support differs")
            check!(counts, "history", entry.post_syndrome == post, "X window post-syndrome differs")
            check!(counts, "history", entry.prefix_syndrome == prefix, "X complete-prefix history differs")
            frontier = measured(window.frontier, bits)
            check!(counts, "history", !any(frontier) && entry.frontier_syndrome == frontier, "X frontier is not clear")
            check!(counts, "history", entry.logical_after == parity(geometry.logical_matrix, bits),
                "X diagnostic logical history differs")
        else
            check!(counts, "history", entry.kind === :window, "Z history includes a separate seed correction")
            check!(counts, "history", entry.post_syndrome == prefix, "Z complete-prefix history differs")
        end
    end
    check!(counts, "history", frame.x == result.frame.x && frame.z == result.frame.z,
        "independent history propagation differs from pre-final frame")
    check!(counts, "history", !any(result.syndrome), "last complete window did not clear final syndrome")
    check!(counts, "history", !any(result.recovery), "final zero-syndrome recovery is nonzero")
end

function main(arguments=ARGS)
    length(arguments) == 4 || throw(ArgumentError(USAGE))
    started = time()
    directory = abspath(arguments[1])
    selected_L, selected_p = parse(Int, arguments[2]), parse(Float64, arguments[3])
    output = abspath(arguments[4])
    checkpoint_path = joinpath(directory, "checkpoint.toml")
    output == checkpoint_path && throw(ArgumentError("output cannot overwrite the checkpoint"))
    counts = Dict{String,Int}()
    bytes = read(checkpoint_path)
    saved = TOML.parse(String(copy(bytes)))
    check!(counts, "checkpoint", saved["format_version"] == 1, "unsupported checkpoint format")
    payload = copy(saved)
    checksum = pop!(payload, "payload_sha256")
    check!(counts, "checkpoint", checksum == digest(canonical_toml(payload)), "payload checksum differs")
    snapshot_name = "checkpoint-" * lpad(saved["generation"], 6, '0') * "-" * checksum[1:12] * ".toml"
    snapshot = joinpath(directory, "checkpoints", snapshot_name)
    check!(counts, "checkpoint", read(snapshot) == bytes, "immutable checkpoint snapshot differs")
    config = saved["config"]
    channel = config["channel"]
    check!(counts, "checkpoint", channel in ("x_only", "z_only"), "unsupported noise channel")
    check!(counts, "checkpoint", config["dimensions"] == [[L, L, L] for L in config["sizes"]],
        "dimensions do not satisfy T=Ly=Lz=L")
    check!(counts, "checkpoint", saved["protocol"]["arm_order"] == collect(ARMS), "arm order differs")
    check!(counts, "checkpoint", saved["protocol"]["channel"] == channel, "protocol channel differs")
    grid = [(L, p) for L in config["sizes"] for p in config["rates"]]
    check!(counts, "checkpoint", length(grid) == length(saved["states"]), "grid and states differ")
    selected = findall(==((selected_L, selected_p)), grid)
    check!(counts, "checkpoint", length(selected) == 1, "requested point is absent or duplicated")
    index = only(selected)
    state = saved["states"][index]
    shots = state["completed_shots"]
    check!(counts, "checkpoint", 0 < shots <= config["shots"], "requested point has no saved samples")
    seeds = regenerate_seeds(config["seed"], length(grid))
    hex_seeds = [string(seed; base=16, pad=16) for seed in seeds]
    check!(counts, "seeds", all(occursin(r"^[0-9a-f]{16}$", seed) for seed in saved["point_seeds_hex"]),
        "point seeds are not 16 lowercase hexadecimal digits")
    check!(counts, "seeds", hex_seeds == saved["point_seeds_hex"], "regenerated point seed list differs")
    check!(counts, "seeds", parse(UInt64, saved["point_seeds_hex"][index]; base=16) == seeds[index], "chosen seed differs")
    observed_sources = Dict{String,String}()
    for (path, expected) in saved["source_hashes"]
        observed_sources[path] = digest(read(joinpath(ROOT, path)))
        check!(counts, "sources", observed_sources[path] == expected, "source hash differs: $path")
    end
    runtime = check_runtime!(counts, saved["runtime"])
    code = Toric3DEncodedSlice(selected_L, selected_L, selected_L)
    encoder = toric3d_encoded_encoder(code)
    build_seconds = @elapsed begin
        if channel == "x_only"
            settings = Toric3DDecoderSettings()
            declared = Dict(string(k)=>v for (k,v) in pairs(TopoNoise._toric3d_settings_metadata(settings)))
            check!(counts, "decoder", declared == saved["protocol"]["decoder_settings"], "X decoder settings differ")
            decoder = build_toric3d_h6_two_slice_x_decoder(code; p=selected_p, settings)
        else
            check!(counts, "decoder", saved["protocol"]["decoder_settings"] ==
                Dict("weights"=>1.0, "merge_strategy"=>"smallest-weight"), "Z decoder settings differ")
            decoder = build_toric3d_z_feedback_decoders(code)
        end
    end
    geometry = independent_geometry(code, channel)
    joint, logical_1, logical_2, failures = zeros(Int, 4), zeros(Int, 2), zeros(Int, 2), zeros(Int, 2)
    rng = Xoshiro(seeds[index])
    replay_seconds = @elapsed for shot in 1:shots
        faults = channel == "x_only" ? sample_toric3d_faults(rng, encoder; p_x=selected_p, p_z=0.0) :
            sample_toric3d_diagonal_z_faults(rng, encoder; p=selected_p)
        original = deepcopy(faults)
        mask = 0
        for (arm, feedback) in enumerate((false, true))
            # Direct public core calls. No runner import or second final decoder call.
            result = channel == "x_only" ?
                replay_toric3d_h6_two_slice_x(encoder, faults, decoder; feedback, record_history=feedback) :
                replay_toric3d_h6_two_slice_z(encoder, faults, decoder; feedback, record_history=feedback)
            check!(counts, "immutability", faults == original, "$(ARMS[arm]) mutated record $shot")
            check_final!(counts, result, geometry, channel)
            feedback ? check_history!(counts, result, encoder, faults, code, geometry, channel) :
                check!(counts, "history", isempty(result.history), "disabled feedback has correction history")
            logical_1[arm] += result.logical_1
            logical_2[arm] += result.logical_2
            failures[arm] += result.failure
            result.failure && (mask |= 1 << (arm - 1))
        end
        joint[mask + 1] += 1
    end
    for mask in 0:3
        check!(counts, "counts", joint[mask + 1] == state["joint_counts"][mask + 1], "joint bin $mask differs")
    end
    for arm in 1:2
        check!(counts, "counts", logical_1[arm] == state["logical_1_counts"][arm], "logical-1 marginal differs")
        check!(counts, "counts", logical_2[arm] == state["logical_2_counts"][arm], "logical-2 marginal differs")
        check!(counts, "counts", failures[arm] == state["failures"][arm], "failure marginal differs")
        marginal = sum(joint[mask + 1] for mask in 0:3 if !iszero(mask & (1 << (arm - 1))))
        check!(counts, "counts", marginal == failures[arm], "joint marginal differs from failure count")
    end
    check!(counts, "counts", sum(joint) == shots, "joint histogram total differs")
    summary = Dict{String,Any}("status"=>"passed", "verification"=>"independent deterministic two-slice point replay",
        "channel"=>channel, "dimensions"=>[selected_L, selected_L, selected_L], "p"=>selected_p,
        "shots"=>shots, "target_shots"=>config["shots"], "point_index"=>index, "base_seed"=>config["seed"],
        "point_seed_hex"=>hex_seeds[index], "regenerated_point_seeds_hex"=>hex_seeds, "arm_order"=>collect(ARMS),
        "joint_counts"=>joint, "logical_1_counts"=>logical_1, "logical_2_counts"=>logical_2, "failures"=>failures,
        "assertions_total"=>sum(values(counts)), "assertions_by_category"=>counts,
        "histories_checked"=>shots, "windows_checked"=>shots*selected_L, "last_windows_checked"=>shots,
        "final_outcomes_checked"=>2shots, "build_seconds"=>build_seconds, "replay_seconds"=>replay_seconds,
        "total_seconds"=>time()-started, "input_directory"=>directory, "input_checkpoint"=>checkpoint_path,
        "input_checkpoint_sha256"=>digest(bytes), "input_payload_sha256"=>checksum, "input_snapshot"=>snapshot,
        "input_generation"=>saved["generation"], "source_hashes"=>observed_sources,
        "verifier_sha256"=>digest(read(@__FILE__)), "runtime"=>runtime,
        "final_validation"=>"independent physical-check and logical-support matrix products; no extra final decode",
        "history_validation"=>"independent propagation of the recorded faults and recoveries, all incident physical checks, complete prefix after all r=1:T, no separate Z seed correction")
    mkpath(dirname(output))
    open(output * ".tmp", "w") do io
        TOML.print(io, summary; sorted=true)
    end
    mv(output * ".tmp", output; force=true)
    println("Passed ", channel, " L=", selected_L, " p=", selected_p, " shots=", shots,
        ": ", summary["assertions_total"], " assertions; joint=", joint)
    println("Saved ", output)
    return summary
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    H6TwoSliceIndependentReplay.main()
end
