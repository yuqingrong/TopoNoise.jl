The Z two-slice data show a finite-size crossover, but the frozen primary scaling model does not establish a threshold. This review used the existing `candidate_fit`, `numerical_guards`, and `crossing_clusters` functions without numerical changes, data reselection, or bootstrap. The primary and four sensitivity variants are exactly the variants already specified by the analysis.

| Frozen variant | Candidate p_c | Candidate nu | Deviance / degrees of freedom | Goodness p-value |
|---|---:|---:|---:|---:|
| Primary, L=3,5,7,9,11; p=.0275–.0425 | .03437778 | 1.14953 | 84.653 / 30 | 4.15e-7 |
| Drop smallest size L=3 | .03579228 | 1.05825 | 27.080 / 23 | .2526 |
| Narrow window, p=.0300–.0400 | .03419252 | 1.17452 | 67.922 / 20 | 3.96e-7 |
| Cubic scaling polynomial | .03438178 | 1.17568 | 84.236 / 29 | 2.73e-7 |
| Fixed inverse-L correction | .04021729 | 1.55133 | 41.991 / 29 | .0563 |

Every optimizer converged to an interior, monotone candidate. The poor primary goodness therefore is not an optimizer-boundary failure. Dropping L=3 improves the numerical fit substantially and shifts p_c by +.00141450; this shift is just below the frozen .0015 minimum p_c sensitivity tolerance. Narrowing the rate window barely moves the candidate but leaves essentially the same strong lack of fit. A cubic polynomial also does not repair the mismatch. The prespecified inverse-L correction improves goodness but moves p_c by +.00583951 and nu by +.40180, demonstrating appreciable model dependence. Final sensitivity acceptance still belongs to the official bootstrap-inclusive analysis; a passing diagnostic variant cannot replace the failed primary fit.

Observed adjacent-size crossing locations from the frozen linear interpolation are .02792969 for L=3/5 and .03227612 for L=5/7. The L=7/9 curves cross three times (.03429878, .03599138, .03903509), and L=9/11 cross three times (.03701923, .03812500, .04133929). Their sign-changing sampled brackets have no common intersection across all adjacent-size pairs. These interpolations are noisy empirical crossings, not individual threshold estimates.

The physical trend is nevertheless clear: at p=.0275, the two-slice failure rate falls from .317 at L=3 to .096 at L=11; at p=.0425 it rises from .624 to .748. Near p=.035 the five rates cluster between .456 and .521. This supports a crossover in the measured regime and is consistent with unresolved finite-size effects; it does not validate a unique asymptotic p_c or universal nu. The frozen primary goodness and crossing guards already fail, so a precise bootstrap interval around its candidate cannot rescue a threshold claim. The main report should retain “threshold not established” and show these candidate fits only as diagnostics.

This interpretation is restricted to the recorded Z-only model, ideal measurements and corrections, T=Ly=Lz=L, no separate seed correction, and complete two-slice recovery after every transfer including the final transfer.
