using TopoNoise
using ITensors
using Random
using Test

include("toric_code_peps.jl")
include("local_gate.jl")
include("network_graph.jl")
include("sequential_circuit.jl")
include("example.jl")
include("visualization.jl")
include("rotated_planar/runtests.jl")
include("rotated_planar/encoder.jl")
include("rotated_planar/input_preparation.jl")
include("rotated_planar/noise.jl")
include("rotated_planar/decoder.jl")
include("rotated_planar/scan.jl")
include("rotated_planar/comparison.jl")
include("rotated_planar/scaling.jl")
include("rotated_planar/comparison_plot.jl")
include("rotated_planar/post_encoding.jl")
include("rotated_planar/duality.jl")
include("toric3d/runtests.jl")
