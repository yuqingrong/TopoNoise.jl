using Test, Random, TopoNoise

# Keep both the previous row implementation and a scalar GF(2) reference here
# so parity comparisons are independent of the optimized packed-column path.
matrix_syndrome_row_reference(matrix, frame) = BitVector(
    isodd(count((@view matrix[row, :]) .& frame)) for row in axes(matrix, 1))
matrix_syndrome_scalar_reference(matrix, frame) = BitVector(
    reduce(xor, (matrix[row, col] && frame[col] for col in axes(matrix, 2)); init=false)
    for row in axes(matrix, 1))
matrix_syndrome_allocated(matrix, frame) = @allocated TopoNoise._toric3d_matrix_syndrome(matrix, frame)

@testset "Packed GF(2) matrix syndrome" begin
    @testset "Parity agrees at empty, rectangular, and packed-word boundaries" begin
        rng = MersenneTwister(2026101501)
        for rows in (0, 1, 2, 63, 64, 65, 129), cols in (0, 1, 2, 63, 64, 65, 129)
            matrix = bitrand(rng, rows, cols)
            saved_matrix = copy(matrix)
            for density in (0.0, 0.01, 0.5, 1.0)
                frame = BitVector(rand(rng, cols) .< density)
                saved_frame = copy(frame)
                result = TopoNoise._toric3d_matrix_syndrome(matrix, frame)
                @test result isa BitVector
                @test length(result) == rows
                @test result == matrix_syndrome_row_reference(matrix, frame)
                @test result == matrix_syndrome_scalar_reference(matrix, frame)
                @test frame == saved_frame
                @test matrix == saved_matrix
            end
        end
    end

    @testset "Frame length is validated even for empty dimensions" begin
        for (rows, cols, length) in ((0, 0, 1), (0, 65, 64), (1, 65, 64),
                (65, 0, 1), (65, 64, 65), (65, 65, 1))
            @test_throws DimensionMismatch TopoNoise._toric3d_matrix_syndrome(
                falses(rows, cols), falses(length))
        end
    end

    @testset "Large zero and sparse frames avoid allocating one vector per row" begin
        matrix = bitrand(MersenneTwister(2026101502), 3993, 4356)
        zero = falses(4356)
        sparse = falses(4356); sparse[1:20:end] .= true
        for frame in (zero, sparse)
            @test TopoNoise._toric3d_matrix_syndrome(matrix, frame) ==
                matrix_syndrome_row_reference(matrix, frame)
            # Warm both the calculation and allocation-measurement wrapper.
            matrix_syndrome_allocated(matrix, frame)
            bytes = matrix_syndrome_allocated(matrix, frame)
            # The previous row implementation allocates about 2.56 MB here;
            # packed columns need under 140 KB even for the sparse frame.
            @test bytes <= 512 * 1024
        end
    end
end
