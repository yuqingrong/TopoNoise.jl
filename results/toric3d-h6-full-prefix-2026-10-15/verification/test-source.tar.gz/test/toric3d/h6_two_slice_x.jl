using Test, Random, TopoNoise

@testset "H+6 complete two-slice X API exists" begin
    @test isdefined(TopoNoise, :build_toric3d_h6_two_slice_x_decoder)
    @test isdefined(TopoNoise, :replay_toric3d_h6_two_slice_x)
end

if isdefined(TopoNoise, :build_toric3d_h6_two_slice_x_decoder)

h6_two_x_syndrome(matrix, bits) = BitVector(isodd.(Int.(matrix) * Int.(bits)))
h6_two_x_checks(checks, bits) = BitVector(isodd(count(bits[check])) for check in checks)

function h6_two_x_audit(result, decoder)
    code = decoder.code
    @test !any(result.frame.z)
    @test length(result.history) == code.lattice.steps
    for entry in result.history
        r = entry.checkpoint
        window = decoder.windows[r]
        @test entry.checks == window.checks
        @test entry.qubits == vcat(toric3d_slice_qubits(code.lattice, r-1),
                                   toric3d_slice_qubits(code.lattice, r))
        @test entry.support == entry.qubits[findall(entry.recovery)]
        @test all(data_qubit_coordinate(code, q)[2] in (r-1, r) for q in entry.support)
        @test entry.measurement_support == sort!(unique(vcat(entry.checks...)))
        @test Set(data_qubit_coordinate(code, q)[2] for q in entry.measurement_support) ==
              Set(max(0, r-2):r)
        @test h6_two_x_syndrome(window.matrix, entry.recovery) == entry.pre_syndrome
        @test !any(entry.post_syndrome)
        @test !any(entry.prefix_syndrome)
        @test !any(entry.frontier_syndrome)
    end
    # The last transfer is corrected too; the common final decoder sees zero.
    @test last(result.history).checkpoint == code.lattice.steps
    @test !any(result.syndrome)
    @test !any(result.recovery)
    @test result.residual == result.frame.x
    outcome = toric3d_x_threshold_outcome(decoder.final, result.frame.x)
    @test (result.syndrome, result.recovery, result.residual,
           result.logical_1, result.logical_2, result.failure) == values(outcome)
    @test all(entry.logical_after == first(result.history).logical_after for entry in result.history)
    @test last(result.history).logical_after == BitVector([result.logical_1, result.logical_2])
end

@testset "Two-slice X geometry caches the first and interior recovery problems" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.02)
    @test decoder.code === code
    @test decoder.final isa Toric3DXThresholdDecoder
    @test decoder.final.code === code
    @test size(decoder.first.matrix) == (18, 36)
    @test size(decoder.interior.matrix) == (36, 36)
    @test decoder.windows[1].matrix == decoder.first.matrix
    @test decoder.windows[2].matrix == decoder.windows[3].matrix == decoder.interior.matrix
    @test length(decoder.windows[1].checks) == 18
    @test length(decoder.windows[2].checks) == 36
    @test decoder.first.prior == decoder.interior.prior == .02
end

@testset "Every small transfer X fault is repaired without retiring a syndrome" begin
    code = Toric3DEncodedSlice(2, 2, 2)
    encoder = toric3d_encoded_encoder(code)
    decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.02)
    clean = sample_toric3d_faults(MersenneTwister(5), encoder; p_x=0, p_z=0)
    zero = replay_toric3d_h6_two_slice_x(encoder, clean, decoder; record_history=true)
    h6_two_x_audit(zero, decoder)
    @test !zero.failure
    @test !any(zero.frame.x)
    @test all(!any(entry.recovery) for entry in zero.history)
    @test isempty(replay_toric3d_h6_two_slice_x(encoder, clean, decoder).history)
    checked = 0
    for (gate, operation) in enumerate(encoder.operations), q in operation.qubits
        faults = with_toric3d_fault(encoder, clean, gate, q, :X)
        saved = (copy(faults.x), copy(faults.z))
        result = replay_toric3d_h6_two_slice_x(encoder, faults, decoder; record_history=true)
        h6_two_x_audit(result, decoder)
        @test (faults.x, faults.z) == saved
        checked += 1
    end
    @test checked == 104
end

@testset "Two-slice X random rectangular histories and final-only comparison" begin
    for dims in ((3, 2, 2), (3, 2, 3), (3, 3, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.12)
        slice = build_toric3d_slice_decoder(code.lattice)
        for seed in 1:6
            faults = sample_toric3d_faults(MersenneTwister(seed), encoder; p_x=.12, p_z=0)
            saved = (copy(faults.x), copy(faults.z))
            result = replay_toric3d_h6_two_slice_x(encoder, faults, decoder; record_history=true)
            h6_two_x_audit(result, decoder)
            baseline = replay_toric3d_h6_two_slice_x(encoder, faults, decoder; feedback=false)
            established = replay_toric3d_x_feedback(encoder, faults, slice, decoder.final; feedback=false)
            for key in (:frame, :syndrome, :recovery, :residual, :logical_1, :logical_2, :failure)
                @test getproperty(baseline, key) == getproperty(established, key)
            end
            @test (faults.x, faults.z) == saved
        end
    end
end

@testset "Final transfer and T=1 receive complete two-slice X correction" begin
    for T in (1, 3)
        code = Toric3DEncodedSlice(T, 2, 3)
        encoder = toric3d_encoded_encoder(code)
        decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.02)
        clean = sample_toric3d_faults(MersenneTwister(11), encoder; p_x=0, p_z=0)
        gate = last(encoder.checkpoints)
        faults = with_toric3d_fault(encoder, clean, gate, last(encoder.operations[gate].qubits), :X)
        result = replay_toric3d_h6_two_slice_x(encoder, faults, decoder; record_history=true)
        h6_two_x_audit(result, decoder)
        @test any(last(result.history).pre_syndrome)
        @test any(last(result.history).recovery)
        @test !any(result.syndrome)
        @test !any(result.recovery)
        if T == 1
            @test decoder.interior === nothing
            baseline = replay_toric3d_h6_two_slice_x(encoder, faults, decoder; feedback=false)
            @test result.residual == baseline.residual
            @test (result.logical_1, result.logical_2) == (baseline.logical_1, baseline.logical_2)
        end
    end
end

@testset "Two-slice X window includes checks crossing its lower boundary" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.02)
    small = Toric3DEncodedSlice(1, 2, 3)
    seed_white = toric3d_encoded_seed_checks(small).x[7]
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    for q in seed_white
        direction, t, u, v = data_qubit_coordinate(small, q)
        frame.x[data_qubit_index(code, direction, t+1, u, v)] = true
    end
    # A white lower-boundary star is invisible to the isolated two-slice slab,
    # but is an actual defect on plaquettes belonging to the preceding layer.
    window = decoder.windows[2]
    measured = h6_two_x_checks(window.checks, frame.x)
    @test any(measured[1:18])
    @test !any(measured[19:end])
    entry = TopoNoise._toric3d_apply_h6_two_slice_x!(frame, decoder, 2; record_history=true)
    @test !any(entry.post_syndrome)
    @test !any(entry.prefix_syndrome)
end

@testset "Undetectable X logical information survives local recovery" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    decoder = build_toric3d_h6_two_slice_x_decoder(code; p=.02)
    clean = sample_toric3d_faults(MersenneTwister(23), encoder; p_x=0, p_z=0)
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    prefix = toric3d_encoded_prefix(code, 1)
    frame.x[prefix.qubits[first(toric3d_encoded_logical_x(prefix.code))]] .= true
    first_operation = encoder.checkpoints[1] + 1
    for r in 1:3
        if r > 1
            propagate_toric3d_segment!(frame, encoder, clean, first_operation, encoder.checkpoints[r])
            first_operation = encoder.checkpoints[r] + 1
        end
        before = copy(frame.x)
        entry = TopoNoise._toric3d_apply_h6_two_slice_x!(frame, decoder, r; record_history=true)
        @test !any(entry.pre_syndrome)
        @test !any(entry.recovery)
        @test frame.x == before
        @test entry.logical_after == BitVector([true, false])
    end
    outcome = toric3d_x_threshold_outcome(decoder.final, frame.x)
    @test (outcome.logical_1, outcome.logical_2, outcome.failure) == (true, false, true)
end

@testset "Two-slice X API rejects incompatible inputs" begin
    code = Toric3DEncodedSlice(2, 2, 2)
    encoder = toric3d_encoded_encoder(code)
    decoder = build_toric3d_h6_two_slice_x_decoder(code; p=0)
    @test decoder.first.prior == decoder.interior.prior == 1e-12
    clean = sample_toric3d_faults(MersenneTwister(41), encoder)
    z_fault = with_toric3d_fault(encoder, clean, 1, only(encoder.operations[1].qubits), :Z)
    @test_throws ArgumentError replay_toric3d_h6_two_slice_x(encoder, z_fault, decoder)
    wrong = toric3d_encoded_encoder(Toric3DEncodedSlice(1, 2, 2))
    @test_throws DimensionMismatch replay_toric3d_h6_two_slice_x(wrong,
        sample_toric3d_faults(MersenneTwister(43), wrong), decoder)
    @test_throws ArgumentError build_toric3d_h6_two_slice_x_decoder(code; p=-.01)
    @test_throws ArgumentError build_toric3d_h6_two_slice_x_decoder(code; p=NaN)
end

end
