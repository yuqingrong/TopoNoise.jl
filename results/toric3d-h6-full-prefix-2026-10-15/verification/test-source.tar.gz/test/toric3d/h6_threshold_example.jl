using Test
using Random
using TopoNoise
import TOML
import SHA
import Serialization

const H6_THRESHOLD_EXAMPLE = abspath(joinpath(@__DIR__, "..", "..", "examples", "scan_toric3d_h6_threshold.jl"))

@testset "H+6 final-only threshold runner exists" begin
    @test isfile(H6_THRESHOLD_EXAMPLE)
end

if isfile(H6_THRESHOLD_EXAMPLE)
include(H6_THRESHOLD_EXAMPLE)

function h6_test_config(path; shots=7, rates=[0.0, 0.02], channels=["x_only", "z_only"])
    data = Dict("stage"=>"regression", "seed"=>1234, "shots"=>shots,
        "batch_size"=>3, "channels"=>Dict(c=>Dict("sizes"=>[2], "rates"=>rates) for c in channels))
    open(path,"w") do io
        TOML.print(io,data; sorted=true)
    end
    return path
end

function h6_raw_counts(path)
    rows = readlines(path)
    # Wall time is deliberately not compared: RNG, counts, and all labels must match.
    return [split(row,',')[[1:11; 13]] for row in rows]
end

@testset "H+6 exact point seeds and strict configuration" begin
    @test H6ThresholdExample.point_seed(1234,"x_only",2,0.02) == 566156783484711123
    mktempdir() do dir
        path=h6_test_config(joinpath(dir,"config.toml"))
        cfg=H6ThresholdExample.load_config(path)
        @test length(H6ThresholdExample.grid(cfg)) == 4
        for (key,value) in [("shots",0),("seed",-1),("batch_size",0),("stage","")]
            bad=deepcopy(cfg); bad[key]=value
            @test_throws ArgumentError H6ThresholdExample.validate_config(bad)
        end
        for (key,value) in [("sizes",[1]),("sizes",[2,2]),("sizes",[2.0]),
                ("rates",[-0.01]),("rates",[0.5]),("rates",[0.01,0.01]),("rates",Float64[])]
            bad=deepcopy(cfg); bad["channels"]["x_only"][key]=value
            @test_throws ArgumentError H6ThresholdExample.validate_config(bad)
        end
        bad=deepcopy(cfg); bad["channels"]["y_only"]=bad["channels"]["x_only"]
        @test_throws ArgumentError H6ThresholdExample.validate_config(bad)
        bad=deepcopy(cfg); bad["feedback"]=true
        @test_throws ArgumentError H6ThresholdExample.validate_config(bad)
    end
end

@testset "H+6 exact resume and zero-noise channels" begin
    mktempdir() do dir
        config=h6_test_config(joinpath(dir,"config.toml"))
        direct=joinpath(dir,"direct"); resumed=joinpath(dir,"resumed")
        first=H6ThresholdExample.run_study(config,resumed;stop_after_batches=1,io=devnull)
        @test !first["complete"]
        @test first["completed_shots"] == 3
        @test length(readlines(joinpath(resumed,"raw.csv"))) == 1
        H6ThresholdExample.run_study(config,resumed;io=devnull)
        H6ThresholdExample.run_study(config,direct;io=devnull)
        @test h6_raw_counts(joinpath(resumed,"raw.csv")) == h6_raw_counts(joinpath(direct,"raw.csv"))
        before=read(joinpath(resumed,"raw.csv"))
        metadata=H6ThresholdExample.run_study(config,resumed;io=devnull)
        @test metadata["complete"]
        @test metadata["completed_shots"] == 28
        @test read(joinpath(resumed,"raw.csv")) == before
        @test metadata["raw_csv_sha256"] == bytes2hex(SHA.sha256(before))
        @test metadata["intermediate_feedback"] == false
        @test metadata["decoding"] == "final-only"
        @test metadata["source_hashes"]["Project.toml"] == bytes2hex(SHA.sha256(read(joinpath(@__DIR__,"..","..","Project.toml"))))
        @test length(metadata["grid"]) == 4
        @test all(p -> p["steps"] == p["Ly"] == p["Lz"], metadata["grid"])
        for line in readlines(joinpath(direct,"raw.csv"))[2:end]
            entries=split(line,',')
            if parse(Float64,entries[5]) == 0
                @test parse.(Int,entries[7:9]) == [0,0,0]
            end
        end
        # A changed requested sample count must never silently reuse earlier samples.
        h6_test_config(config;shots=8)
        @test_throws ArgumentError H6ThresholdExample.run_study(config,resumed;io=devnull)
    end
end

@testset "H+6 nonzero-noise partial resumes preserve each channel RNG stream" begin
    for channel in ("x_only","z_only")
        mktempdir() do dir
            config=h6_test_config(joinpath(dir,"config.toml");
                shots=11,rates=[0.08],channels=[channel])
            resumed=joinpath(dir,"resumed"); direct=joinpath(dir,"direct")
            first=H6ThresholdExample.run_study(config,resumed;stop_after_batches=1,io=devnull)
            @test first["completed_shots"] == 3
            @test !first["complete"]
            second=H6ThresholdExample.run_study(config,resumed;stop_after_batches=1,io=devnull)
            @test second["completed_shots"] == 6
            @test !second["complete"]
            saved=H6ThresholdExample.run_study(config,resumed;io=devnull)
            reference=H6ThresholdExample.run_study(config,direct;io=devnull)
            @test saved["completed_shots"] == 11
            @test h6_raw_counts(joinpath(resumed,"raw.csv")) == h6_raw_counts(joinpath(direct,"raw.csv"))
            saved_state=open(Serialization.deserialize,joinpath(resumed,saved["current_checkpoint"]))
            reference_state=open(Serialization.deserialize,joinpath(direct,reference["current_checkpoint"]))
            # Count agreement alone can conceal an RNG reset by coincidence.
            @test rand(saved_state["rng"],32) == rand(reference_state["rng"],32)
        end
    end
end

@testset "H+6 resume rejects corrupted provenance and checkpoints" begin
    for corruption in (:checkpoint,:source,:environment)
        mktempdir() do dir
            config=h6_test_config(joinpath(dir,"config.toml");shots=1,rates=[0.0],channels=["z_only"])
            out=joinpath(dir,"run")
            metadata=H6ThresholdExample.run_study(config,out;io=devnull)
            if corruption == :checkpoint
                open(joinpath(out,metadata["current_checkpoint"]),"a") do io
                    write(io,UInt8(0x01))
                end
            else
                if corruption == :source
                    metadata["source_hashes"]["Project.toml"]="corrupted"
                else
                    metadata["runtime"]["julia_version"]="0.0.0"
                end
                open(joinpath(out,"metadata.toml"),"w") do io
                    TOML.print(io,metadata;sorted=true)
                end
            end
            @test_throws ArgumentError H6ThresholdExample.run_study(config,out;io=devnull)
        end
    end
end
end
