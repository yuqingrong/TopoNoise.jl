using Test, Random, TopoNoise

@testset "H+6 full-prefix replay API is available" begin
    @test isdefined(TopoNoise, :replay_toric3d_h6_full_prefix_x)
    @test isdefined(TopoNoise, :replay_toric3d_h6_full_prefix_z)
end

if isdefined(TopoNoise, :replay_toric3d_h6_full_prefix_x) &&
        isdefined(TopoNoise, :replay_toric3d_h6_full_prefix_z)

h6_full_checks(checks, bits) = BitVector(isodd(count(bits[check])) for check in checks)

function h6_full_final_audit(result, code, channel)
    bits = getproperty(result.frame, channel)
    checks = channel === :x ? plaquette_checks(code) : star_checks(code)
    logicals = channel === :x ? toric3d_encoded_logical_z(code) : toric3d_encoded_logical_x(code)
    @test !any(getproperty(result.frame, channel === :x ? :z : :x))
    @test result.syndrome == h6_full_checks(checks, bits)
    @test result.syndrome == h6_full_checks(checks, result.recovery)
    @test result.residual == bits .⊻ result.recovery
    @test !any(h6_full_checks(checks, result.residual))
    logical = h6_full_checks(logicals, result.residual)
    @test (result.logical_1, result.logical_2) == Tuple(logical)
    @test result.failure == any(logical)
end

# Reconstruct the circuit from immutable faults and the reported recoveries.
# Expectations use physical check supports, not the decoder's stored matrices.
function h6_full_history_audit(result, encoder, faults, family, channel)
    code = family.code
    @test length(result.history) == code.lattice.steps
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    transfer = channel === :x ? faults : faults.transfer
    if channel === :z
        frame.z[toric3d_slice_qubits(code.lattice, 0)] .= faults.seed
    end
    first_operation = 1
    for r in 1:code.lattice.steps
        propagate_toric3d_segment!(frame, encoder, transfer,
            first_operation, encoder.checkpoints[r])
        first_operation = encoder.checkpoints[r] + 1
        entry = result.history[r]
        prefix = toric3d_encoded_prefix(code, r)
        bits = getproperty(frame, channel)
        checks = channel === :x ? plaquette_checks(prefix.code) : star_checks(prefix.code)
        measured = channel === :x ? entry.pre_syndrome : entry.syndrome
        @test entry.checkpoint == r
        @test entry.qubits == prefix.qubits
        @test Set(data_qubit_coordinate(code, q)[2] for q in entry.qubits) == Set(0:r)
        @test measured == h6_full_checks(checks, bits[prefix.qubits])
        @test h6_full_checks(checks, entry.recovery) == measured
        support = entry.qubits[findall(entry.recovery)]
        @test all(0 <= data_qubit_coordinate(code, q)[2] <= r for q in support)
        future = findall(q -> data_qubit_coordinate(code, q)[2] > r, eachindex(bits))
        before = copy(bits[future])
        bits[entry.qubits] .⊻= entry.recovery
        @test bits[future] == before
        @test entry.post_syndrome == h6_full_checks(checks, bits[prefix.qubits])
        @test !any(entry.post_syndrome)
        if channel === :x
            @test entry.future_qubits == future
            @test entry.future_before == entry.future_after == before
            @test entry.frontier_syndrome == h6_full_checks(
                toric3d_slice_checks(prefix.code.lattice, r), bits[prefix.qubits])
            @test !any(entry.frontier_syndrome)
        else
            @test entry.kind === :prefix
            @test entry.support == support
        end
    end
    @test result.frame == frame
    @test !any(result.syndrome)
    @test !any(result.recovery)
    @test result.residual == getproperty(frame, channel)
    h6_full_final_audit(result, code, channel)
end

@testset "Full-prefix feedback clears every single small X and Z fault, including T=1" begin
    for T in (1, 2)
        code = Toric3DEncodedSlice(T, 2, 2)
        encoder = toric3d_encoded_encoder(code)
        x_family = build_toric3d_x_feedback_decoders(code; p=.02)
        z_family = build_toric3d_z_feedback_decoders(code)
        clean = sample_toric3d_faults(MersenneTwister(301), encoder)
        clean_z = Toric3DDiagonalZFaultRecord(falses(12), clean)
        for (channel, faults, family, replay) in (
                (:x, clean, x_family, TopoNoise.replay_toric3d_h6_full_prefix_x),
                (:z, clean_z, z_family, TopoNoise.replay_toric3d_h6_full_prefix_z))
            result = replay(encoder, faults, family; record_history=true)
            h6_full_history_audit(result, encoder, faults, family, channel)
            @test !result.failure
            @test !any(getproperty(result.frame, channel))
            @test isempty(replay(encoder, faults, family).history)
        end
        checked = 0
        for (gate, operation) in enumerate(encoder.operations), q in operation.qubits
            x = with_toric3d_fault(encoder, clean, gate, q, :X)
            z = Toric3DDiagonalZFaultRecord(clean_z.seed,
                with_toric3d_fault(encoder, clean, gate, q, :Z))
            for (channel, faults, family, replay) in (
                    (:x, x, x_family, TopoNoise.replay_toric3d_h6_full_prefix_x),
                    (:z, z, z_family, TopoNoise.replay_toric3d_h6_full_prefix_z))
                saved = deepcopy(faults)
                result = replay(encoder, faults, family; record_history=true)
                h6_full_history_audit(result, encoder, faults, family, channel)
                @test faults == saved
            end
            checked += 1
        end
        @test checked == 52T
        for q in eachindex(clean_z.seed)
            seed = copy(clean_z.seed); seed[q] = true
            faults = Toric3DDiagonalZFaultRecord(seed, clean)
            saved = deepcopy(faults)
            result = TopoNoise.replay_toric3d_h6_full_prefix_z(
                encoder, faults, z_family; record_history=true)
            h6_full_history_audit(result, encoder, faults, z_family, :z)
            @test faults == saved
        end
    end
end

@testset "Full-prefix history includes the final correction and never an r=0 correction" begin
    for T in (1, 3)
        code = Toric3DEncodedSlice(T, 2, 3)
        encoder = toric3d_encoded_encoder(code)
        clean = sample_toric3d_faults(MersenneTwister(302), encoder)
        x_family = build_toric3d_x_feedback_decoders(code; p=.02)
        z_family = build_toric3d_z_feedback_decoders(code)
        gate = last(encoder.checkpoints)
        q = last(encoder.operations[gate].qubits)
        x = with_toric3d_fault(encoder, clean, gate, q, :X)
        z = Toric3DDiagonalZFaultRecord(falses(18),
            with_toric3d_fault(encoder, clean, gate, q, :Z))
        for (channel, faults, family, replay) in (
                (:x, x, x_family, TopoNoise.replay_toric3d_h6_full_prefix_x),
                (:z, z, z_family, TopoNoise.replay_toric3d_h6_full_prefix_z))
            result = replay(encoder, faults, family; record_history=true)
            h6_full_history_audit(result, encoder, faults, family, channel)
            last_entry = last(result.history)
            @test any(channel === :x ? last_entry.pre_syndrome : last_entry.syndrome)
            @test any(last_entry.recovery)
            @test [entry.checkpoint for entry in result.history] == collect(1:T)
            baseline = replay(encoder, faults, family; feedback=false)
            @test any(baseline.syndrome)
            if T == 1
                @test result.residual == baseline.residual
                @test result.failure == baseline.failure
            end
        end
        noisy_seed = falses(18); noisy_seed[1] = true
        faults = Toric3DDiagonalZFaultRecord(noisy_seed, clean)
        result = TopoNoise.replay_toric3d_h6_full_prefix_z(
            encoder, faults, z_family; record_history=true)
        h6_full_history_audit(result, encoder, faults, z_family, :z)
        @test first(result.history).checkpoint == 1
        @test any(first(result.history).syndrome)
    end
end

@testset "Random rectangular histories and exact final-only baseline" begin
    for dims in ((1, 2, 2), (3, 2, 2), (3, 2, 3), (3, 3, 2), (3, 3, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        x_family = build_toric3d_x_feedback_decoders(code; p=.18)
        z_family = build_toric3d_z_feedback_decoders(code)
        for seed in 1:5
            x = sample_toric3d_faults(MersenneTwister(seed), encoder; p_x=.18)
            z = sample_toric3d_diagonal_z_faults(MersenneTwister(seed), encoder; p=.18)
            for (channel, faults, family, replay) in (
                    (:x, x, x_family, TopoNoise.replay_toric3d_h6_full_prefix_x),
                    (:z, z, z_family, TopoNoise.replay_toric3d_h6_full_prefix_z))
                saved = deepcopy(faults)
                result = replay(encoder, faults, family; record_history=true)
                h6_full_history_audit(result, encoder, faults, family, channel)
                unrecorded = replay(encoder, faults, family)
                @test isempty(unrecorded.history)
                for key in (:frame, :syndrome, :recovery, :residual, :logical_1, :logical_2, :failure)
                    @test getproperty(unrecorded, key) == getproperty(result, key)
                end
                baseline = replay(encoder, faults, family; feedback=false, record_history=true)
                established = channel === :x ? replay_toric3d_x_feedback(
                    encoder, faults, family.slice, family.prefixes[end]; feedback=false) :
                    replay_toric3d_z_strength(encoder, faults, family; protocol=:none)
                @test isempty(baseline.history)
                for key in (:frame, :syndrome, :recovery, :residual, :logical_1, :logical_2, :failure)
                    @test getproperty(baseline, key) == getproperty(established, key)
                end
                h6_full_final_audit(baseline, code, channel)
                @test faults == saved
            end
        end
    end
end

@testset "Full-prefix feedback preserves zero-syndrome logical errors" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    clean = sample_toric3d_faults(MersenneTwister(303), encoder)
    x_family = build_toric3d_x_feedback_decoders(code; p=.02)
    z_family = build_toric3d_z_feedback_decoders(code)
    for (index, support) in enumerate(toric3d_encoded_logical_z(code))
        seed = falses(18); seed[support] .= true
        faults = Toric3DDiagonalZFaultRecord(seed, clean)
        result = TopoNoise.replay_toric3d_h6_full_prefix_z(
            encoder, faults, z_family; record_history=true)
        h6_full_history_audit(result, encoder, faults, z_family, :z)
        @test all(!any(entry.syndrome) && !any(entry.recovery) for entry in result.history)
        @test (result.logical_1, result.logical_2, result.failure) == (index == 1, index == 2, true)
    end
    prefix = toric3d_encoded_prefix(code, 1)
    for (index, support) in enumerate(toric3d_encoded_logical_x(prefix.code))
        # Inject each membrane bit at its final use in transfer 1, so the
        # complete undetectable membrane first exists at checkpoint 1.
        faults = clean
        for q in prefix.qubits[support]
            gate = findlast(i -> q in encoder.operations[i].qubits, 1:encoder.checkpoints[1])
            @test gate !== nothing
            faults = with_toric3d_fault(encoder, faults, gate, q, :X)
        end
        result = TopoNoise.replay_toric3d_h6_full_prefix_x(
            encoder, faults, x_family; record_history=true)
        h6_full_history_audit(result, encoder, faults, x_family, :x)
        @test all(!any(entry.pre_syndrome) && !any(entry.recovery) for entry in result.history)
        @test (result.logical_1, result.logical_2, result.failure) == (index == 1, index == 2, true)
    end
end

@testset "Full-prefix replay validates family geometry and mutable fault contents" begin
    code = Toric3DEncodedSlice(2, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    clean = sample_toric3d_faults(MersenneTwister(304), encoder)
    clean_z = Toric3DDiagonalZFaultRecord(falses(18), clean)
    x_family = build_toric3d_x_feedback_decoders(code; p=0)
    z_family = build_toric3d_z_feedback_decoders(code)
    foreign = Toric3DEncodedSlice(2, 3, 2)
    foreign_x = build_toric3d_x_feedback_decoders(foreign; p=.02)
    foreign_z = build_toric3d_z_feedback_decoders(foreign)
    foreign_fault = sample_toric3d_faults(MersenneTwister(305), toric3d_encoded_encoder(foreign))
    short_x = Toric3DXFeedbackDecoderFamily(code, x_family.slice, x_family.prefixes[1:end-1])
    short_z = Toric3DZFeedbackDecoderFamily(code, z_family.seed, z_family.transfer, z_family.prefixes[1:end-1])
    mixed_x = Toric3DXFeedbackDecoderFamily(code, x_family.slice, foreign_x.prefixes)
    mixed_z = Toric3DZFeedbackDecoderFamily(code, z_family.seed, z_family.transfer, foreign_z.prefixes)
    z_fault = with_toric3d_fault(encoder, clean, 1, only(encoder.operations[1].qubits), :Z)
    bad_z = deepcopy(clean_z); bad_z.transfer.x[1, 1] = true
    short_seed = deepcopy(clean_z); pop!(short_seed.seed)
    inactive_x = deepcopy(clean); inactive_x.x[2, 1] = true
    inactive_z = deepcopy(clean_z); inactive_z.transfer.z[2, 1] = true
    short_record = Toric3DFaultRecord(2, 2, 3, falses(2, 1), falses(2, 1))
    for feedback in (false, true)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, clean, foreign_x; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, clean_z, foreign_z; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, clean, short_x; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, clean_z, short_z; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, clean, mixed_x; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, clean_z, mixed_z; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, z_fault, x_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, bad_z, z_family; feedback)
        @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, short_seed, z_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, inactive_x, x_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_z(encoder, inactive_z, z_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, short_record, x_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_x(encoder, foreign_fault, x_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_z(encoder,
            Toric3DDiagonalZFaultRecord(falses(18), foreign_fault), z_family; feedback)
        @test_throws ArgumentError TopoNoise.replay_toric3d_h6_full_prefix_z(encoder,
            Toric3DDiagonalZFaultRecord(falses(18), short_record), z_family; feedback)
    end
end

end
