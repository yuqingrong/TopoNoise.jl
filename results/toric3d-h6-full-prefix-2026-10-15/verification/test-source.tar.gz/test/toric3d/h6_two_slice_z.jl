using Test
using Random
using TopoNoise

@testset "H+6 Z two-slice feedback API is available" begin
    @test isdefined(TopoNoise, :replay_toric3d_h6_two_slice_z)
end

h6_two_slice_z_parity(matrix, bits) = BitVector(isodd.(matrix * UInt8.(bits)))

function h6_two_slice_z_check_final(result, code)
    matrix = star_check_matrix(code; sparse=true)
    @test keys(result) == (:frame, :syndrome, :recovery, :residual,
        :logical_1, :logical_2, :failure, :history)
    @test !any(result.frame.x)
    @test result.syndrome == h6_two_slice_z_parity(matrix, result.frame.z)
    @test result.syndrome == h6_two_slice_z_parity(matrix, result.recovery)
    @test result.residual == result.frame.z .⊻ result.recovery
    @test !any(h6_two_slice_z_parity(matrix, result.residual))
    logical = [isodd(count(result.residual[support]))
        for support in toric3d_encoded_logical_x(code)]
    @test (result.logical_1, result.logical_2) == Tuple(logical)
    @test result.failure == any(logical)
end

function h6_two_slice_z_check_history(result, encoder, faults, family)
    code = family.code
    steps = code.lattice.steps
    @test length(result.history) == steps
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    window = toric3d_z_feedback_window(code, 0)
    frame.z[window.qubits] .= faults.seed
    first_operation = 1
    for r in 1:steps
        propagate_toric3d_segment!(frame, encoder, faults.transfer,
            first_operation, encoder.checkpoints[r])
        first_operation = encoder.checkpoints[r] + 1
        entry = result.history[r]
        window = toric3d_z_feedback_window(code, r)
        @test entry.kind === :window
        @test entry.checkpoint == r
        @test entry.qubits == vcat(toric3d_slice_qubits(code.lattice, r - 1),
            toric3d_slice_qubits(code.lattice, r))
        @test entry.syndrome == toric3d_z_window_syndrome(window, frame.z)
        @test h6_two_slice_z_parity(window.matrix, entry.recovery) == entry.syndrome
        @test entry.support == entry.qubits[findall(entry.recovery)]
        @test all(data_qubit_coordinate(code, q)[2] in (r - 1, r) for q in entry.support)
        frame.z[entry.qubits] .⊻= entry.recovery
        @test !any(toric3d_z_window_syndrome(window, frame.z))
        prefix = toric3d_encoded_prefix(code, r)
        prefix_syndrome = h6_two_slice_z_parity(star_check_matrix(prefix.code; sparse=true),
            frame.z[prefix.qubits])
        @test entry.post_syndrome == prefix_syndrome
        @test !any(prefix_syndrome)
    end
    @test frame.z == result.frame.z
    @test frame.x == result.frame.x
    @test !any(result.syndrome)
    @test !any(result.recovery)
    @test result.residual == result.frame.z
    h6_two_slice_z_check_final(result, code)
end

@testset "Z two-slice complete feedback includes the last transfer" begin
    for dims in ((1, 2, 2), (3, 2, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        family = build_toric3d_z_feedback_decoders(code)
        clean = sample_toric3d_diagonal_z_faults(MersenneTwister(201), encoder; p=0)
        gate = length(encoder.operations)
        transfer = with_toric3d_fault(encoder, clean.transfer, gate,
            last(encoder.operations[gate].qubits), :Z)
        record = Toric3DDiagonalZFaultRecord(clean.seed, transfer)
        result = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family; record_history=true)
        h6_two_slice_z_check_history(result, encoder, record, family)
        @test last(result.history).checkpoint == dims[1]
        @test any(last(result.history).syndrome)
        @test any(last(result.history).recovery)
        @test !any(last(result.history).post_syndrome)
        # The previous complete-window arm intentionally skips this local T window.
        previous = replay_toric3d_z_strength(encoder, record, family;
            protocol=:slice_local, record_history=true)
        @test length(previous.history) == dims[1]
        @test result.history[1:end-1] == previous.history[2:end]
        @test any(previous.syndrome)
        @test any(previous.recovery)
        @test result.frame.z != previous.frame.z
        @test !any(result.syndrome)
        @test !any(result.recovery)
    end
end

@testset "Noisy Z seed waits for the first two-slice window" begin
    code = Toric3DEncodedSlice(1, 2, 2)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(205), encoder; p=0)
    seed = copy(clean.seed); seed[1] = true
    record = Toric3DDiagonalZFaultRecord(seed, clean.transfer)
    result = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family; record_history=true)
    @test length(result.history) == 1
    @test only(result.history).kind === :window
    @test only(result.history).checkpoint == 1
    @test any(only(result.history).syndrome)
    @test any(only(result.history).recovery)
    @test !any(only(result.history).post_syndrome)
    h6_two_slice_z_check_history(result, encoder, record, family)
end

@testset "Every small seed and transfer Z fault has a fully clear prefix" begin
    code = Toric3DEncodedSlice(2, 2, 2)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(202), encoder; p=0)
    records = Toric3DDiagonalZFaultRecord[clean]
    for q in eachindex(clean.seed)
        seed = copy(clean.seed); seed[q] = true
        push!(records, Toric3DDiagonalZFaultRecord(seed, clean.transfer))
    end
    for (gate, operation) in enumerate(encoder.operations), q in operation.qubits
        transfer = with_toric3d_fault(encoder, clean.transfer, gate, q, :Z)
        push!(records, Toric3DDiagonalZFaultRecord(clean.seed, transfer))
    end
    @test length(records) == 117
    for record in records
        saved = deepcopy(record)
        result = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family; record_history=true)
        h6_two_slice_z_check_history(result, encoder, record, family)
        @test record == saved
    end
    clean_result = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, clean, family)
    @test !clean_result.failure
    @test !any(clean_result.frame.z)
    @test isempty(clean_result.history)
end

@testset "Random and rectangular Z two-slice replay agrees with direct history propagation" begin
    for dims in ((1, 2, 2), (3, 2, 2), (3, 2, 3), (3, 3, 2), (3, 3, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        family = build_toric3d_z_feedback_decoders(code)
        for seed in 1:5
            record = sample_toric3d_diagonal_z_faults(MersenneTwister(seed), encoder; p=0.18)
            saved = deepcopy(record)
            active = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family; record_history=true)
            h6_two_slice_z_check_history(active, encoder, record, family)
            @test record == saved
            baseline = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family;
                feedback=false, record_history=true)
            old_none = replay_toric3d_z_strength(encoder, record, family; protocol=:none)
            @test isempty(baseline.history)
            @test baseline.frame.z == old_none.frame.z
            @test baseline.frame.x == old_none.frame.x
            @test (baseline.syndrome, baseline.recovery, baseline.residual,
                baseline.logical_1, baseline.logical_2, baseline.failure) ==
                (old_none.syndrome, old_none.recovery, old_none.residual,
                old_none.logical_1, old_none.logical_2, old_none.failure)
            @test record == saved
            h6_two_slice_z_check_final(baseline, code)
        end
    end
end

@testset "Z two-slice complete recovery preserves undetectable logical information" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(203), encoder; p=0)
    for (index, support) in enumerate(toric3d_encoded_logical_z(code))
        seed = copy(clean.seed); seed[support] .= true
        record = Toric3DDiagonalZFaultRecord(seed, clean.transfer)
        result = TopoNoise.replay_toric3d_h6_two_slice_z(encoder, record, family; record_history=true)
        h6_two_slice_z_check_history(result, encoder, record, family)
        @test all(!any(entry.syndrome) && !any(entry.recovery) for entry in result.history)
        @test (result.logical_1, result.logical_2, result.failure) ==
            (index == 1, index == 2, true)
    end
    wrong_encoder = toric3d_encoded_encoder(Toric3DEncodedSlice(2, 2, 3))
    wrong_record = sample_toric3d_diagonal_z_faults(MersenneTwister(204), wrong_encoder; p=0)
    @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_two_slice_z(
        wrong_encoder, wrong_record, family)
    @test_throws ArgumentError TopoNoise.replay_toric3d_h6_two_slice_z(encoder, wrong_record, family)
    wrong_depth = Toric3DZFeedbackDecoderFamily(code, family.seed, family.transfer, family.prefixes[1:end-1])
    @test_throws DimensionMismatch TopoNoise.replay_toric3d_h6_two_slice_z(encoder, clean, wrong_depth)
end
