using Test
using Random
using TopoNoise

@testset "H+6 causal Z one-step API is available" begin
    @test isdefined(TopoNoise, :build_toric3d_h6_z_one_step_decoder)
    @test isdefined(TopoNoise, :decode_toric3d_h6_z_one_step)
    @test isdefined(TopoNoise, :replay_toric3d_h6_z_one_step)
end

h6_z_test_syndrome(matrix, bits) = BitVector(isodd.(matrix * Vector{UInt8}(bits)))

function h6_z_test_decision(decoder, syndrome)
    matrix = decoder.family.transfer.matrix
    cells = decoder.family.code.lattice.Ly * decoder.family.code.lattice.Lz
    saved = copy(syndrome)
    result = decode_toric3d_h6_z_one_step(decoder, syndrome)
    @test syndrome == saved
    @test h6_z_test_syndrome(matrix, result.recovery) == syndrome
    @test result.residual_syndrome == syndrome .⊻ h6_z_test_syndrome(matrix, result.route)
    @test !any(result.residual_syndrome[1:cells])
    @test !any(result.route[3cells+1:end])
    @test length(result.matched_pairs) == length(result.paths) == count(syndrome) ÷ 2
    endpoints = falses(length(syndrome))
    for ((a, b), path) in zip(result.matched_pairs, result.paths)
        endpoints[a] ⊻= true
        endpoints[b] ⊻= true
        path_bits = falses(size(matrix, 2))
        for q in path
            path_bits[q] ⊻= true
        end
        expected = falses(length(syndrome))
        expected[[a, b]] .= true
        @test h6_z_test_syndrome(matrix, path_bits) == expected
    end
    @test endpoints == syndrome
    return result
end

function h6_z_test_replay(result, decoder)
    code = decoder.family.code
    cells = code.lattice.Ly * code.lattice.Lz
    @test !any(result.frame.x)
    @test h6_z_test_syndrome(decoder.family.prefixes[end].matrix, result.recovery) ==
          result.syndrome
    @test !any(h6_z_test_syndrome(decoder.family.prefixes[end].matrix, result.residual))
    expected = toric3d_z_threshold_outcome(decoder.family.prefixes[end], result.frame.z)
    @test (result.syndrome, result.recovery, result.residual,
           result.logical_1, result.logical_2, result.failure) == values(expected)
    @test first(result.history).kind === :seed
    @test !any(first(result.history).post_syndrome)
    for entry in result.history[2:end]
        r = entry.checkpoint
        window = toric3d_z_feedback_window(code, r)
        @test entry.kind === :window
        @test entry.qubits == window.qubits
        @test entry.support == entry.qubits[findall(entry.route)]
        @test all(data_qubit_coordinate(code, q)[2] == r - 1 for q in entry.support)
        @test h6_z_test_syndrome(window.matrix, entry.recovery) == entry.syndrome
        @test entry.residual_syndrome == entry.syndrome .⊻
              h6_z_test_syndrome(window.matrix, entry.route)
        @test entry.window_post_syndrome == entry.residual_syndrome
        @test entry.retiring_syndrome == entry.syndrome[1:cells]
        @test entry.predicted_retiring_syndrome == entry.residual_syndrome[1:cells]
        @test entry.observed_retiring_syndrome == entry.window_post_syndrome[1:cells]
        @test !any(entry.observed_retiring_syndrome)
        @test entry.retired_prefix_rows == 1:r*cells
        @test !any(entry.post_syndrome[1:r*cells])
        @test entry.post_syndrome[(r-1)*cells+1:end] == entry.window_post_syndrome
        @test entry.prefix_syndrome[(r-1)*cells+1:end] == entry.syndrome
    end
end

@testset "Closed three-sheet Z matching clears only retiring endpoints" begin
    family = build_toric3d_z_feedback_decoders(Toric3DEncodedSlice(2, 2, 2))
    decoder = build_toric3d_h6_z_one_step_decoder(family)
    @test decoder.family === family
    remaining = 0
    # All 2^11 even syndromes on the 12-check physical graph are affordable.
    for mask in 0:(2^12-1)
        iseven(count_ones(mask)) || continue
        syndrome = BitVector(!iszero(mask & (1 << (i-1))) for i in 1:12)
        decision = h6_z_test_decision(decoder, syndrome)
        remaining += any(decision.residual_syndrome)
    end
    @test remaining > 0
    middle_pair = falses(12)
    middle_pair[[5, 6]] .= true
    decision = decode_toric3d_h6_z_one_step(decoder, middle_pair)
    @test !any(decision.route)
    @test decision.residual_syndrome == middle_pair
    @test decision == decode_toric3d_h6_z_one_step(decoder, middle_pair)
    @test_throws DimensionMismatch decode_toric3d_h6_z_one_step(decoder, falses(11))
    odd = falses(12); odd[1] = true
    @test_throws ArgumentError decode_toric3d_h6_z_one_step(decoder, odd)
end

@testset "Every H+6 seed and transfer single Z fault respects retired checks" begin
    code = Toric3DEncodedSlice(2, 2, 2)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    decoder = build_toric3d_h6_z_one_step_decoder(family)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(561), encoder; p=0)
    records = Toric3DDiagonalZFaultRecord[]
    for q in eachindex(clean.seed)
        seed = copy(clean.seed); seed[q] = true
        push!(records, Toric3DDiagonalZFaultRecord(seed, clean.transfer))
    end
    for (gate, operation) in enumerate(encoder.operations), q in operation.qubits
        transfer = with_toric3d_fault(encoder, clean.transfer, gate, q, :Z)
        push!(records, Toric3DDiagonalZFaultRecord(clean.seed, transfer))
    end
    @test length(records) == 116
    for record in records
        result = replay_toric3d_h6_z_one_step(encoder, record, decoder; record_history=true)
        @test length(result.history) == 2
        h6_z_test_replay(result, decoder)
    end
    result = replay_toric3d_h6_z_one_step(encoder, clean, decoder; record_history=true)
    @test !result.failure
    @test !any(result.frame.z)
    @test !any(result.recovery)
    @test all(!any(entry.syndrome) for entry in result.history)
    @test isempty(replay_toric3d_h6_z_one_step(encoder, clean, decoder).history)
end

@testset "H+6 random multi-fault histories retain a causal two-sheet residual" begin
    nonzero_windows = 0
    for dims in ((3, 2, 2), (3, 2, 3), (3, 3, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        family = build_toric3d_z_feedback_decoders(code)
        decoder = build_toric3d_h6_z_one_step_decoder(family)
        for seed in 1:8
            record = sample_toric3d_diagonal_z_faults(MersenneTwister(seed), encoder; p=0.19)
            saved = (copy(record.seed), copy(record.transfer.x), copy(record.transfer.z))
            result = replay_toric3d_h6_z_one_step(encoder, record, decoder; record_history=true)
            h6_z_test_replay(result, decoder)
            @test length(result.history) == dims[1]
            @test (record.seed, record.transfer.x, record.transfer.z) == saved
            nonzero_windows += count(entry -> any(entry.residual_syndrome), result.history[2:end])
            # The seed correction is shared exactly with existing complete local feedback.
            local_result = replay_toric3d_z_strength(encoder, record, family;
                protocol=:slice_local, record_history=true)
            @test result.history[1] == local_result.history[1]
        end
    end
    @test nonzero_windows > 0
end

@testset "H+6 seed-only control manually propagates the same corrected seed" begin
    for dims in ((1, 2, 2), (3, 2, 3))
        code = Toric3DEncodedSlice(dims...)
        encoder = toric3d_encoded_encoder(code)
        family = build_toric3d_z_feedback_decoders(code)
        decoder = build_toric3d_h6_z_one_step_decoder(family)
        record = sample_toric3d_diagonal_z_faults(MersenneTwister(99), encoder; p=0.23)
        result = replay_toric3d_h6_z_one_step(encoder, record, decoder;
            intermediate_feedback=false, record_history=true)
        frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
        qubits = toric3d_slice_qubits(code.lattice, 0)
        frame.z[qubits] .= record.seed
        measured = toric3d_z_window_syndrome(family.seed.window, frame.z)
        repair = decode_toric3d_z_feedback(family.seed, measured)
        frame.z[qubits] .⊻= repair
        propagate_toric3d_segment!(frame, encoder, record.transfer, 1, length(encoder.operations))
        @test result.frame.z == frame.z
        @test length(result.history) == 1
        h6_z_test_replay(result, decoder)
        if dims[1] == 1
            active = replay_toric3d_h6_z_one_step(encoder, record, decoder; record_history=true)
            local_result = replay_toric3d_z_strength(encoder, record, family;
                protocol=:slice_local, record_history=true)
            @test active.frame.z == result.frame.z
            @test active.history == result.history
            @test active.residual == result.residual
            @test active.frame.z == local_result.frame.z
            @test active.history == local_result.history
            @test active.residual == local_result.residual
        end
    end
end

@testset "A retained Z defect moves into the next retiring sheet causally" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    decoder = build_toric3d_h6_z_one_step_decoder(build_toric3d_z_feedback_decoders(code))
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(13), encoder; p=0)
    gate = encoder.checkpoints[1]
    new_qubit = last(encoder.operations[gate].qubits)
    transfer = with_toric3d_fault(encoder, clean.transfer, gate, new_qubit, :Z)
    result = replay_toric3d_h6_z_one_step(encoder,
        Toric3DDiagonalZFaultRecord(clean.seed, transfer), decoder; record_history=true)
    first_window, next_window = result.history[2:3]
    @test !any(first_window.route)
    @test count(first_window.residual_syndrome) == 2
    @test !any(first_window.residual_syndrome[1:6])
    @test any(next_window.retiring_syndrome)
    @test count(next_window.route) == 1
    @test !any(next_window.observed_retiring_syndrome)
    @test !any(next_window.post_syndrome)
    @test !result.failure
end

@testset "Naive X endpoint trimming can create a retiring Z defect" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    family = build_toric3d_z_feedback_decoders(code)
    decoder = build_toric3d_h6_z_one_step_decoder(family)
    syndrome = falses(18)
    syndrome[[1, 9]] .= true # One retiring endpoint and one middle endpoint.
    decision = decode_toric3d_h6_z_one_step(decoder, syndrome)
    @test count(decision.route) == 1
    @test !any(decision.residual_syndrome[1:6])
    # Applying both endpoint edges, as for the X slice, sends the middle
    # endpoint backwards to a retiring check on this shortest physical path.
    naive_route = falses(36)
    for path in decision.paths
        naive_route[first(path)] ⊻= true
        length(path) > 1 && (naive_route[last(path)] ⊻= true)
    end
    naive_residual = syndrome .⊻ h6_z_test_syndrome(family.transfer.matrix, naive_route)
    @test any(naive_residual[1:6])
    @test decision.route != naive_route
end

@testset "A transfer fault on a disappearing old check needs the retiring sheet" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    decoder = build_toric3d_h6_z_one_step_decoder(family)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(19), encoder; p=0)
    # This post-CNOT Z on old qubit 10 touches initial white check 6.
    transfer = with_toric3d_fault(encoder, clean.transfer, 4, 10, :Z)
    record = Toric3DDiagonalZFaultRecord(clean.seed, transfer)
    frame = PauliFrame(falses(data_qubit_count(code)), falses(data_qubit_count(code)))
    propagate_toric3d_segment!(frame, encoder, transfer, 1, encoder.checkpoints[1])
    first_syndrome = toric3d_z_window_syndrome(decoder.windows[1], frame.z)
    @test findall(first_syndrome) == [6, 10]
    @test isodd(count(first_syndrome[7:end]))
    propagate_toric3d_segment!(frame, encoder, transfer,
        encoder.checkpoints[1] + 1, encoder.checkpoints[2])
    later_window = toric3d_z_window_syndrome(decoder.windows[2], frame.z)
    prefix = toric3d_encoded_prefix(code, 2)
    prefix_syndrome = h6_z_test_syndrome(family.prefixes[2].matrix, frame.z[prefix.qubits])
    @test prefix_syndrome[6]
    @test isodd(count(later_window))
    @test_throws ArgumentError decode_toric3d_h6_z_one_step(decoder, later_window)
    repaired = replay_toric3d_h6_z_one_step(encoder, record, decoder; record_history=true)
    @test !any(repaired.history[2].observed_retiring_syndrome)
    @test !any(repaired.history[3].post_syndrome[1:12])
end

@testset "Syndrome-only H+6 feedback preserves undetectable logical Z errors" begin
    code = Toric3DEncodedSlice(3, 2, 3)
    encoder = toric3d_encoded_encoder(code)
    family = build_toric3d_z_feedback_decoders(code)
    decoder = build_toric3d_h6_z_one_step_decoder(family)
    clean = sample_toric3d_diagonal_z_faults(MersenneTwister(31), encoder; p=0)
    seed = copy(clean.seed)
    seed[first(toric3d_encoded_logical_z(code))] .= true
    record = Toric3DDiagonalZFaultRecord(seed, clean.transfer)
    result = replay_toric3d_h6_z_one_step(encoder, record, decoder; record_history=true)
    @test all(!any(entry.syndrome) for entry in result.history)
    @test all(!any(entry.recovery) for entry in result.history)
    @test !any(result.syndrome)
    @test !any(result.recovery)
    @test (result.logical_1, result.logical_2, result.failure) == (true, false, true)
    wrong_code = Toric3DEncodedSlice(2, 2, 3)
    wrong_encoder = toric3d_encoded_encoder(wrong_code)
    wrong_record = sample_toric3d_diagonal_z_faults(MersenneTwister(1), wrong_encoder; p=0)
    @test_throws DimensionMismatch replay_toric3d_h6_z_one_step(wrong_encoder, wrong_record, decoder)
    @test_throws ArgumentError replay_toric3d_h6_z_one_step(encoder, wrong_record, decoder)
end
